#!/usr/bin/env bash
#
#  build.sh
#  AppleMailMCP
#
#  Created by Michel Storms on 21/10/2026.
#
#  Builds the EventKit helper delete_event runs (#42). Calendar.app's
#  AppleScript dictionary has no delete command, so deletion has to go through
#  EventKit, and EventKit only grants calendar access to a binary carrying an
#  NSCalendarsFullAccessUsageDescription, embedded here as __TEXT,__info_plist.
#  Ad-hoc signed with a fixed identifier, which is what the grant attaches to.
#
#  Usage: helpers/calendar-delete/build.sh [<output dir>]   (default: its build/)
#

set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT="${1:-$HERE/build}"
mkdir -p "$OUT"

swiftc -O \
  -o "$OUT/applecal-delete" \
  "$HERE/main.swift" \
  -framework EventKit \
  -Xlinker -sectcreate -Xlinker __TEXT -Xlinker __info_plist -Xlinker "$HERE/Info.plist"

codesign --force --sign - --identifier com.stormychel.applemailmcp.calendar-delete "$OUT/applecal-delete"
echo "$OUT/applecal-delete"
