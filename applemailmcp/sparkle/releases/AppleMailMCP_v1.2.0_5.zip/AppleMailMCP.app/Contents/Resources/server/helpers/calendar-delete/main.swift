//
//  main.swift
//  AppleMailMCP
//
//  Created by Michel Storms on 21/10/2026.
//
//  The EventKit half of delete_event (#42). Calendar.app's scripting
//  dictionary has no delete command, so this is the only way in.
//
//  It deletes exactly one thing per run, chosen by calendarItemIdentifier (the
//  index's CalendarItem.UUID, which get_event returns as uid), and only after
//  the title and start the caller read from the index match what EventKit
//  holds. Every answer is one line of JSON on stdout: {"ok":true,…} or
//  {"ok":false,"code":…,"error":…} with exit status 1.
//
//  Usage:
//    applecal-delete --version
//    applecal-delete delete --uid <uid> --title <title> --start <start>
//                           --span single|occurrence|future|series [--occurrence <date>]
//
//  <start> and <date> are an ISO-8601 instant for a timed event, or YYYY-MM-DD
//  for an all-day one, exactly as get_event and search_events print them.
//

import EventKit
import Foundation

let helperVersion = 1

func emit(_ object: [String: Any]) -> Never {
    let data = (try? JSONSerialization.data(withJSONObject: object, options: [.sortedKeys])) ?? Data("{\"ok\":false,\"code\":\"internal\",\"error\":\"could not encode the answer\"}".utf8)
    FileHandle.standardOutput.write(data)
    FileHandle.standardOutput.write(Data("\n".utf8))
    exit((object["ok"] as? Bool) == true ? 0 : 1)
}

func fail(_ code: String, _ message: String) -> Never {
    emit(["ok": false, "code": code, "error": message])
}

// MARK: - Arguments

var argv = Array(CommandLine.arguments.dropFirst())
if argv == ["--version"] {
    emit(["ok": true, "version": helperVersion])
}
guard argv.first == "delete" else {
    fail("usage", "expected --version or delete")
}
argv.removeFirst()

var options: [String: String] = [:]
var index = 0
while index < argv.count {
    let key = argv[index]
    guard key.hasPrefix("--"), index + 1 < argv.count else {
        fail("usage", "malformed arguments at \(key)")
    }
    options[String(key.dropFirst(2))] = argv[index + 1]
    index += 2
}

func required(_ name: String) -> String {
    guard let value = options[name], !value.isEmpty else {
        fail("usage", "--\(name) is required")
    }
    return value
}

let uid = required("uid")
let expectedTitle = required("title")
let expectedStart = required("start")
let span = required("span")
guard ["single", "occurrence", "future", "series"].contains(span) else {
    fail("usage", "--span must be single, occurrence, future or series")
}
let occurrenceSpec = options["occurrence"]
if (span == "occurrence" || span == "future") && (occurrenceSpec ?? "").isEmpty {
    fail("usage", "--occurrence is required for span \(span)")
}

// MARK: - Dates

/** A plain date for an all-day event, an instant otherwise; never a guess between them. */
enum When {
    case day(year: Int, month: Int, day: Int)
    case instant(Date)
}

func parseWhen(_ text: String) -> When? {
    let dayPattern = try! NSRegularExpression(pattern: "^(\\d{4})-(\\d{2})-(\\d{2})$")
    let range = NSRange(text.startIndex..., in: text)
    if let match = dayPattern.firstMatch(in: text, range: range) {
        func part(_ i: Int) -> Int { Int((text as NSString).substring(with: match.range(at: i)))! }
        return .day(year: part(1), month: part(2), day: part(3))
    }
    let plain = ISO8601DateFormatter()
    plain.formatOptions = [.withInternetDateTime]
    let fractional = ISO8601DateFormatter()
    fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
    if let date = plain.date(from: text) ?? fractional.date(from: text) {
        return .instant(date)
    }
    return nil
}

/** All-day dates in EventKit are floating midnights, so they are compared as calendar days. */
func matches(_ date: Date?, _ when: When) -> Bool {
    guard let date else { return false }
    switch when {
    case let .day(year, month, day):
        let parts = Calendar.current.dateComponents([.year, .month, .day], from: date)
        return parts.year == year && parts.month == month && parts.day == day
    case let .instant(instant):
        return abs(date.timeIntervalSince(instant)) < 1
    }
}

func describe(_ date: Date?, allDay: Bool) -> String {
    guard let date else { return "" }
    if allDay {
        let parts = Calendar.current.dateComponents([.year, .month, .day], from: date)
        return String(format: "%04d-%02d-%02d", parts.year!, parts.month!, parts.day!)
    }
    let formatter = ISO8601DateFormatter()
    formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
    return formatter.string(from: date)
}

guard let startWhen = parseWhen(expectedStart) else {
    fail("usage", "--start is neither YYYY-MM-DD nor an ISO-8601 instant: \(expectedStart)")
}

// MARK: - Access

let store = EKEventStore()

/// Asks only when the user has never answered. A refusal is final here: the
/// grant lives in System Settings, and asking again would not show a prompt.
func ensureAccess() {
    switch EKEventStore.authorizationStatus(for: .event) {
    case .fullAccess:
        return
    case .notDetermined:
        let done = DispatchSemaphore(value: 0)
        var granted = false
        var failure: Error?
        store.requestFullAccessToEvents { ok, error in
            granted = ok
            failure = error
            done.signal()
        }
        // As long as osascript's first-run Automation prompt is given: the
        // user may need to go and find the dialog.
        if done.wait(timeout: .now() + 600) == .timedOut {
            fail("access", "No answer to the Calendars permission prompt within 10 minutes. Nothing was deleted.")
        }
        if !granted {
            fail("access", "Calendars access was not granted\(failure.map { ": \($0.localizedDescription)" } ?? ""). Nothing was deleted.")
        }
    case .writeOnly:
        fail("access", "This helper has write-only Calendars access, which cannot look an event up. Grant full access under System Settings → Privacy & Security → Calendars. Nothing was deleted.")
    default:
        fail("access", "Calendars access is denied or restricted. Grant it under System Settings → Privacy & Security → Calendars. Nothing was deleted.")
    }
}

ensureAccess()

// MARK: - Resolve and check

guard let event = store.calendarItem(withIdentifier: uid) as? EKEvent else {
    fail("not_found", "EventKit has no event with identifier \(uid). Nothing was deleted.")
}
guard event.title == expectedTitle else {
    fail("mismatch", "Event \(uid) is titled \"\(event.title ?? "")\" in EventKit, not \"\(expectedTitle)\". The store may have changed since it was read. Nothing was deleted.")
}
guard matches(event.startDate, startWhen) else {
    fail("mismatch", "Event \(uid) starts \(describe(event.startDate, allDay: event.isAllDay)) in EventKit, not \(expectedStart). The store may have changed since it was read. Nothing was deleted.")
}
// Deleting a meeting the user organises sends cancellations to everyone on it,
// which no one can take back. An organiser EventKit cannot name is treated the
// same, rather than assumed to be someone else.
if event.hasAttendees && (event.organizer == nil || event.organizer?.isCurrentUser == true) {
    fail("organiser", "Event \(uid) has attendees and you organise it (or its organiser is unknown); deleting it would send cancellations. Nothing was deleted.")
}

let recurring = event.hasRecurrenceRules
if recurring && span == "single" {
    fail("span_required", "Event \(uid) repeats. Say which: occurrence (with its date), future (from that date on), or series. Nothing was deleted.")
}
if !recurring && span != "single" {
    fail("not_recurring", "Event \(uid) does not repeat in EventKit; pass span single. Nothing was deleted.")
}

var target: EKEvent = event
var ekSpan: EKSpan = .thisEvent
switch span {
case "series":
    // The master removed with futureEvents takes every occurrence with it.
    ekSpan = .futureEvents
case "occurrence", "future":
    guard let spec = occurrenceSpec, let when = parseWhen(spec) else {
        fail("usage", "--occurrence is neither YYYY-MM-DD nor an ISO-8601 instant")
    }
    let anchor: Date
    switch when {
    case let .day(year, month, day):
        anchor = Calendar.current.date(from: DateComponents(year: year, month: month, day: day))!
    case let .instant(instant):
        anchor = instant
    }
    let window = store.predicateForEvents(
        withStart: anchor.addingTimeInterval(-2 * 86400),
        end: anchor.addingTimeInterval(2 * 86400),
        calendars: [event.calendar],
    )
    // Matched on the current start only, which is what search_events prints.
    // Accepting the original date as well let two occurrences answer to one
    // date — one moved away from it, another moved onto it — and the window
    // could not see the first. Every event starting at the anchor is inside
    // the window, so exactly-one here is exactly-one in the series.
    let found = store.events(matching: window).filter {
        $0.calendarItemIdentifier == uid && matches($0.startDate, when)
    }
    guard found.count == 1, let occurrence = found.first else {
        fail("occurrence", "Event \(uid) has \(found.count) occurrences at \(spec), not exactly one. Nothing was deleted.")
    }
    target = occurrence
    ekSpan = span == "future" ? .futureEvents : .thisEvent
default:
    break
}

// Again for the occurrence itself: a changed occurrence can carry attendees
// its series does not, and deleting it would cancel on them just the same.
if target.hasAttendees && (target.organizer == nil || target.organizer?.isCurrentUser == true) {
    fail("organiser", "That occurrence of \(uid) has attendees and you organise it (or its organiser is unknown); deleting it would send cancellations. Nothing was deleted.")
}

// future and series also remove every changed occurrence after the target,
// each of which can be a meeting of its own. EventKit searches at most four
// years per query, so this walks four-year windows from the target to the
// series' end, or to ten years past today for one that never ends. The Node
// side has already checked every changed occurrence the index knows of, at
// any date; this catches ones EventKit has gained since.
if ekSpan == .futureEvents, let from = target.startDate {
    let chunk: TimeInterval = 4 * 365 * 86400
    // Ten years past the later of today and the target, and further when the
    // series has a later dated end. Never less than ten years: an end date
    // bounds the generated occurrences, not changed ones moved past it.
    var horizon = max(from, Date()).addingTimeInterval(10 * 365 * 86400)
    if let end = event.recurrenceRules?.first?.recurrenceEnd?.endDate, end >= horizon {
        horizon = end.addingTimeInterval(86400)
    }
    var windowStart = from
    while windowStart < horizon {
        let windowEnd = min(windowStart.addingTimeInterval(chunk), horizon)
        let ahead = store.predicateForEvents(withStart: windowStart, end: windowEnd, calendars: [event.calendar])
        let meeting = store.events(matching: ahead).first {
            $0.calendarItemIdentifier == uid && $0.isDetached && $0.hasAttendees
                && ($0.organizer == nil || $0.organizer?.isCurrentUser == true)
        }
        if let meeting {
            fail("organiser", "A changed occurrence of \(uid) on \(describe(meeting.startDate, allDay: meeting.isAllDay)) has attendees and you organise it (or its organiser is unknown); span \(span) would delete it and send cancellations. Nothing was deleted.")
        }
        windowStart = windowEnd
    }
}

let summary: [String: Any] = [
    "uid": uid,
    "title": target.title ?? "",
    "calendar": target.calendar?.title ?? "",
    "start": describe(target.startDate, allDay: target.isAllDay),
    "span": span,
]

do {
    try store.remove(target, span: ekSpan, commit: true)
} catch {
    fail("remove_failed", "EventKit refused the deletion: \(error.localizedDescription). Check Calendar before retrying.")
}
emit(["ok": true, "deleted": summary])
