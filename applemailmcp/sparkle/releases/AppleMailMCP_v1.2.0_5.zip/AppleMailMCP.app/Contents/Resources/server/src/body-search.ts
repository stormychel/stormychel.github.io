//
//  body-search.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 15/10/2026.
//
//  Full-text search over message bodies (#28, #30). Spotlight cannot answer
//  it: Mail indexes into a private CoreSpotlight index that mdfind does not
//  see, and the .emlx files carry no searchable metadata of their own. So the
//  envelope index narrows the candidates, newest first, and only those bodies
//  are read — a bounded scan that reports how far it got.
//

import type { ReadOnlyIndex } from "./db.ts";
import { DEFAULT_LIMIT, MAX_LIMIT } from "./db.ts";
import { resolveBodyFile } from "./emlx.ts";
import { clampLimit, LOCAL_ONLY_NOTE, NOT_FOUND_LOCALLY } from "./format.ts";
import { OPERATIONAL_CODES, parseRfc822 } from "./message.ts";
import { wrapIndexError } from "./schema.ts";
import { search, searchCandidates, toSearchRow, type RawRow, type SearchResult } from "./search.ts";
import type { BodyAvailability, MailStore, SearchQuery, SearchRow } from "./types.ts";

/**
 * Candidates whose bodies are read per call. On the store this was measured
 * on (3.6 GB over 30,023 files) the newest 2,000 came to 187 MB and scanned
 * in 6–10 s — seconds, not the 140 s a whole-store grep took — and they cover
 * months of mail before any date, sender or mailbox filter narrows them.
 */
export const MAX_BODY_SCAN = 2_000;

/**
 * Wall-clock ceiling on one scan. The candidate cap bounds the count, not the
 * size: a run of heavy messages can make 2,000 bodies far slower than the
 * measured case, and a tool call that takes minutes looks hung to its client.
 */
export const BODY_SCAN_BUDGET_MS = 20_000;

/**
 * Bodies parsed at once. mailparser yields to the event loop after every
 * line, so one parse at a time spends most of its wall time idle: 14 ms a
 * message on the real store, against 1.9 ms with sixteen in flight. Sixteen
 * open files and sixteen small text buffers is the whole cost.
 */
export const BODY_SCAN_CONCURRENCY = 16;

/**
 * Bytes of each message handed to the parser. Every .partial.emlx on the
 * measured store — Mail's text-only copies — is under 2 MB; the 212 full
 * messages over it (0.7%) are attachment-heavy, and their text parts come
 * first. Past this a message is searched in its first 2 MB and counted in
 * `bodyClipped`, so the bound is visible rather than silent.
 */
export const BODY_SCAN_MAX_BYTES = 2 * 1024 * 1024;

export type BodySearchQuery = SearchQuery & {
  /** Case-insensitive substring matched against the decoded body text. */
  body?: string;
};

export type BodySearchResult = SearchResult & {
  /** Candidates whose bodies were examined, matched or not. */
  scanned: number;
  /** True when the candidate cap or the time budget stopped the scan early. */
  scanTruncated: boolean;
  /** Which bound stopped it, when one did. */
  truncatedBy: "maxScan" | "timeBudget" | null;
  /**
   * True only when every candidate the filters selected was examined. Filling
   * the limit also stops the scan, so a zero or short result is the whole
   * answer only when this is true.
   */
  exhausted: boolean;
  /**
   * Scanned candidates with no body text on this Mac: no .emlx at all, or one
   * that could not be parsed. They are counted, never reported as non-matches.
   */
  bodyUnavailable: number;
  /**
   * Scanned candidates stored as .partial.emlx. Mail keeps the text parts
   * there and the attachments elsewhere, so these were searched; the count is
   * here because what was searched is not the complete message.
   */
  bodyPartial: number;
  /** Scanned bodies larger than BODY_SCAN_MAX_BYTES, searched in their first part only. */
  bodyClipped: number;
  maxScan: number;
};

/**
 * One entry point for search_mail and the CLI: a query without `body` is the
 * synchronous index search, unchanged.
 */
export async function searchMail(
  index: ReadOnlyIndex,
  query: BodySearchQuery = {},
  options: { store?: MailStore | null; maxScan?: number; timeBudgetMs?: number } = {},
): Promise<SearchResult | BodySearchResult> {
  const { body, ...indexQuery } = query;
  if (body === undefined || body.trim() === "") {
    return search(index, indexQuery, { store: options.store });
  }
  // A body scan returns no cursor, and whether the next one should follow the
  // matches or everything scanned has no answer that cannot skip mail. Refused
  // rather than guessed: poll with afterId, then search the new ids' bodies.
  if (indexQuery.afterId !== undefined) {
    throw new Error("body and afterId cannot be combined: poll with afterId first, then search those messages' bodies.");
  }
  return searchBodies(index, { ...indexQuery, body }, options);
}

export async function searchBodies(
  index: ReadOnlyIndex,
  query: BodySearchQuery & { body: string },
  options: { store?: MailStore | null; maxScan?: number; timeBudgetMs?: number } = {},
): Promise<BodySearchResult> {
  // Overridable so a test can reach both bounds with a seven-message fixture.
  const maxScan = Math.max(1, Math.floor(options.maxScan ?? MAX_BODY_SCAN));
  const budgetMs = options.timeBudgetMs ?? BODY_SCAN_BUDGET_MS;
  const store = options.store ?? null;
  const limit = clampLimit(query.limit, DEFAULT_LIMIT, MAX_LIMIT);
  const needle = fold(query.body);

  const { body: _body, ...indexQuery } = query;
  // One row past the cap, so "the cap was reached" and "the candidates ran out
  // exactly at the cap" are told apart rather than guessed.
  const candidates = searchCandidates(index, indexQuery, maxScan + 1);
  const started = performance.now();

  const scannable = Math.min(candidates.length, maxScan);
  const outcomes: (Outcome | undefined)[] = new Array(scannable);
  const messages: SearchRow[] = [];
  let scanned = 0;
  let bodyUnavailable = 0;
  let bodyPartial = 0;
  let bodyClipped = 0;
  let filledLimit = false;
  let nextToStart = 0;
  let fatal: unknown = null;

  // Outcomes land out of order; they are counted in candidate order, so the
  // matches are the newest ones and `scanned` is an unbroken prefix. Anything
  // that finished past the point the limit was met is read but not counted.
  const commit = () => {
    while (!filledLimit && scanned < scannable && outcomes[scanned] !== undefined) {
      const outcome = outcomes[scanned]!;
      const row = candidates[scanned];
      scanned++;
      if (outcome.kind === "unavailable") {
        bodyUnavailable++;
        continue;
      }
      if (outcome.status === "partial") {
        bodyPartial++;
      }
      if (outcome.clipped) {
        bodyClipped++;
      }
      if (outcome.match) {
        messages.push(toSearchRow(row, store, outcome.status));
        if (messages.length >= limit) {
          filledLimit = true;
        }
      }
    }
  };

  const worker = async () => {
    while (!filledLimit && fatal === null && nextToStart < scannable) {
      // The first candidate always runs, so a zero budget still says something.
      if (nextToStart > 0 && performance.now() - started >= budgetMs) {
        return;
      }
      const position = nextToStart++;
      try {
        outcomes[position] = await examine(candidates[position], store, needle);
      } catch (error) {
        fatal ??= error;
        return;
      }
      commit();
    }
  };
  await Promise.all(Array.from({ length: Math.min(BODY_SCAN_CONCURRENCY, Math.max(1, scannable)) }, worker));
  if (fatal !== null) {
    throw fatal;
  }

  let truncatedBy: BodySearchResult["truncatedBy"] = null;
  if (!filledLimit) {
    if (scanned < scannable) {
      truncatedBy = "timeBudget";
    } else if (candidates.length > maxScan) {
      truncatedBy = "maxScan";
    }
  }

  const exhausted = !filledLimit && truncatedBy === null;
  return {
    count: messages.length,
    limit,
    note: bodyNote(messages.length, {
      scanned,
      truncatedBy,
      exhausted,
      filledLimit,
      bodyUnavailable,
      bodyPartial,
      bodyClipped,
      maxScan,
      budgetMs,
    }),
    source: "local",
    snapshot: index.openedViaSnapshot,
    messages,
    scanned,
    scanTruncated: truncatedBy !== null,
    truncatedBy,
    exhausted,
    bodyUnavailable,
    bodyPartial,
    bodyClipped,
    maxScan,
  };
}

type Outcome =
  | { kind: "unavailable" }
  | { kind: "read"; status: BodyAvailability; match: boolean; clipped: boolean };

async function examine(row: RawRow, store: MailStore | null, needle: string): Promise<Outcome> {
  // The same containment-checked resolution get_message uses; a body that
  // resolves outside its account directory is unavailable here too.
  const resolved = store ? resolveBodyFile(store, row.id, row.mailbox) : { status: "unavailable" as const, path: null };
  if (!resolved.path) {
    return { kind: "unavailable" };
  }
  let parsed: Awaited<ReturnType<typeof parseRfc822>>;
  try {
    parsed = await parseRfc822(resolved.path, { textOnly: true, maxBytes: BODY_SCAN_MAX_BYTES });
  } catch (error) {
    // As in get_message: a permission or descriptor error is about the
    // process, and folding it into a count would turn one fault into
    // thousands of quietly unavailable bodies.
    if (OPERATIONAL_CODES.has((error as { code?: string }).code ?? "")) {
      throw wrapIndexError(error, `failed to read the body of message ${row.id}`);
    }
    return { kind: "unavailable" };
  }
  const match = parsed.text !== null && fold(parsed.text).includes(needle);
  return { kind: "read", status: resolved.status, match, clipped: parsed.clipped };
}

/**
 * Case-folded, NFC-normalised and whitespace-collapsed on both sides: "café"
 * typed composed must find a body that decoded to the decomposed form, the
 * same trap the mailbox filter fell into with "Envoyés"; and plain-text mail
 * is hard-wrapped at ~76 columns, so "tracking number" must still find
 * "tracking\nnumber" rather than reporting an exhausted, confident miss.
 * Lowercased before normalising, since lowercasing can itself produce a
 * decomposed sequence ("İ" becomes "i" + U+0307).
 */
export function fold(text: string): string {
  return text.toLowerCase().normalize("NFC").replace(/\s+/g, " ");
}

function bodyNote(
  count: number,
  scan: {
    scanned: number;
    truncatedBy: BodySearchResult["truncatedBy"];
    exhausted: boolean;
    filledLimit: boolean;
    bodyUnavailable: number;
    bodyPartial: number;
    bodyClipped: number;
    maxScan: number;
    budgetMs: number;
  },
): string {
  const parts: string[] = [];
  const noun = scan.scanned === 1 ? "message" : "messages";
  if (scan.exhausted) {
    parts.push(`Scanned the bodies of all ${scan.scanned} ${noun} the other filters selected.`);
  } else if (scan.filledLimit) {
    parts.push(`Scanned ${scan.scanned} ${noun}, newest first, and stopped at the limit; older messages were not checked.`);
  } else if (scan.truncatedBy === "maxScan") {
    parts.push(
      `Scanned only the newest ${scan.scanned} ${noun}: the scan stops at ${scan.maxScan}, so older messages were not ` +
        `checked. Narrow with after/before, mailbox or from to search further back.`,
    );
  } else {
    parts.push(
      `Scanned only the newest ${scan.scanned} ${noun} before the ${Math.round(scan.budgetMs / 1000)}s time budget ran ` +
        `out, so older messages were not checked. Narrow with after/before, mailbox or from to search further back.`,
    );
  }
  if (scan.bodyUnavailable > 0) {
    parts.push(`${scan.bodyUnavailable} had no readable body on this Mac and could not be searched.`);
  }
  if (scan.bodyPartial > 0) {
    parts.push(`${scan.bodyPartial} were partial downloads, text without attachments; their text was searched.`);
  }
  if (scan.bodyClipped > 0) {
    const mb = BODY_SCAN_MAX_BYTES / 1024 / 1024;
    parts.push(`${scan.bodyClipped} were larger than ${mb} MB and were searched in their first ${mb} MB only.`);
  }
  const summary = parts.join(" ");
  return count === 0 ? `${NOT_FOUND_LOCALLY}. ${summary}` : `${LOCAL_ONLY_NOTE} ${summary}`;
}
