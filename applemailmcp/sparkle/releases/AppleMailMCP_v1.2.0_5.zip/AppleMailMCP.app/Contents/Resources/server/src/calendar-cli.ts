#!/usr/bin/env node
//
//  calendar-cli.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 26/08/2026.
//

import { getEvent, listCalendars, searchEvents } from "./calendar/events.ts";
import { parseRangeBound } from "./calendar/format.ts";
import { openCalendarSession } from "./calendar/session.ts";
import { createEvent, writeEnabled, WRITE_ENV } from "./calendar/write.ts";

const USAGE = `Usage:
  applecal list-calendars [options]
  applecal search [options]
  applecal get --id <n> [options]
  applecal create --calendar <title> --title <text> --start <when> [options]
  applecal mcp

Reading is read-only: the live Calendar.sqlitedb is never opened by SQLite, it
is APFS-cloned to a temp snapshot first. Writing never touches SQLite at all —
it goes through Calendar.app, and only when ${WRITE_ENV}=1.

Options:
  --db <path>            Calendar.sqlitedb (skips live-store detection)
  --id <n>               CalendarItem.ROWID (get)
  --title <text>         Title substring (search) / event title (create)
  --notes <text>         Notes substring (search) / event notes (create)
  --calendar <text>      Calendar title substring (search) / exact title (create)
  --calendar-id <uuid>   Calendar uuid (create), for when two calendars share a title
  --from <date>          Range start (search). A bare date means that whole
                         day in local time; a timestamp is that instant
  --to <date>            Range end, inclusive (search). A bare date covers
                         through 23:59:59 that day — same date as --from is one day
  --limit <n>            Max rows (default 50, hard cap 1000)
  --start <when>         Local start, e.g. 2026-09-01T14:00 (create)
  --end <when>           Local end; defaults to +1h, or the same day if --all-day
  --all-day              Create an all-day event
  --location <text>      Event location (create)
  --url <text>           Event URL (create)
  --alarm <minutes>      Alarm this many minutes before the start (create)
  --dry-run              Resolve and print what would be created, write nothing
  --help                 Show this help
`;

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  if (args.length === 0 || args.includes("--help") || args.includes("-h")) {
    process.stdout.write(USAGE);
    process.exit(args.length === 0 ? 1 : 0);
  }

  const command = args[0];
  if (command.startsWith("-")) {
    fail(`missing command. ${USAGE}`);
  }

  if (command === "mcp") {
    const { startStdioServer } = await import("./calendar-server.ts");
    await startStdioServer();
    return;
  }

  const flags = parseFlags(args.slice(1));

  if (command === "create") {
    if (!flags.dryRun && !writeEnabled()) {
      fail(
        `writing is disabled. Set ${WRITE_ENV}=1 to allow it, or pass --dry-run to see what would be created.`,
      );
    }
    if (!flags.calendar && !flags.calendarId) {
      fail(
        "--calendar or --calendar-id is required for create (list-calendars shows both)",
      );
    }
    if (!flags.title) {
      fail("--title is required for create");
    }
    if (!flags.start) {
      fail("--start is required for create");
    }
    printJson(
      createEvent(
        {
          calendar: flags.calendar,
          calendarId: flags.calendarId,
          title: flags.title,
          start: flags.start,
          end: flags.end,
          allDay: flags.allDay,
          location: flags.location,
          notes: flags.notes,
          url: flags.url,
          alarmMinutesBefore: flags.alarm,
        },
        { dryRun: flags.dryRun === true },
      ),
    );
    return;
  }

  const session = openCalendarSession({ dbPath: flags.db });
  try {
    if (command === "list-calendars") {
      printJson(listCalendars(session.index));
      return;
    }
    if (command === "search") {
      printJson(
        searchEvents(session.index, {
          title: flags.title,
          notes: flags.notes,
          calendar: flags.calendar,
          from: flags.from ? parseRangeBound(flags.from, "from") : undefined,
          to: flags.to ? parseRangeBound(flags.to, "to") : undefined,
          limit: flags.limit,
        }),
      );
      return;
    }
    if (command === "get" || command === "get-event") {
      if (flags.id === undefined) {
        fail("--id is required for get");
      }
      printJson(getEvent(session.index, flags.id));
      return;
    }
    fail(`unknown command: ${command}\n${USAGE}`);
  } finally {
    session.close();
  }
}

type Flags = {
  db?: string;
  id?: number;
  title?: string;
  notes?: string;
  calendar?: string;
  calendarId?: string;
  from?: string;
  to?: string;
  limit?: number;
  start?: string;
  end?: string;
  allDay?: boolean;
  location?: string;
  url?: string;
  alarm?: number;
  dryRun?: boolean;
};

function parseFlags(argv: string[]): Flags {
  const flags: Flags = {};
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    const next = (): string => {
      const value = argv[i + 1];
      if (value === undefined) {
        fail(`missing value for ${arg}`);
      }
      i += 1;
      return value;
    };
    const nextNumber = (label: string): number => {
      const value = Number(next());
      if (!Number.isFinite(value)) {
        fail(`${label} must be a number`);
      }
      return value;
    };
    switch (arg) {
      case "--db":
        flags.db = next();
        break;
      case "--id":
        flags.id = nextNumber("--id");
        break;
      case "--title":
        flags.title = next();
        break;
      case "--notes":
        flags.notes = next();
        break;
      case "--calendar":
        flags.calendar = next();
        break;
      case "--calendar-id":
        flags.calendarId = next();
        break;
      case "--from":
        flags.from = next();
        break;
      case "--to":
        flags.to = next();
        break;
      case "--limit":
        flags.limit = nextNumber("--limit");
        break;
      case "--start":
        flags.start = next();
        break;
      case "--end":
        flags.end = next();
        break;
      case "--all-day":
        flags.allDay = true;
        break;
      case "--location":
        flags.location = next();
        break;
      case "--url":
        flags.url = next();
        break;
      case "--alarm":
        flags.alarm = nextNumber("--alarm");
        break;
      case "--dry-run":
        flags.dryRun = true;
        break;
      default:
        fail(`unknown option: ${arg}`);
    }
  }
  return flags;
}

function printJson(value: unknown): void {
  process.stdout.write(`${JSON.stringify(value, null, 2)}\n`);
}

function fail(message: string): never {
  process.stderr.write(`${message.trim()}\n`);
  process.exit(1);
}

try {
  await main();
} catch (error) {
  const message = error instanceof Error ? error.message : String(error);
  fail(message);
}
