#!/usr/bin/env node
//
//  calendar-server.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 26/08/2026.
//

import { basename } from "node:path";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { reportHealth } from "./health.ts";
import { calendarRootForHome, findCalendarStore } from "./calendar/store.ts";
import { getEvent, listCalendars, searchEvents } from "./calendar/events.ts";
import { parseRangeBound } from "./calendar/format.ts";
import { openCalendarSession, type CalendarSession } from "./calendar/session.ts";
import { createEvent, writeEnabled, WRITE_ENV } from "./calendar/write.ts";
import { DELETE_ENV, deleteEnabled, deleteEvent } from "./calendar/delete.ts";

export const MCP_DEFAULT_LIMIT = 20;
export const MCP_MAX_LIMIT = 50;

const READ_ONLY = {
  readOnlyHint: true,
  destructiveHint: false,
  idempotentHint: true,
  openWorldHint: false,
} as const;

const WRITES = {
  readOnlyHint: false,
  // Nothing existing is modified or removed — create_event only ever adds.
  destructiveHint: false,
  idempotentHint: false,
  openWorldHint: false,
} as const;

const DELETES = {
  readOnlyHint: false,
  // The first verb here that removes something, with no undo: Calendar keeps
  // no trash for events, and the deletion syncs to every device (#42).
  destructiveHint: true,
  idempotentHint: false,
  openWorldHint: false,
} as const;

const limitSchema = z.number().int().min(1).max(MCP_MAX_LIMIT).optional();

export function createCalendarServer(
  sessionFactory: () => CalendarSession = () => openCalendarSession(),
  options: { enableWrite?: boolean; enableDelete?: boolean; osascriptPath?: string; deleteHelperPath?: string } = {},
): McpServer {
  const server = new McpServer({
    name: "applecalendar",
    version: "0.3.0",
    title: "Apple Calendar",
  });

  const withSession = async (fn: (session: CalendarSession) => Promise<unknown> | unknown) => {
    let session: CalendarSession | null = null;
    try {
      session = sessionFactory();
      const result = await fn(session);
      return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
    } catch (error) {
      return errorEnvelope(error);
    } finally {
      session?.close();
    }
  };

  server.registerTool(
    "list_calendars",
    {
      title: "List Calendars",
      description:
        "Read-only list of calendars in the local Calendar store, with the account each belongs to. Use the exact titles from here when creating an event.",
      annotations: READ_ONLY,
    },
    async () => withSession((session) => listCalendars(session.index)),
  );

  server.registerTool(
    "search_events",
    {
      title: "Search Events",
      description:
        "Read-only search of the local Calendar store. Repeating events are expanded only inside Calendar's occurrence cache window, which is reported as occurrenceWindow — a range outside it comes back with a note saying repeats are not covered, not with a confident empty answer. All-day events return a plain date; timed events return an instant in UTC plus the event's own timeZone.",
      inputSchema: {
        title: z.string().optional().describe("Title substring"),
        notes: z.string().optional().describe("Notes/description substring"),
        calendar: z.string().optional().describe("Calendar title substring"),
        from: z
          .string()
          .optional()
          .describe("Range start. A bare date (2026-08-27) means that whole day in local time; a timestamp is used as the instant it names."),
        to: z
          .string()
          .optional()
          .describe("Range end, inclusive. A bare date covers through 23:59:59 that day in local time — pass the same date as from for a single day."),
        limit: limitSchema.describe(`Max rows (default ${MCP_DEFAULT_LIMIT}, cap ${MCP_MAX_LIMIT})`),
      },
      annotations: READ_ONLY,
    },
    async (args) =>
      withSession((session) =>
        searchEvents(session.index, {
          title: args.title,
          notes: args.notes,
          calendar: args.calendar,
          from: args.from ? parseRangeBound(args.from, "from") : undefined,
          to: args.to ? parseRangeBound(args.to, "to") : undefined,
          limit: args.limit ?? MCP_DEFAULT_LIMIT,
        }),
      ),
  );

  server.registerTool(
    "get_event",
    {
      title: "Get Event",
      description:
        "Read-only fetch of one event: notes, location, organizer, attendees, recurrence rule and alarms. Dates are the master item's, not a single occurrence's.",
      inputSchema: {
        id: z.number().int().positive().describe("CalendarItem.ROWID, as returned by search_events"),
      },
      annotations: READ_ONLY,
    },
    async (args) => withSession((session) => getEvent(session.index, args.id)),
  );

  // Registered, not merely refused: with the gate off the tool is absent from
  // tools/list, so a model cannot decide to try it.
  if (options.enableWrite ?? writeEnabled()) {
    server.registerTool(
      "create_event",
      {
        title: "Create Event",
        description:
          "Creates one event through Calendar.app. Times are local wall-clock on this Mac. Attendees are deliberately not supported — inviting people is not undoable from the recipients' side. Pass dryRun to see exactly what would be created without writing.",
        inputSchema: {
          calendar: z
            .string()
            .optional()
            .describe("Exact calendar title from list_calendars. Refused if two calendars share it. Use this or calendarId, not both."),
          calendarId: z
            .string()
            .optional()
            .describe("The calendar's uuid from list_calendars — use instead of calendar when titles collide"),
          title: z.string().describe("Event title"),
          start: z
            .string()
            .describe("Local start, e.g. 2026-09-01T14:00. A trailing Z or offset is converted to local time."),
          end: z.string().optional().describe("Local end. Defaults to one hour after start, or the same day when allDay."),
          allDay: z.boolean().optional(),
          location: z.string().optional(),
          notes: z.string().optional(),
          url: z.string().optional(),
          alarmMinutesBefore: z.number().int().min(0).max(40320).optional(),
          dryRun: z.boolean().optional().describe("Resolve and validate without creating anything"),
        },
        annotations: WRITES,
      },
      async (args) => {
        try {
          const result = createEvent(
            {
              calendar: args.calendar,
              calendarId: args.calendarId,
              title: args.title,
              start: args.start,
              end: args.end,
              allDay: args.allDay,
              location: args.location,
              notes: args.notes,
              url: args.url,
              alarmMinutesBefore: args.alarmMinutesBefore,
            },
            { dryRun: args.dryRun === true, osascriptPath: options.osascriptPath },
          );
          return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
        } catch (error) {
          return errorEnvelope(error);
        }
      },
    );
  }

  // Its own gate (#42): enabling create_event does not enable this.
  if (options.enableDelete ?? deleteEnabled()) {
    server.registerTool(
      "delete_event",
      {
        title: "Delete Event",
        description:
          "Deletes one event through EventKit. THERE IS NO UNDO: Calendar has no trash for events, and the " +
          "deletion syncs to iCloud and every device on the account. The event is named only by the uid " +
          "get_event or search_events returned. A repeating event needs span — occurrence (one, with its " +
          "date), future (that one and all later ones) or series (all of them); there is no default. Refused " +
          "for a meeting with attendees that you organise, since deleting it sends cancellations. Run dryRun " +
          "first to see exactly what would go.",
        inputSchema: {
          uid: z.string().describe("The event's uid from get_event or search_events — never a title or a date"),
          span: z
            .enum(["occurrence", "future", "series"])
            .optional()
            .describe("Required for a repeating event, refused for one that does not repeat"),
          occurrence: z
            .string()
            .optional()
            .describe("For span occurrence or future: that occurrence's start exactly as search_events prints it"),
          dryRun: z.boolean().optional().describe("Resolve and check against the local store, delete nothing"),
        },
        annotations: DELETES,
      },
      async (args) =>
        withSession((session) =>
          deleteEvent(
            session.index,
            { uid: args.uid, span: args.span, occurrence: args.occurrence },
            { dryRun: args.dryRun === true, helperPath: options.deleteHelperPath },
          ),
        ),
    );
  }

  return server;
}

function errorEnvelope(error: unknown) {
  const message = error instanceof Error ? error.message : String(error);
  return {
    isError: true,
    content: [{ type: "text" as const, text: JSON.stringify({ error: message }, null, 2) }],
  };
}

export async function startStdioServer(): Promise<void> {
  // Which app started this server, and whether its store opened under it (#99).
  reportHealth("calendar", () => findCalendarStore().dbPath, calendarRootForHome());
  const server = createCalendarServer();
  const transport = new StdioServerTransport();
  await server.connect(transport);
}

export { DELETE_ENV, WRITE_ENV };

const entry = basename(process.argv[1] ?? "");
if (entry === "calendar-server.ts" || entry === "calendar-server.js") {
  startStdioServer().catch((error) => {
    process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
    process.exit(1);
  });
}
