//
//  delete.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 21/10/2026.
//

import { switchEnabled, type SwitchName } from "../config.ts";
import { spawnSync } from "node:child_process";
import { existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import type { ReadOnlyIndex } from "../db.ts";
import { getEvent } from "./events.ts";
import { EVENT_ENTITY_TYPE } from "./schema.ts";

export const DELETE_ENV = "APPLECAL_ENABLE_DELETE" satisfies SwitchName;
export const DELETE_HELPER_ENV = "APPLECAL_DELETE_HELPER";

/**
 * Its own switch, not APPLECAL_ENABLE_WRITE (#42). That one was granted as
 * "may add an event"; reading it as "may also remove one" would widen it
 * after the fact, which is what a gate exists to stop.
 */
export function deleteEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
  return switchEnabled(DELETE_ENV, env);
}

/** Where helpers/calendar-delete/build.sh puts the helper by default. */
export const DEFAULT_DELETE_HELPER = fileURLToPath(
  new URL("../../helpers/calendar-delete/build/applecal-delete", import.meta.url),
);

/** As long as osascript's: the first run waits on the Calendars permission prompt. */
export const DELETE_TIMEOUT_MS = 660_000;

export type DeleteSpan = "occurrence" | "future" | "series";

export type DeleteRequest = {
  /** CalendarItem.UUID, as get_event and search_events return it. Nothing else selects an event. */
  uid: string;
  /** Required for a repeating event, refused for one that does not repeat. */
  span?: DeleteSpan;
  /** The occurrence's start as search_events prints it; required for span occurrence and future. */
  occurrence?: string;
};

export type DeleteEventResult = {
  deleted: boolean;
  dryRun: boolean;
  uid: string;
  title: string;
  calendar: string | null;
  start: string;
  recurring: boolean;
  span: DeleteSpan | "single";
  occurrence: string | null;
  note: string;
  /**
   * The start of what EventKit removed, as it reported it: the occurrence's
   * for span occurrence or future, where `start` is the series'.
   */
  removedStart?: string;
  /** Exactly what would be handed to the helper, so a dry run is inspectable. */
  arguments?: string[];
};

const DAY = /^\d{4}-\d{2}-\d{2}$/;
const INSTANT = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})$/;

/**
 * Deletes one event, one occurrence of one, or the rest of a series, through
 * EventKit (#42) — Calendar.app's AppleScript has no delete command.
 *
 * Everything is checked against the read path first, so a dry run and a real
 * run refuse the same things: an unknown or ambiguous uid, a repeating event
 * without a span, and a meeting the user organises, whose deletion would send
 * cancellations. The helper then checks again in EventKit, title and start
 * included, before it removes anything.
 */
export function deleteEvent(
  index: ReadOnlyIndex,
  request: DeleteRequest,
  options: { dryRun?: boolean; helperPath?: string; timeoutMs?: number; env?: NodeJS.ProcessEnv } = {},
): DeleteEventResult {
  const uid = request.uid?.trim();
  if (!uid) {
    throw new Error("uid is required — the uid get_event or search_events returned for the event");
  }
  const rows = index.all<{ id: number; orig_item_id: number | null; organizer_id: number | null }>(
    `SELECT ROWID AS id, orig_item_id, organizer_id FROM CalendarItem WHERE UUID = ? AND entity_type = ${EVENT_ENTITY_TYPE}`,
    [uid],
  );
  if (rows.length === 0) {
    throw new Error(`No event with uid ${uid} in the local Calendar store. Nothing was deleted.`);
  }
  if (rows.length > 1) {
    throw new Error(`${rows.length} events share uid ${uid}, so it does not name one. Nothing was deleted.`);
  }
  const [row] = rows;
  // A detached occurrence is a row of its own, but EventKit reaches it
  // through its series; deleting it by this uid is not something either side
  // has been checked to agree on.
  if (row.orig_item_id) {
    throw new Error(
      `Event ${uid} is a single changed occurrence of a repeating event. Delete it through the series' uid with ` +
        "span occurrence and the occurrence's date. Nothing was deleted.",
    );
  }

  const event = getEvent(index, row.id);
  if (!event.title) {
    throw new Error(`Event ${uid} has no title to check it by, so it is not deleted.`);
  }
  if (!event.start) {
    throw new Error(`Event ${uid} has no start to check it by, so it is not deleted.`);
  }
  if (event["has-attendees"] && wouldCancel(index, row.organizer_id)) {
    throw new Error(
      `Event ${uid} ("${event.title}") has attendees and you organise it, or its organiser is unknown: ` +
        "deleting it sends everyone a cancellation, which cannot be taken back. Delete it in Calendar if you mean it.",
    );
  }

  const recurring = event.recurring;
  if (recurring && !request.span) {
    throw new Error(
      `Event ${uid} ("${event.title}") repeats. Pass span: occurrence (one, with its date), future (that one and ` +
        "every later one) or series (all of them). There is no default.",
    );
  }
  if (!recurring && request.span) {
    throw new Error(`Event ${uid} does not repeat; leave span out. Nothing was deleted.`);
  }
  const span = request.span ?? "single";
  const occurrence = request.occurrence?.trim() || null;
  // future and series take the changed occurrences with them, and one of
  // those can be a meeting of its own. Which of them lie after a given date is
  // not known here, so for future every one counts.
  if (span === "future" || span === "series") {
    const changed = index.all<{ organizer_id: number | null }>(
      `SELECT organizer_id FROM CalendarItem WHERE orig_item_id = ? AND entity_type = ${EVENT_ENTITY_TYPE} AND has_attendees = 1`,
      [row.id],
    );
    if (changed.some((occ) => wouldCancel(index, occ.organizer_id))) {
      throw new Error(
        `A changed occurrence of ${uid} ("${event.title}") has attendees and you organise it, or its organiser is ` +
          `unknown: span ${span} would delete it and send cancellations. Nothing was deleted.`,
      );
    }
  }
  if (span === "occurrence" || span === "future") {
    if (!occurrence) {
      throw new Error(`span ${span} needs occurrence: that occurrence's start, as search_events prints it.`);
    }
  } else if (occurrence) {
    throw new Error(`occurrence only goes with span occurrence or future, not ${span}.`);
  }
  if (occurrence && !(event.allDay ? DAY : INSTANT).test(occurrence)) {
    throw new Error(
      `occurrence must be ${event.allDay ? "a date, YYYY-MM-DD, for an all-day event" : "an ISO-8601 instant, as search_events prints it"} (got ${occurrence}).`,
    );
  }

  const args = ["delete", "--uid", uid, "--title", event.title, "--start", event.start, "--span", span];
  if (occurrence) args.push("--occurrence", occurrence);

  const shared = {
    uid,
    title: event.title,
    calendar: event.calendar,
    start: event.start,
    recurring,
    span,
    occurrence,
  };

  if (options.dryRun) {
    return {
      ...shared,
      deleted: false,
      dryRun: true,
      note:
        "Dry run — nothing was deleted, and EventKit was not asked: whether the occurrence exists, and that the event " +
        "still matches, are only checked on a real run.",
      arguments: args,
    };
  }

  const env = options.env ?? process.env;
  const helper = options.helperPath ?? (env[DELETE_HELPER_ENV] || DEFAULT_DELETE_HELPER);
  if (!existsSync(helper)) {
    throw new Error(
      `The EventKit helper is not built (${helper}). Run helpers/calendar-delete/build.sh, or set ${DELETE_HELPER_ENV}. Nothing was deleted.`,
    );
  }
  const answer = runHelper(helper, args, options.timeoutMs ?? DELETE_TIMEOUT_MS);
  return {
    ...shared,
    deleted: true,
    dryRun: false,
    note:
      span === "single"
        ? "Deleted. There is no undo: Calendar has no trash for events, and the deletion syncs to every device on the account."
        : `Deleted (${span}). There is no undo: Calendar has no trash for events, and the deletion syncs to every device on the account.`,
    removedStart: answer.start,
  };
}

/**
 * Whether deleting an item with attendees would send cancellations: it does
 * when the user organises it, and an organiser the index cannot name is
 * treated the same rather than assumed to be someone else.
 */
function wouldCancel(index: ReadOnlyIndex, organizerId: number | null): boolean {
  if (!organizerId) return true;
  const organiser = index.get<{ is_self: number | null }>(`SELECT is_self FROM Participant WHERE ROWID = ?`, [organizerId]);
  return !organiser || organiser.is_self === 1;
}

/** spawn errors that mean the helper process never ran. */
const LAUNCH_FAILURES = new Set(["ENOENT", "EACCES", "ENOEXEC", "EPERM", "ENOTDIR"]);

type HelperAnswer ={ title: string; calendar: string; start: string; span: string };

/**
 * The helper answers one JSON object. Anything else — a crash, a timeout,
 * output that does not parse — leaves the outcome unknown, and is reported
 * that way rather than as a failure that invites a retry.
 */
function runHelper(helper: string, args: string[], timeoutMs: number): HelperAnswer {
  const result = spawnSync(helper, args, { encoding: "utf8", timeout: timeoutMs });
  const unknown = (why: string) =>
    new Error(`${why}, so whether the event was deleted is unknown. Check Calendar before retrying.`);
  if (result.error) {
    const code = (result.error as NodeJS.ErrnoException).code ?? "";
    // Only a helper that never started can be said to have done nothing. A
    // timeout or an output overflow comes after it was running, and possibly
    // after it deleted.
    if (LAUNCH_FAILURES.has(code)) {
      throw new Error(`Could not run the EventKit helper: ${result.error.message}. Nothing was deleted.`);
    }
    throw unknown(
      code === "ETIMEDOUT" ? "The EventKit helper did not answer in time" : `The EventKit helper failed (${result.error.message})`,
    );
  }
  let parsed: unknown;
  try {
    parsed = JSON.parse((result.stdout ?? "").trim());
  } catch {
    throw unknown(`The EventKit helper gave an unreadable answer (${JSON.stringify((result.stdout ?? "").trim() || result.stderr)})`);
  }
  if (typeof parsed !== "object" || parsed === null) {
    throw unknown("The EventKit helper gave an unreadable answer");
  }
  const answer = parsed as { ok?: unknown; error?: unknown; deleted?: Record<string, unknown> };
  if (answer.ok === false && typeof answer.error === "string" && result.status !== 0) {
    // The helper's own refusals all say whether anything changed.
    throw new Error(answer.error);
  }
  const deleted = answer.deleted;
  if (
    answer.ok !== true ||
    result.status !== 0 ||
    !deleted ||
    typeof deleted.title !== "string" ||
    typeof deleted.start !== "string" ||
    typeof deleted.calendar !== "string" ||
    typeof deleted.span !== "string"
  ) {
    throw unknown(`The EventKit helper gave an unexpected answer (${JSON.stringify(parsed)})`);
  }
  return deleted as HelperAnswer;
}
