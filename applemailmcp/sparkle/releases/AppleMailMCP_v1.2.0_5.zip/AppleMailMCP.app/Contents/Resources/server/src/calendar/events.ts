//
//  events.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 26/08/2026.
//

import { DEFAULT_LIMIT, MAX_LIMIT, type ReadOnlyIndex } from "../db.ts";
import { clampLimit, likeContains } from "../format.ts";
import {
  appleToDisplay,
  LOCAL_ONLY_NOTE,
  NOT_FOUND_LOCALLY,
} from "./format.ts";
import { EVENT_ENTITY_TYPE, readNumericProperty, readProperty } from "./schema.ts";
import type {
  AlarmRow,
  AttendeeRow,
  CalendarRow,
  EventDetail,
  EventQuery,
  EventRow,
  RecurrenceRow,
} from "./types.ts";

export type CalendarListResult = {
  count: number;
  source: "local";
  snapshot: boolean;
  calendars: CalendarRow[];
};

export type EventSearchResult = {
  count: number;
  limit: number;
  note: string;
  notes?: string[];
  occurrenceWindow: { start: string | null; end: string | null; timeZone: string | null };
  source: "local";
  snapshot: boolean;
  events: EventRow[];
};

/** Columns shared by the direct-item and occurrence-cache queries. */
const EVENT_COLUMNS = `
  ci.ROWID AS id,
  ci.UUID AS uid,
  ci.summary AS title,
  ci.all_day AS all_day,
  ci.start_tz AS start_tz,
  ci.calendar_id AS calendar_id,
  cal.title AS calendar_title,
  loc.title AS location_title,
  ci.has_recurrences AS has_recurrences,
  ci.has_attendees AS has_attendees,
  ci.has_attachment AS has_attachment,
  ci.status AS status,
  ci.url AS url,
  ci.conference_url AS conference_url`;

type RawEvent = {
  id: number;
  uid: string | null;
  title: string | null;
  all_day: number | null;
  start_tz: string | null;
  calendar_id: number;
  calendar_title: string | null;
  location_title: string | null;
  has_recurrences: number | null;
  has_attendees: number | null;
  has_attachment: number | null;
  status: number | null;
  url: string | null;
  conference_url: string | null;
  start_date: number | null;
  end_date: number | null;
  from_cache: number;
};

export function listCalendars(index: ReadOnlyIndex): CalendarListResult {
  const rows = index.all<{
    id: number;
    title: string | null;
    color: string | null;
    uuid: string | null;
    notes: string | null;
    account: string | null;
    account_type: number | null;
  }>(`
    SELECT
      cal.ROWID AS id,
      cal.title AS title,
      cal.symbolic_color_name AS color,
      cal.UUID AS uuid,
      cal.notes AS notes,
      st.name AS account,
      st.type AS account_type
    FROM Calendar cal
    LEFT JOIN Store st ON st.ROWID = cal.store_id
    ORDER BY st.name, cal.title
  `);

  return {
    count: rows.length,
    source: "local",
    snapshot: index.openedViaSnapshot,
    calendars: rows.map((row) => ({
      id: row.id,
      title: row.title,
      // Calendar.type is NULL for every calendar on the machines checked, so
      // the account row is what actually distinguishes iCloud from local from
      // subscribed. The raw Store.type is passed through rather than mapped to
      // a label we would be inventing.
      type: null,
      account: row.account,
      accountType: row.account_type === null ? null : String(row.account_type),
      color: row.color,
      uuid: row.uuid,
      notes: row.notes,
    })),
  };
}

/**
 * How many rows each half may return before deduplication. It cannot be the
 * caller's limit: a multi-day event has one cache row per day and they all
 * collapse into a single occurrence, so a limit of 2 spent on one three-day
 * event would report one event and hide everything after it. The budget is
 * still bounded — nothing here can scan a whole store — and a query that
 * exhausts it says so rather than quietly returning a short list.
 */
const SCAN_CEILING = 2_000;

function scanBudget(limit: number): number {
  return Math.min(Math.max(limit * 4, limit + 64), SCAN_CEILING);
}

export function searchEvents(index: ReadOnlyIndex, query: EventQuery = {}): EventSearchResult {
  const limit = clampLimit(query.limit, DEFAULT_LIMIT, MAX_LIMIT);
  const budget = scanBudget(limit);
  const cacheStart = readNumericProperty(index, "OccurrenceCacheStart");
  const cacheEnd = readNumericProperty(index, "OccurrenceCacheEnd");

  const fromCache = index.all<RawEvent>(...occurrenceSql(query, budget));
  const fromItems = index.all<RawEvent>(...directSql(query, budget));
  const cacheZone = readProperty(index, "OccurrenceCacheTimeZone");

  const merged = new Map<string, EventRow>();
  for (const row of [...fromCache, ...fromItems]) {
    const event = toEventRow(row, cacheZone);
    // One event can arrive from both halves — a non-recurring event inside the
    // cache window is in OccurrenceCache and in CalendarItem. Same id and same
    // start means same occurrence.
    const key = `${event.id}@${event.start ?? "?"}`;
    if (!merged.has(key)) {
      merged.set(key, event);
    }
  }

  const events = [...merged.values()]
    .sort((a, b) => (a.start ?? "").localeCompare(b.start ?? "") || a.id - b.id)
    .slice(0, limit);

  const caveats = coverageNotes(query, cacheStart, cacheEnd);
  if (fromCache.length >= budget || fromItems.length >= budget) {
    caveats.push(
      `More than ${budget} rows matched, so this list may be missing events. Narrow the date range.`,
    );
  }
  return {
    count: events.length,
    limit,
    note: events.length === 0 ? NOT_FOUND_LOCALLY : LOCAL_ONLY_NOTE,
    ...(caveats.length > 0 ? { notes: caveats } : {}),
    occurrenceWindow: {
      start: appleToDisplay(cacheStart, false),
      end: appleToDisplay(cacheEnd, false),
      timeZone: cacheZone,
    },
    source: "local",
    snapshot: index.openedViaSnapshot,
    events,
  };
}

/**
 * Recurring events are only expanded between OccurrenceCacheStart and
 * OccurrenceCacheEnd — roughly a couple of years either side of today on the
 * store checked. Outside that window the cache is empty and the masters are
 * deliberately not returned at their original date, because reporting a weekly
 * meeting once, on the day it started in 2019, is worse than saying the range
 * is not covered. Saying so is the whole point.
 */
function coverageNotes(
  query: EventQuery,
  cacheStart: number | null,
  cacheEnd: number | null,
): string[] {
  if (cacheStart === null || cacheEnd === null) {
    return [
      "Calendar's occurrence cache window is unknown, so repeating events may be missing.",
    ];
  }
  const notes: string[] = [];
  // An absent bound is an unbounded one, so it reaches outside the window by
  // definition. Treating "no `to`" as covered is how an open-ended search
  // silently drops every later repeat.
  if (query.from === undefined || query.from < cacheStart) {
    notes.push(
      `Repeating events are only expanded from ${appleToDisplay(cacheStart, false)}; earlier repeats are not included.`,
    );
  }
  if (query.to === undefined || query.to > cacheEnd) {
    notes.push(
      `Repeating events are only expanded to ${appleToDisplay(cacheEnd, false)}; later repeats are not included.`,
    );
  }
  return notes;
}

/**
 * `occurrence_start_date` is NULL for 3,727 of the 4,108 cache rows on the
 * store checked, and reading it as the occurrence start drops 90% of the cache
 * on the floor — silently, because a comparison against NULL is not an error.
 *
 * What the columns actually mean, verified against real rows rather than
 * assumed: `occurrence_date` is the occurrence's start, and it matches the
 * master's `start_date` exactly for a single-day non-repeating event.
 * `occurrence_start_date` is only filled in when the two differ — a multi-day
 * event has one cache row per day, each carrying that day in
 * `occurrence_date` and the event's true start in `occurrence_start_date`
 * (379 of the 381 filled-in rows span more than a day). So the start is the
 * first non-null of the two, which also collapses a multi-day event's per-day
 * rows onto one occurrence once they are deduplicated.
 */
const OCCURRENCE_START = "IFNULL(oc.occurrence_start_date, oc.occurrence_date)";
const OCCURRENCE_END = `IFNULL(oc.occurrence_end_date, ${OCCURRENCE_START})`;

function occurrenceSql(query: EventQuery, limit: number): [string, unknown[]] {
  const { where, params } = commonFilters(query);
  if (query.to !== undefined) {
    where.push(`${OCCURRENCE_START} <= ?`);
    params.push(query.to);
  }
  if (query.from !== undefined) {
    where.push(`${OCCURRENCE_END} >= ?`);
    params.push(query.from);
  }
  params.push(limit);
  return [
    `
    SELECT ${EVENT_COLUMNS},
      ${OCCURRENCE_START} AS start_date,
      ${OCCURRENCE_END} AS end_date,
      1 AS from_cache
    FROM OccurrenceCache oc
    JOIN CalendarItem ci ON ci.ROWID = oc.event_id
    LEFT JOIN Calendar cal ON cal.ROWID = ci.calendar_id
    LEFT JOIN Location loc ON loc.ROWID = ci.location_id
    WHERE ${where.join(" AND ")}
    ORDER BY ${OCCURRENCE_START}
    LIMIT ?
  `,
    params,
  ];
}

/**
 * The cache holds only what falls inside its window, and only ~a fifth of the
 * items on the store checked. Non-recurring events outside the window — last
 * year's meeting, next decade's flight — are still in CalendarItem, so they are
 * queried directly. Recurring masters are excluded here on purpose; see
 * coverageNotes.
 */
function directSql(query: EventQuery, limit: number): [string, unknown[]] {
  const { where, params } = commonFilters(query);
  where.push("IFNULL(ci.has_recurrences, 0) = 0");
  if (query.to !== undefined) {
    where.push("ci.start_date <= ?");
    params.push(query.to);
  }
  if (query.from !== undefined) {
    where.push("IFNULL(ci.end_date, ci.start_date) >= ?");
    params.push(query.from);
  }
  params.push(limit);
  return [
    `
    SELECT ${EVENT_COLUMNS},
      ci.start_date AS start_date,
      ci.end_date AS end_date,
      0 AS from_cache
    FROM CalendarItem ci
    LEFT JOIN Calendar cal ON cal.ROWID = ci.calendar_id
    LEFT JOIN Location loc ON loc.ROWID = ci.location_id
    WHERE ${where.join(" AND ")}
    ORDER BY ci.start_date
    LIMIT ?
  `,
    params,
  ];
}

function commonFilters(query: EventQuery): { where: string[]; params: unknown[] } {
  const where: string[] = [
    `ci.entity_type = ${EVENT_ENTITY_TYPE}`,
    "IFNULL(ci.hidden, 0) = 0",
  ];
  const params: unknown[] = [];
  if (query.title) {
    where.push("ci.summary LIKE ? ESCAPE '#'");
    params.push(likeContains(query.title));
  }
  if (query.notes) {
    where.push("ci.description LIKE ? ESCAPE '#'");
    params.push(likeContains(query.notes));
  }
  if (query.calendar) {
    where.push("cal.title LIKE ? ESCAPE '#'");
    params.push(likeContains(query.calendar));
  }
  return { where, params };
}

/**
 * An all-day date is anchored to UTC midnight in CalendarItem and to local
 * midnight in OccurrenceCache, so which zone renders it depends on where the
 * row came from. Getting this wrong reports every cached all-day event a day
 * early east of Greenwich, and a day late west of it.
 */
function toEventRow(row: RawEvent, cacheZone: string | null): EventRow {
  const allDay = row.all_day === 1;
  const zone = row.from_cache === 1 ? cacheZone ?? "UTC" : "UTC";
  return {
    id: row.id,
    uid: row.uid,
    calendar: row.calendar_title,
    calendarId: row.calendar_id,
    title: row.title,
    start: appleToDisplay(row.start_date, allDay, zone),
    end: appleToDisplay(row.end_date, allDay, zone),
    allDay,
    timeZone: row.start_tz,
    location: row.location_title,
    recurring: row.has_recurrences === 1,
    occurrence: row.from_cache === 1,
    status: row.status,
    url: row.url,
    conferenceUrl: row.conference_url,
    "has-attendees": row.has_attendees === 1,
    "has-attachments": row.has_attachment === 1,
  };
}

export function getEvent(index: ReadOnlyIndex, id: number): EventDetail {
  const row = index.get<
    RawEvent & {
      description: string | null;
      hidden: number | null;
      creation_date: number | null;
      last_modified: number | null;
      organizer_id: number | null;
    }
  >(
    `
    SELECT ${EVENT_COLUMNS},
      ci.start_date AS start_date,
      ci.end_date AS end_date,
      0 AS from_cache,
      ci.description AS description,
      ci.hidden AS hidden,
      ci.creation_date AS creation_date,
      ci.last_modified AS last_modified,
      ci.organizer_id AS organizer_id
    FROM CalendarItem ci
    LEFT JOIN Calendar cal ON cal.ROWID = ci.calendar_id
    LEFT JOIN Location loc ON loc.ROWID = ci.location_id
    WHERE ci.ROWID = ? AND ci.entity_type = ${EVENT_ENTITY_TYPE}
  `,
    [id],
  );

  if (!row) {
    throw new Error(`Event ${id} ${NOT_FOUND_LOCALLY}.`);
  }

  const base = toEventRow(row, null);
  delete base.occurrence;
  return {
    ...base,
    // search_events filters hidden items out; a lookup by ROWID still returns
    // one, because it exists and claiming otherwise would be a lie. Saying so
    // is the difference.
    hidden: row.hidden === 1,
    notes: row.description,
    organizer: organizerFor(index, row.organizer_id),
    attendees: attendeesFor(index, id),
    recurrence: recurrenceFor(index, id),
    alarms: alarmsFor(index, id),
    created: appleToDisplay(row.creation_date, false),
    lastModified: appleToDisplay(row.last_modified, false),
  };
}

function organizerFor(index: ReadOnlyIndex, organizerId: number | null): string | null {
  if (organizerId === null || organizerId === undefined) {
    return null;
  }
  const row = index.get<{ display_name: string | null; email: string | null }>(
    `
    SELECT idn.display_name AS display_name, p.email AS email
    FROM Participant p
    LEFT JOIN Identity idn ON idn.rowid = p.identity_id
    WHERE p.ROWID = ?
  `,
    [organizerId],
  );
  if (!row) {
    return null;
  }
  return formatParticipant(row.display_name, row.email);
}

function attendeesFor(index: ReadOnlyIndex, id: number): AttendeeRow[] {
  const rows = index.all<{
    display_name: string | null;
    email: string | null;
    address: string | null;
    status: number | null;
    role: number | null;
    is_self: number | null;
  }>(
    `
    SELECT
      idn.display_name AS display_name,
      p.email AS email,
      idn.address AS address,
      p.status AS status,
      p.role AS role,
      p.is_self AS is_self
    FROM Participant p
    LEFT JOIN Identity idn ON idn.rowid = p.identity_id
    WHERE p.owner_id = ?
    ORDER BY p.ROWID
  `,
    [id],
  );
  return rows.map((row) => ({
    name: row.display_name,
    email: row.email ?? row.address,
    status: row.status,
    role: row.role,
    isSelf: row.is_self === 1,
  }));
}

function recurrenceFor(index: ReadOnlyIndex, id: number): RecurrenceRow | null {
  const row = index.get<{
    frequency: number | null;
    interval: number | null;
    count: number | null;
    end_date: number | null;
    specifier: string | null;
  }>(
    `
    SELECT frequency, interval, count, end_date, specifier
    FROM Recurrence
    WHERE owner_id = ?
    LIMIT 1
  `,
    [id],
  );
  if (!row) {
    return null;
  }
  return {
    frequency: row.frequency,
    interval: row.interval,
    count: row.count,
    end: appleToDisplay(row.end_date, false),
    specifier: row.specifier === null ? null : String(row.specifier),
  };
}

function alarmsFor(index: ReadOnlyIndex, id: number): AlarmRow[] {
  const rows = index.all<{
    trigger_date: number | null;
    trigger_interval: number | null;
    type: number | null;
  }>(
    `
    SELECT trigger_date, trigger_interval, type
    FROM Alarm
    WHERE calendaritem_owner_id = ? AND IFNULL(disabled, 0) = 0
    ORDER BY ROWID
  `,
    [id],
  );
  return rows.map((row) => ({
    triggerDate: appleToDisplay(row.trigger_date, false),
    triggerInterval: row.trigger_interval,
    type: row.type,
  }));
}

function formatParticipant(name: string | null, email: string | null): string | null {
  const trimmedName = name?.trim() || "";
  const trimmedEmail = email?.trim() || "";
  if (trimmedName && trimmedEmail) {
    return `${trimmedName} <${trimmedEmail}>`;
  }
  return trimmedName || trimmedEmail || null;
}
