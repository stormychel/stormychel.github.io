//
//  format.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 26/08/2026.
//

import { epochToIso, parseDateInput } from "../format.ts";

/**
 * Calendar.sqlitedb stores dates as Core Data reference-date seconds — seconds
 * since 2001-01-01T00:00:00Z — as REAL, not as unix epochs. Mail's columns are
 * unix seconds, so nothing in ../format.ts can be pointed at these columns
 * without this offset.
 */
export const APPLE_EPOCH_OFFSET = 978_307_200;

/** Timezone Calendar writes for an all-day (date-only, unanchored) event. */
export const FLOATING_TZ = "_float";

export function appleToUnix(value: number | null | undefined): number | null {
  if (value === null || value === undefined || !Number.isFinite(value)) {
    return null;
  }
  return value + APPLE_EPOCH_OFFSET;
}

export function unixToApple(value: number): number {
  return value - APPLE_EPOCH_OFFSET;
}

/**
 * All-day events are stored floating, and which midnight they are anchored to
 * depends on the table they came out of:
 *
 * - `CalendarItem` anchors them to **UTC** midnight. All 742 all-day rows on
 *   the store checked carry `start_tz = '_float'` and a value exactly divisible
 *   by 86400.
 * - `OccurrenceCache` anchors them to **local** midnight in
 *   `OccurrenceCacheTimeZone`. Every all-day row there sits at 79200 or 82800
 *   seconds past a UTC midnight — 86400 less two hours or one, which is
 *   Brussels in summer and in winter.
 *
 * A birthday on 28 August is `1604-08-28 00:00:00` UTC in the item table and
 * `2026-08-27 22:00:00` UTC in the cache. Both mean the 28th. Reading the
 * second as UTC reports the 27th, which is how an all-day event ends up a day
 * early for everyone east of Greenwich — so the zone a value is anchored to has
 * to travel with it.
 *
 * The end is inclusive in both, so truncating it to a date is right rather than
 * off by one: a single-day all-day event measures 86,399 seconds, ending at
 * 23:59:59 on its own day rather than at midnight on the next.
 */
export function appleToDisplay(
  value: number | null | undefined,
  allDay: boolean,
  zone: string = "UTC",
): string | null {
  const unix = appleToUnix(value);
  if (unix === null) {
    return null;
  }
  if (!allDay) {
    return epochToIso(unix);
  }
  return calendarDateIn(new Date(unix * 1000), zone);
}

/**
 * The calendar date this instant falls on in `zone`. `en-CA` because it formats
 * as YYYY-MM-DD; an unusable zone falls back to UTC rather than throwing, since
 * the caller can sanity-check a date but cannot see a thrown one at all.
 */
function calendarDateIn(date: Date, zone: string): string | null {
  if (Number.isNaN(date.getTime())) {
    return null;
  }
  for (const timeZone of [zone, "UTC"]) {
    try {
      return new Intl.DateTimeFormat("en-CA", {
        timeZone,
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
      }).format(date);
    } catch {
      // Fall through to UTC.
    }
  }
  return date.toISOString().slice(0, 10);
}

/**
 * Parses a query bound into Apple reference-date seconds. Accepts everything
 * the mail CLI accepts (ISO-8601, YYYYMMDD, unix epoch) so the two halves of
 * the project take dates the same way.
 */
export function parseAppleDateInput(value: string): number {
  return unixToApple(parseDateInput(value));
}

const BARE_DATE = /^(\d{4})-(\d{2})-(\d{2})$/;
const COMPACT_DATE = /^(\d{4})(\d{2})(\d{2})$/;

/**
 * A search bound. A bare date means the **whole of that day in local time**:
 * `--from 2026-08-27 --to 2026-08-27` is that Thursday, midnight to 23:59:59.
 *
 * Reading a bare date as an instant at UTC midnight is wrong at both ends. As
 * an upper bound it truncates the day — `--to 2026-09-30` dropped everything
 * after 02:00 local on the 30th. And because the occurrence cache anchors an
 * all-day event to local midnight, an upper bound at the next day's midnight
 * pulled *tomorrow's* all-day events into today: asking for 27 August returned
 * two birthdays that belong to the 28th, because their stored start is exactly
 * that boundary.
 *
 * A value carrying a time is used as the instant it names.
 */
export function parseRangeBound(value: string, edge: "from" | "to"): number {
  const trimmed = value.trim();
  const match = BARE_DATE.exec(trimmed) ?? COMPACT_DATE.exec(trimmed);
  if (!match) {
    return parseAppleDateInput(trimmed);
  }

  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const bound =
    edge === "from"
      ? new Date(year, month - 1, day, 0, 0, 0, 0)
      : new Date(year, month - 1, day, 23, 59, 59, 0);
  bound.setFullYear(year);
  if (
    Number.isNaN(bound.getTime()) ||
    bound.getFullYear() !== year ||
    bound.getMonth() + 1 !== month ||
    bound.getDate() !== day
  ) {
    throw new Error(`Invalid date: ${value} (no such day)`);
  }
  return unixToApple(Math.floor(bound.getTime() / 1000));
}

/**
 * Wall-clock components in the machine's local timezone. AppleScript builds a
 * date by assigning components, which is locale-proof in a way that handing it
 * a formatted string is not.
 */
export type LocalParts = {
  year: number;
  month: number;
  day: number;
  hours: number;
  minutes: number;
};

/**
 * A datetime with no offset means local wall-clock time — that is what a
 * person means by "3pm on Tuesday", and what Calendar will store. A value
 * carrying `Z` or an explicit offset is converted into local components, so
 * both spellings land on the same instant.
 */
/** Bare wall-clock: 2026-09-01, 2026-09-01T14:00, optionally with seconds. */
const LOCAL_SPEC = /^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2})(\.\d+)?)?)?$/;

/** The same, carrying Z or an explicit offset, so it names an instant. */
const ABSOLUTE_SPEC =
  /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2})(\.\d+)?)?(?:Z|[+-]\d{2}:?\d{2})$/i;

const DAYS_IN_MONTH = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

/**
 * A datetime with no offset means local wall-clock time — that is what a
 * person means by "3pm on Tuesday", and what Calendar will store. A value
 * carrying `Z` or an explicit offset is converted into local components, so
 * both spellings land on the same instant.
 *
 * Only these two shapes are accepted. Anything else `Date` would take, it takes
 * by guessing: `2026-2-29` and `2026/02/29` both parse through the legacy
 * parser and roll forward to 1 March, and `+010000-01-01T00:00Z` yields a
 * five-digit year that no fixed-width format can carry. Rejecting the input is
 * the only answer that cannot create the wrong event.
 */
export function parseLocalDateTime(value: string): LocalParts {
  const trimmed = value.trim();
  const local = LOCAL_SPEC.exec(trimmed);
  const absolute = local ? null : ABSOLUTE_SPEC.exec(trimmed);
  const matched = local ?? absolute;

  if (!matched) {
    throw new Error(
      `Invalid date-time: ${value} (use 2026-09-01T14:00 for local time, or 2026-09-01T12:00Z)`,
    );
  }

  const typed = {
    year: Number(matched[1]),
    month: Number(matched[2]),
    day: Number(matched[3]),
    hours: Number(matched[4] ?? "0"),
    minutes: Number(matched[5] ?? "0"),
  };
  // Checked on the digits themselves, before any Date is built. An offset moves
  // the components, so comparing the result against what was typed only works
  // for the bare form — but 31 February is not a date in any timezone, and
  // `new Date("2026-02-29T12:00Z")` silently answers 1 March.
  assertRealDate(typed, value);
  assertOnTheMinute(matched[6], matched[7], value);

  let parts: LocalParts;
  if (local) {
    const built = localPartsToDate(typed);
    if (Number.isNaN(built.getTime())) {
      throw new Error(`Invalid date: ${value}`);
    }
    parts = partsOf(built);
    // `Date` rolls a nonexistent local time forward: 2026-03-29T02:30 in
    // Brussels becomes 03:30. Creating a different event from the one asked for
    // is exactly the confident-wrong-answer failure this project refuses.
    if (typed.hours !== parts.hours || typed.minutes !== parts.minutes) {
      throw new Error(
        `${value} does not exist in this Mac's timezone — the clocks skip over it. Pick a time outside the daylight-saving gap.`,
      );
    }
  } else {
    const parsed = new Date(trimmed);
    if (Number.isNaN(parsed.getTime())) {
      throw new Error(`Invalid date-time: ${value}`);
    }
    parts = partsOf(parsed);
  }

  if (parts.year < 1 || parts.year > 9999) {
    throw new Error(`Year out of range: ${value} (1 to 9999)`);
  }
  // A repeated wall-clock time cannot be expressed as components: AppleScript
  // would pick one of the two instants and there is no way to say which was
  // meant. It also makes ordering two endpoints ambiguous.
  if (isAmbiguousLocal(parts)) {
    throw new Error(
      `${value} is ambiguous on this Mac — the clocks repeat that time, so it happens twice. Pick a time outside the daylight-saving overlap.`,
    );
  }
  return parts;
}

function assertRealDate(typed: LocalParts, value: string): void {
  const leap =
    typed.year % 4 === 0 && (typed.year % 100 !== 0 || typed.year % 400 === 0);
  const days =
    typed.month === 2 && leap ? 29 : DAYS_IN_MONTH[typed.month - 1] ?? 0;
  if (typed.month < 1 || typed.month > 12 || typed.day < 1 || typed.day > days) {
    throw new Error(`Invalid date: ${value} (no such day)`);
  }
  if (typed.hours > 23 || typed.minutes > 59) {
    throw new Error(`Invalid time: ${value}`);
  }
}

/**
 * Calendar events are created on the minute — the AppleScript sets seconds to
 * zero — so a request carrying seconds would be honoured as something other
 * than what was asked. A literal `:00` is the same instant and is allowed.
 */
function assertOnTheMinute(
  seconds: string | undefined,
  fraction: string | undefined,
  value: string,
): void {
  const hasSeconds = seconds !== undefined && Number(seconds) !== 0;
  const hasFraction = fraction !== undefined && Number(fraction) !== 0;
  if (hasSeconds || hasFraction) {
    throw new Error(
      `${value} is not on the minute. Calendar events are created to the minute, so drop the seconds.`,
    );
  }
}

function partsOf(date: Date): LocalParts {
  return {
    year: date.getFullYear(),
    month: date.getMonth() + 1,
    day: date.getDate(),
    hours: date.getHours(),
    minutes: date.getMinutes(),
  };
}

/**
 * The instant these wall-clock components name on this Mac. `setFullYear` is
 * not optional: `new Date(26, 0, 1)` means 1926, so every year below 100 would
 * otherwise land in the twentieth century.
 */
export function localPartsToDate(parts: LocalParts): Date {
  const date = new Date(parts.year, parts.month - 1, parts.day, parts.hours, parts.minutes);
  date.setFullYear(parts.year);
  return date;
}

/**
 * A wall-clock time inside a fall-back overlap occurs twice, and there is no
 * way to say which instant was meant in components alone.
 *
 * The transition's size is measured rather than assumed: the UTC offset twelve
 * hours either side is compared, and if it moved, the local clock is stepped by
 * exactly that much. Probing fixed amounts would only ever cover the zones
 * thought of — an hour misses Lord Howe Island's thirty minutes, and thirty and
 * sixty both miss Troll station's two hours. Where no transition is near, this
 * is two offset lookups and no further work.
 */
function isAmbiguousLocal(parts: LocalParts): boolean {
  const base = localPartsToDate(parts);
  const half = 12 * 3_600_000;
  const before = new Date(base.getTime() - half).getTimezoneOffset();
  const after = new Date(base.getTime() + half).getTimezoneOffset();
  if (before === after) {
    return false;
  }

  const clock = (date: Date) =>
    `${date.getFullYear()}-${date.getMonth()}-${date.getDate()} ${date.getHours()}:${date.getMinutes()}`;
  const here = clock(base);
  const transition = (after - before) * 60_000;
  for (const shift of [transition, -transition]) {
    if (clock(new Date(base.getTime() + shift)) === here) {
      return true;
    }
  }
  return false;
}

/**
 * Throws unless these components name exactly one instant on this Mac. Applied
 * to derived times as well as parsed ones: an end computed as start + 1 hour
 * can land inside an overlap that the same value would be refused for if it had
 * been typed.
 */
export function assertUnambiguousLocal(parts: LocalParts, label: string): void {
  if (isAmbiguousLocal(parts)) {
    throw new Error(
      `${label} (${formatLocalParts(parts)}) is ambiguous on this Mac — the clocks repeat that time, so it happens twice. Give an explicit end outside the daylight-saving overlap.`,
    );
  }
}

export function formatLocalParts(parts: LocalParts): string {
  const pad = (n: number, width = 2) => String(n).padStart(width, "0");
  return `${pad(parts.year, 4)}-${pad(parts.month)}-${pad(parts.day)}T${pad(parts.hours)}:${pad(parts.minutes)}`;
}

export const LOCAL_ONLY_NOTE =
  "Results are from the local Calendar store on this Mac only. A zero-result search means not found locally.";

export const NOT_FOUND_LOCALLY = "not found locally";
