//
//  schema.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 26/08/2026.
//

import type { ReadOnlyIndex } from "../db.ts";

const REQUIRED_TABLES = [
  "CalendarItem",
  "Calendar",
  "Store",
  "OccurrenceCache",
  "Participant",
  "Recurrence",
  "Location",
  "Alarm",
] as const;

/** Every CalendarItem column this code reads. */
const REQUIRED_EVENT_COLUMNS = [
  "summary",
  "description",
  "start_date",
  "start_tz",
  "end_date",
  "end_tz",
  "all_day",
  "calendar_id",
  "entity_type",
  "has_recurrences",
  "has_attendees",
  "has_attachment",
  "location_id",
  "organizer_id",
  "status",
  "url",
  "conference_url",
  "UUID",
  "orig_item_id",
  "phantom_master",
  "hidden",
  "creation_date",
  "last_modified",
] as const;

/** Events, as opposed to reminders, which share this database. */
export const EVENT_ENTITY_TYPE = 2;

/**
 * Mail's index carries a `properties.version` that changes rarely, so the mail
 * guard pins it. Calendar's `_ClientVersion` moves with every macOS point
 * release without the columns changing, so pinning it would break the server on
 * an OS update that broke nothing. The honest equivalent is to assert that the
 * columns actually read are present, and to say which are missing when they are
 * not — the same "never guess column meanings" rule, checked against what the
 * code depends on rather than against a number.
 */
export function assertKnownCalendarSchema(index: ReadOnlyIndex): void {
  const tables = new Set(
    index
      .all<{ name: string }>(`SELECT name FROM sqlite_master WHERE type = 'table'`)
      .map((row) => row.name),
  );
  const missingTables = REQUIRED_TABLES.filter((name) => !tables.has(name));
  if (missingTables.length > 0) {
    throw new Error(
      `Unknown Calendar schema: missing tables ${missingTables.join(", ")}. Refusing to guess column meanings.`,
    );
  }

  // `pragma_table_info` is unreachable here: the read-only authorizer denies
  // SQLITE_PRAGMA, and relaxing it to introspect the schema would widen what
  // every other query is allowed to do. Asking for each column instead is
  // authoritative — a prepare against a missing column fails, and LIMIT 0 means
  // no row is ever read.
  const missingColumns = REQUIRED_EVENT_COLUMNS.filter((name) => {
    try {
      index.all(`SELECT "${name}" FROM CalendarItem LIMIT 0`);
      return false;
    } catch {
      return true;
    }
  });
  if (missingColumns.length > 0) {
    throw new Error(
      `Unknown Calendar schema: CalendarItem is missing ${missingColumns.join(", ")}` +
        `${clientVersionSuffix(index)}. Refusing to guess column meanings.`,
    );
  }
}

function clientVersionSuffix(index: ReadOnlyIndex): string {
  const version = readProperty(index, "_ClientVersion");
  return version === null ? "" : ` (Calendar _ClientVersion ${version})`;
}

export function readProperty(index: ReadOnlyIndex, key: string): string | null {
  try {
    const row = index.get<{ value: string }>(
      `SELECT value FROM _SqliteDatabaseProperties WHERE key = ?`,
      [key],
    );
    return row === undefined ? null : String(row.value);
  } catch {
    return null;
  }
}

export function readNumericProperty(index: ReadOnlyIndex, key: string): number | null {
  const value = readProperty(index, key);
  if (value === null) {
    return null;
  }
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

export function wrapCalendarError(error: unknown, fallback: string): Error {
  const err = error as { message?: string; code?: string };
  const message = err.message ?? String(error);
  const code = err.code ?? "";
  if (code === "SQLITE_BUSY" || /locked|SQLITE_BUSY/i.test(message)) {
    return new Error(`Calendar database is locked or busy. ${message}`);
  }
  if (code === "EACCES" || code === "EPERM" || /permission denied/i.test(message)) {
    return new Error(
      `Cannot read the Calendar store (${message}). Grant Full Disk Access to the terminal / Node / MCP host.`,
    );
  }
  if (code === "ENOENT") {
    return new Error(message);
  }
  return new Error(`${fallback}: ${message}`);
}
