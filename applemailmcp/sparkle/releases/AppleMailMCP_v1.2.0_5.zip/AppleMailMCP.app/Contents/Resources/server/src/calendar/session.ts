//
//  session.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 26/08/2026.
//

import { existsSync } from "node:fs";
import { resolve } from "node:path";
import { openIndex, type ReadOnlyIndex } from "../db.ts";
import { assertKnownCalendarSchema, wrapCalendarError } from "./schema.ts";
import { findCalendarStore, inferStoreFromDbPath, isInsideLiveCalendarStore } from "./store.ts";
import type { CalendarStore } from "./types.ts";

export type CalendarSession = {
  index: ReadOnlyIndex;
  store: CalendarStore | null;
  close: () => void;
};

export function openCalendarSession(
  options: { dbPath?: string; home?: string } = {},
): CalendarSession {
  try {
    const resolved = resolveStoreAndDb(options);
    const index = openIndex(resolved.dbPath, options.home, {
      isLive: isInsideLiveCalendarStore,
      label: "Calendar",
    });
    try {
      assertKnownCalendarSchema(index);
    } catch (error) {
      index.close();
      throw error;
    }
    return { index, store: resolved.store, close: () => index.close() };
  } catch (error) {
    throw wrapCalendarError(error, "failed to open Calendar session");
  }
}

function resolveStoreAndDb(options: { dbPath?: string; home?: string }): {
  dbPath: string;
  store: CalendarStore | null;
} {
  if (!options.dbPath) {
    const store = findCalendarStore(options.home);
    return { dbPath: store.dbPath, store };
  }
  const dbPath = resolve(options.dbPath);
  if (!existsSync(dbPath)) {
    throw new Error(`Calendar database not found: ${dbPath}`);
  }
  return { dbPath, store: inferStoreFromDbPath(dbPath) };
}
