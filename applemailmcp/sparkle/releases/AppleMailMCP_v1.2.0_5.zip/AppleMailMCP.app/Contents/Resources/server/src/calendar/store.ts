//
//  store.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 26/08/2026.
//

import { existsSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
import { canonicalPath, isInsideCanonical, sharesInodeWith, sqliteFamily } from "../store.ts";
import type { CalendarStore } from "./types.ts";

const GROUP_CONTAINER = "group.com.apple.calendar";
const DB_NAME = "Calendar.sqlitedb";

/**
 * `~/Library/Calendars` is the pre-Catalina location and is empty on modern
 * macOS — verified on 26.6, where it exists with zero entries. Every guide that
 * still names it produces a confident "no calendars" answer, which is the
 * failure mode this project exists to avoid, so it is not consulted at all.
 */
export function calendarRootForHome(home: string = homedir()): string {
  return join(home, "Library", "Group Containers", GROUP_CONTAINER);
}

export function isInsideLiveCalendarStore(path: string, home: string = homedir()): boolean {
  if (isInsideCanonical(path, calendarRootForHome(home))) {
    return true;
  }
  return sharesInodeWith(canonicalPath(path), () => sqliteFamily(findCalendarStore(home).dbPath));
}

export function findCalendarStore(home: string = homedir()): CalendarStore {
  const root = calendarRootForHome(home);
  if (!existsSync(root)) {
    throw new Error(
      `Calendar store not found at ${root}. On macOS 10.15+ the store lives in this group container, not ~/Library/Calendars.`,
    );
  }
  const dbPath = join(root, DB_NAME);
  if (!existsSync(dbPath)) {
    throw new Error(`${DB_NAME} missing at ${dbPath}.`);
  }
  return { root, dbPath };
}

export function inferStoreFromDbPath(dbPath: string): CalendarStore | null {
  const abs = canonicalPath(dbPath);
  if (!abs.endsWith(`/${DB_NAME}`)) {
    return null;
  }
  return { root: abs.slice(0, -(DB_NAME.length + 1)), dbPath: abs };
}
