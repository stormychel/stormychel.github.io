//
//  types.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 26/08/2026.
//

export type CalendarStore = {
  root: string;
  dbPath: string;
};

export type CalendarRow = {
  id: number;
  title: string | null;
  type: string | null;
  account: string | null;
  accountType: string | null;
  color: string | null;
  uuid: string | null;
  notes: string | null;
};

export type EventRow = {
  id: number;
  uid: string | null;
  calendar: string | null;
  calendarId: number;
  title: string | null;
  start: string | null;
  end: string | null;
  allDay: boolean;
  timeZone: string | null;
  location: string | null;
  recurring: boolean;
  /** Only set when the row came out of the occurrence cache. */
  occurrence?: boolean;
  status: number | null;
  url: string | null;
  conferenceUrl: string | null;
  "has-attendees": boolean;
  "has-attachments": boolean;
};

export type EventDetail = EventRow & {
  /** True for items search_events filters out; a ROWID lookup still returns them. */
  hidden: boolean;
  notes: string | null;
  organizer: string | null;
  attendees: AttendeeRow[];
  recurrence: RecurrenceRow | null;
  alarms: AlarmRow[];
  created: string | null;
  lastModified: string | null;
};

export type AttendeeRow = {
  name: string | null;
  email: string | null;
  status: number | null;
  role: number | null;
  isSelf: boolean;
};

export type RecurrenceRow = {
  frequency: number | null;
  interval: number | null;
  count: number | null;
  end: string | null;
  specifier: string | null;
};

export type AlarmRow = {
  triggerDate: string | null;
  triggerInterval: number | null;
  type: number | null;
};

export type EventQuery = {
  title?: string;
  notes?: string;
  calendar?: string;
  /** Apple reference-date seconds; inclusive lower bound on the event end. */
  from?: number;
  /** Apple reference-date seconds; inclusive upper bound on the event start. */
  to?: number;
  limit?: number;
};

export type NewEvent = {
  /** Calendar title. Refused when more than one calendar carries it. */
  calendar?: string;
  /** Calendar uuid from list_calendars — unambiguous where titles are not. */
  calendarId?: string;
  title: string;
  start: string;
  end?: string;
  allDay?: boolean;
  location?: string;
  notes?: string;
  url?: string;
  alarmMinutesBefore?: number;
};
