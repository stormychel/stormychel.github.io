//
//  write.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 26/08/2026.
//

import { switchEnabled, type SwitchName } from "../config.ts";
import { runOsascript } from "../osascript.ts";
import {
  assertUnambiguousLocal,
  formatLocalParts,
  localPartsToDate,
  parseLocalDateTime,
  type LocalParts,
} from "./format.ts";
import type { NewEvent } from "./types.ts";

export const WRITE_ENV = "APPLECAL_ENABLE_WRITE" satisfies SwitchName;

/** Four weeks, matching the MCP schema's bound. */
export const MAX_ALARM_MINUTES = 40_320;

/**
 * Off unless explicitly set, and checked at registration time so the write tool
 * does not merely refuse — it does not exist. Mail's Stage 4 switch (#23) should
 * absorb this once it lands; until then the two halves gate independently and
 * neither defaults on.
 */
export function writeEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
  return switchEnabled(WRITE_ENV, env);
}

export type CreateEventResult = {
  created: boolean;
  dryRun: boolean;
  uid: string | null;
  calendar: string;
  title: string;
  start: string;
  end: string;
  allDay: boolean;
  note: string;
  /** Exactly what would be handed to osascript, so a dry run is inspectable. */
  arguments?: string[];
};

/**
 * Writing goes through Calendar.app, never through SQLite. CalendarAgent owns
 * Calendar.sqlitedb: it maintains the *Changes journal, the occurrence and
 * alarm caches and the iCloud sync state, so a direct INSERT is invisible at
 * best and corrupting at worst.
 *
 * Values reach AppleScript as `on run argv` arguments rather than interpolated
 * into the source, so a quote or a line break in a title is data and can never
 * become script.
 */
export function createEvent(
  event: NewEvent,
  options: { dryRun?: boolean; osascriptPath?: string } = {},
): CreateEventResult {
  const allDay = event.allDay === true;
  const title = event.title?.trim();
  if (!title) {
    throw new Error("title is required");
  }
  const calendarTitle = event.calendar?.trim() ?? "";
  const calendarId = event.calendarId?.trim() ?? "";
  if (!calendarTitle && !calendarId) {
    throw new Error(
      "calendar is required — run list_calendars for the titles, or pass calendarId (its uuid)",
    );
  }
  // Both, and the id would win while the title was reported back. Two
  // selectors that disagree have no safe resolution, and picking one silently
  // is how an event lands in a calendar nobody named.
  if (calendarTitle && calendarId) {
    throw new Error("pass either calendar or calendarId, not both");
  }

  // The MCP schema bounds this, but the CLI and any direct caller do not. A
  // negative value is the one that actually misfires: AppleScript negates it,
  // so -15 would set an alarm 15 minutes *after* the event.
  if (event.alarmMinutesBefore !== undefined) {
    const minutes = event.alarmMinutesBefore;
    // Integer, not merely finite: AppleScript coerces 1.5 to 2, so a fractional
    // request would be honoured as a different alarm.
    if (!Number.isInteger(minutes) || minutes < 0 || minutes > MAX_ALARM_MINUTES) {
      throw new Error(
        `alarmMinutesBefore must be a whole number of minutes between 0 and ${MAX_ALARM_MINUTES} (got ${minutes})`,
      );
    }
  }

  const start = parseLocalDateTime(event.start);
  const end = resolveEnd(event, start, allDay);
  if (compareParts(end, start) < 0) {
    throw new Error(`end (${formatLocalParts(end)}) is before start (${formatLocalParts(start)})`);
  }

  const args = [
    calendarTitle,
    title,
    formatLocalParts(start),
    formatLocalParts(end),
    allDay ? "1" : "0",
    event.location?.trim() ?? "",
    event.notes ?? "",
    event.url?.trim() ?? "",
    event.alarmMinutesBefore === undefined ? "" : String(event.alarmMinutesBefore),
    calendarId,
  ];

  const shared = {
    calendar: calendarTitle || calendarId,
    title,
    start: formatLocalParts(start),
    end: formatLocalParts(end),
    allDay,
  };

  if (options.dryRun) {
    return {
      ...shared,
      created: false,
      dryRun: true,
      uid: null,
      note: "Dry run — nothing was written. Times are local wall-clock on this Mac.",
      arguments: args,
    };
  }

  const uid = runOsascript(CREATE_EVENT_SCRIPT, args, {
    app: "Calendar",
    osascriptPath: options.osascriptPath,
    explain: explainCalendarFailure,
  });
  return {
    ...shared,
    created: true,
    dryRun: false,
    uid,
    note: "Created in Calendar.app. Times are local wall-clock on this Mac.",
  };
}

function resolveEnd(event: NewEvent, start: LocalParts, allDay: boolean): LocalParts {
  if (event.end) {
    return parseLocalDateTime(event.end);
  }
  if (allDay) {
    // Calendar treats an all-day event whose end day equals its start day as a
    // single day, so the default is the same day rather than the next one.
    return start;
  }
  // localPartsToDate, not `new Date(year, …)`: the latter reads a year below
  // 100 as nineteen-hundred-and-that, so an event in year 1 would default to an
  // end in 1901.
  const asDate = localPartsToDate(start);
  asDate.setHours(asDate.getHours() + 1);
  const derived = {
    year: asDate.getFullYear(),
    month: asDate.getMonth() + 1,
    day: asDate.getDate(),
    hours: asDate.getHours(),
    minutes: asDate.getMinutes(),
  };
  // The derived end goes through the same check a typed one would: an hour
  // after 01:30 on the night the clocks go back is 02:30, which is refused when
  // supplied explicitly and must not slip in by default.
  assertUnambiguousLocal(derived, "The default end, one hour after the start,");
  return derived;
}

/**
 * Compared as instants, not as formatted strings. Wall-clock ordering reverses
 * across a daylight-saving transition — 02:45 then 02:15 is half an hour
 * forward on the night the clocks go back — and a string compare cannot see
 * that. The parser refuses readings inside a repeated hour, which is the only
 * way that reversal is reachable today; comparing instants means it stays
 * correct if that ever relaxes. Ambiguity being refused is also what makes the
 * instant each set of components names unique.
 */
function compareParts(a: LocalParts, b: LocalParts): number {
  return localPartsToDate(a).getTime() - localPartsToDate(b).getTime();
}

/** Calendar-specific wording; the shared runner covers Automation denials and a missing app. */
function explainCalendarFailure(message: string): string | null {
  if (/More than one calendar/i.test(message)) {
    return `${message}. Run list_calendars and pass calendarId (the calendar's uuid) instead.`;
  }
  if (/No calendar (named|with identifier)/i.test(message)) {
    return `${message}. Run list_calendars for the exact titles and ids.`;
  }
  return null;
}

/**
 * Ten arguments, positional. Month is assigned from the constant list rather
 * than an integer: coercing a
 * number into `month of` is the classic AppleScript foot-gun, and `day` is set
 * to 1 first so assigning a month never overflows out of a 31-day date.
 */
const CREATE_EVENT_SCRIPT = `
on run argv
  set calName to item 1 of argv
  set theSummary to item 2 of argv
  set startSpec to item 3 of argv
  set endSpec to item 4 of argv
  set isAllDay to (item 5 of argv is "1")
  set theLocation to item 6 of argv
  set theNotes to item 7 of argv
  set theURL to item 8 of argv
  set alarmSpec to item 9 of argv
  set calId to item 10 of argv

  set startDate to my parseSpec(startSpec)
  set endDate to my parseSpec(endSpec)

  tell application "Calendar"
    if calId is not "" then
      set matches to (every calendar whose calendarIdentifier is calId)
      if (count of matches) is 0 then error "No calendar with identifier " & calId
    else
      set matches to (every calendar whose title is calName)
      if (count of matches) is 0 then error "No calendar named " & calName
      -- Titles are not unique across accounts, and silently taking the first
      -- match would create the event in whichever calendar happened to sort
      -- first.
      if (count of matches) > 1 then error "More than one calendar is named " & calName
    end if
    set targetCalendar to item 1 of matches
    set newEvent to make new event at end of events of targetCalendar with properties {summary:theSummary, start date:startDate, end date:endDate, allday event:isAllDay}
    if theLocation is not "" then set location of newEvent to theLocation
    if theNotes is not "" then set description of newEvent to theNotes
    if theURL is not "" then set url of newEvent to theURL
    if alarmSpec is not "" then
      tell newEvent
        make new display alarm at end of display alarms with properties {trigger interval:-(alarmSpec as integer)}
      end tell
    end if
    return uid of newEvent
  end tell
end run

on parseSpec(spec)
  set monthList to {January, February, March, April, May, June, July, August, September, October, November, December}
  set theDate to current date
  set day of theDate to 1
  set year of theDate to (text 1 thru 4 of spec) as integer
  set month of theDate to item ((text 6 thru 7 of spec) as integer) of monthList
  set day of theDate to (text 9 thru 10 of spec) as integer
  set hours of theDate to (text 12 thru 13 of spec) as integer
  set minutes of theDate to (text 15 thru 16 of spec) as integer
  set seconds of theDate to 0
  return theDate
end parseSpec
`;

export { CREATE_EVENT_SCRIPT };
