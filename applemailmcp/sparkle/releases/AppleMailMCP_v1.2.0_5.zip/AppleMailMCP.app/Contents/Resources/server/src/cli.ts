#!/usr/bin/env node
//
//  cli.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 13/08/2026.
//

import { readConfig, SWITCHES, switchState } from "./config.ts";
import { NOT_FOUND_LOCALLY, parseDateInput } from "./format.ts";
import { mailMessageRef, probeMessage } from "./mail-bridge.ts";
import { COMPOSE_ENV, composeDraft, composeEnabled } from "./mail-compose.ts";
import {
  FLAG_COLORS,
  moveMessage,
  setFlag,
  setFlagColor,
  setJunk,
  setRead,
  trashMessages,
  WRITE_ENV,
  writeEnabled,
  type FlagColor,
} from "./mail-write.ts";
import { listAccounts, listMailboxes } from "./mailboxes.ts";
import { searchMail, type BodySearchQuery } from "./body-search.ts";
import { getMessage, getThread } from "./message.ts";
import { search } from "./search.ts";
import { openSession } from "./session.ts";

const USAGE = `Usage:
  applemail search [options]
  applemail get --id <n> [options]
  applemail thread --id <n> [options]
  applemail bridge-check --id <n>
  applemail flag --id <n> [--color <c>] [--dry-run]
                                           (needs APPLEMAIL_ENABLE_WRITE=1)
  applemail unflag --id <n> [--dry-run]    (needs APPLEMAIL_ENABLE_WRITE=1)
  applemail mark-read --id <n> [--dry-run]   (needs APPLEMAIL_ENABLE_WRITE=1)
  applemail mark-unread --id <n> [--dry-run] (needs APPLEMAIL_ENABLE_WRITE=1)
  applemail mark-junk --id <n> [--dry-run]   (needs APPLEMAIL_ENABLE_WRITE=1)
  applemail mark-not-junk --id <n> [--dry-run] (needs APPLEMAIL_ENABLE_WRITE=1)
  applemail move --id <n> --dest <mailbox url> [--cross-account] [--dry-run]
                                           (needs APPLEMAIL_ENABLE_WRITE=1)
  applemail trash --id <n> [--dry-run]     (needs APPLEMAIL_ENABLE_WRITE=1)
  applemail compose [--to <a,b>] [--cc <a,b>] [--bcc <a,b>] [--subject <text>]
                    [--body <text>] [--from <own address>] [--dry-run]
                                           (needs APPLEMAIL_ENABLE_COMPOSE=1)
                     Opens a filled-in compose window in Mail. Never sends.
  applemail list-mailboxes [options]
  applemail list-accounts [options]
  applemail switches                       Each write switch, its value and where it came from
  applemail mcp

Read-only. The live Mail envelope index is never opened by SQLite;
it is APFS-cloned to a temp snapshot first. .emlx files are read, never
written. Tests should pass --index pointing at a fixture, not ~/Library/Mail.

Options:
  --index <path>     Envelope index file (skips live-store detection)
  --id <n>           messages.ROWID (get / thread)
  --from <text>      Sender address or display name substring
  --to <text>        Recipient address or display name substring
  --subject <text>   Subject substring
  --body <text>      Body text substring, case-insensitive (search). Reads at
                     most 2,000 bodies, newest first, after the other filters;
                     the result's exhausted says whether that was all of them
  --after <date>     date_received >= ISO-8601 (or unix epoch)
  --before <date>    date_received <= ISO-8601 (or unix epoch)
  --mailbox <text>   Mailbox url/path substring (e.g. INBOX)
  --read             Only read messages
  --unread           Only unread messages
  --flagged          Only flagged messages
  --unflagged        Only unflagged messages
  --include-deleted  Include deleted = 1 rows, and Trash mailboxes when
                     --mailbox is not given (default: both left out)
  --after-id <n>     Only ids above n, oldest first; the result's
                     nextAfterId is the cursor for the next poll
  --limit <n>        Max rows (default 50, hard cap 1000)
                     Any option may be written --option=value, which also
                     passes a value that itself begins with --
  --color <c>        Flag colour for flag: ${FLAG_COLORS.join(", ")}
  --offset <n>       Character offset into decoded body (get)
  --max-body <n>     Max body characters to return (get)
  --help             Show this help
`;

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  if (args.length === 0 || args.includes("--help") || args.includes("-h")) {
    process.stdout.write(USAGE);
    process.exit(args.length === 0 ? 1 : 0);
  }

  const command = args[0];
  if (command.startsWith("-")) {
    fail(`missing command. ${USAGE}`);
  }

  if (command === "mcp") {
    const { startStdioServer } = await import("./server.ts");
    await startStdioServer();
    return;
  }

  const flags = parseFlags(args.slice(1));
  // Checked before any command runs, so no command can silently ignore it.
  if (flags.color !== undefined && command !== "flag") {
    fail("--color only applies to flag");
  }
  // Compose reads nothing from the index, so it opens no session.
  if (command === "compose") {
    if (!flags.dryRun && !composeEnabled()) {
      fail(`composing is disabled. Set ${COMPOSE_ENV}=1 to allow it, or pass --dry-run to check the input.`);
    }
    const list = (value: string | undefined) => (value === undefined ? undefined : value.split(",").filter((a) => a.trim()));
    printJson(
      composeDraft(
        {
          to: list(flags.to),
          cc: list(flags.cc),
          bcc: list(flags.bcc),
          subject: flags.subject,
          body: flags.body,
          from: flags.from,
        },
        { dryRun: flags.dryRun === true },
      ),
    );
    return;
  }
  // Reads no index, so it opens no session.
  if (command === "switches") {
    const config = readConfig();
    printJson({
      configFile: config.path,
      configProblem: config.problem,
      switches: Object.fromEntries(SWITCHES.map((name) => [name, switchState(name)])),
    });
    return;
  }
  const session = openSession({ indexPath: flags.index });
  try {
    if (command === "search") {
      printJson(await searchMail(session.index, searchQueryFromFlags(flags), { store: session.store }));
      return;
    }
    if (command === "get" || command === "get-message") {
      if (flags.id === undefined) {
        fail("--id is required for get");
      }
      printJson(
        await getMessage(session.index, session.store, flags.id, {
          offset: flags.offset,
          maxBodyChars: flags.maxBody,
        }),
      );
      return;
    }
    if (command === "thread" || command === "get-thread") {
      if (flags.id === undefined) {
        fail("--id is required for thread");
      }
      printJson(getThread(session.index, session.store, flags.id, { limit: flags.limit }));
      return;
    }
    if (command === "bridge-check") {
      // Read-only. Asks Mail.app for the message the index knows by this id,
      // so the path every future write takes can be checked end to end.
      if (flags.id === undefined) {
        fail("--id is required for bridge-check");
      }
      const found = search(session.index, { id: flags.id, includeDeleted: true, limit: 1 }, { store: session.store });
      const row = found.messages[0];
      if (!row) {
        fail(`Message ${flags.id}: ${NOT_FOUND_LOCALLY}`);
      }
      const ref = mailMessageRef(row.mailbox, flags.id);
      printJson({ index: { subject: row.subject, mailbox: row.mailbox }, ref, mail: probeMessage(ref) });
      return;
    }
    if (
      command === "flag" ||
      command === "unflag" ||
      command === "mark-read" ||
      command === "mark-unread" ||
      command === "mark-junk" ||
      command === "mark-not-junk"
    ) {
      if (!flags.dryRun && !writeEnabled()) {
        fail(`writing is disabled. Set ${WRITE_ENV}=1 to allow it, or pass --dry-run to see what would change.`);
      }
      if (flags.id === undefined) {
        fail(`--id is required for ${command}`);
      }
      const options = { dryRun: flags.dryRun === true };
      printJson(
        command === "flag" && flags.color !== undefined
          ? setFlagColor(session.index, flags.id, flags.color, options)
          : command === "flag" || command === "unflag"
            ? setFlag(session.index, flags.id, command === "flag", options)
            : command === "mark-junk" || command === "mark-not-junk"
              ? setJunk(session.index, flags.id, command === "mark-junk", options)
              : setRead(session.index, flags.id, command === "mark-read", options),
      );
      return;
    }
    if (command === "move") {
      if (!flags.dryRun && !writeEnabled()) {
        fail(`writing is disabled. Set ${WRITE_ENV}=1 to allow it, or pass --dry-run to see what would change.`);
      }
      if (flags.id === undefined) {
        fail("--id is required for move");
      }
      if (!flags.dest) {
        fail("--dest is required for move: a mailbox url exactly as list-mailboxes prints it");
      }
      printJson(
        moveMessage(session.index, flags.id, flags.dest, {
          dryRun: flags.dryRun === true,
          allowCrossAccount: flags.crossAccount === true,
        }),
      );
      return;
    }
    if (command === "trash") {
      if (!flags.dryRun && !writeEnabled()) {
        fail(`writing is disabled. Set ${WRITE_ENV}=1 to allow it, or pass --dry-run to see what would change.`);
      }
      if (flags.id === undefined) {
        fail("--id is required for trash");
      }
      printJson(trashMessages(session.index, [flags.id], { dryRun: flags.dryRun === true }));
      return;
    }
    if (command === "list-mailboxes") {
      printJson({ mailboxes: listMailboxes(session.index) });
      return;
    }
    if (command === "list-accounts") {
      printJson({ accounts: listAccounts(session.index) });
      return;
    }
    fail(`unknown command: ${command}\n${USAGE}`);
  } finally {
    session.close();
  }
}

type Flags = {
  index?: string;
  id?: number;
  from?: string;
  to?: string;
  subject?: string;
  body?: string;
  after?: string;
  before?: string;
  mailbox?: string;
  read?: boolean;
  unread?: boolean;
  flagged?: boolean;
  unflagged?: boolean;
  includeDeleted?: boolean;
  afterId?: number;
  limit?: number;
  offset?: number;
  maxBody?: number;
  dryRun?: boolean;
  dest?: string;
  crossAccount?: boolean;
  cc?: string;
  bcc?: string;
  body?: string;
  color?: FlagColor;
};

function parseFlags(argv: string[]): Flags {
  const flags: Flags = {};
  for (let i = 0; i < argv.length; i += 1) {
    // `--flag=value` carries its value inline, so any value at all can be
    // passed that way, including one that itself begins with `--`.
    const eq = argv[i].startsWith("--") ? argv[i].indexOf("=") : -1;
    const arg = eq > 0 ? argv[i].slice(0, eq) : argv[i];
    const inline = eq > 0 ? argv[i].slice(eq + 1) : undefined;
    let consumedInline = false;
    const next = (): string => {
      if (inline !== undefined) {
        consumedInline = true;
        return inline;
      }
      const value = argv[i + 1];
      // Only a double dash marks the next word as a flag. Refusing every
      // leading dash made `--subject -urgent` and a negative epoch impossible,
      // while `--subject --limit 5` still has to fail rather than search for
      // the subject "--limit".
      if (value === undefined || value.startsWith("--")) {
        fail(`missing value for ${arg}${value === undefined ? "" : ` (use ${arg}=${value} to pass it as the value)`}`);
      }
      i += 1;
      return value;
    };
    // Checked here rather than left to the clamps downstream: once a single
    // dash stopped meaning "missing value", `--limit -5` would otherwise run
    // quietly with the default limit instead of failing on the typo.
    const nextNumber = (label: string, min: number): number => {
      const value = Number(next());
      if (!Number.isInteger(value) || value < min) {
        fail(`${label} must be a whole number of at least ${min}`);
      }
      return value;
    };
    switch (arg) {
      case "--index":
        flags.index = next();
        break;
      case "--id":
        flags.id = nextNumber("--id", 1);
        break;
      case "--from":
        flags.from = next();
        break;
      case "--to":
        flags.to = next();
        break;
      case "--subject":
        flags.subject = next();
        break;
      case "--body":
        flags.body = next();
        break;
      case "--after":
        flags.after = next();
        break;
      case "--before":
        flags.before = next();
        break;
      case "--mailbox":
        flags.mailbox = next();
        break;
      case "--after-id":
        flags.afterId = nextNumber("--after-id", 0);
        break;
      case "--limit":
        flags.limit = nextNumber("--limit", 1);
        break;
      case "--offset":
        flags.offset = nextNumber("--offset", 0);
        break;
      case "--max-body":
        flags.maxBody = nextNumber("--max-body", 1);
        break;
      case "--read":
        flags.read = true;
        break;
      case "--unread":
        flags.unread = true;
        break;
      case "--flagged":
        flags.flagged = true;
        break;
      case "--unflagged":
        flags.unflagged = true;
        break;
      case "--include-deleted":
        flags.includeDeleted = true;
        break;
      case "--dry-run":
        flags.dryRun = true;
        break;
      case "--cc":
        flags.cc = next();
        break;
      case "--bcc":
        flags.bcc = next();
        break;
      case "--body":
        flags.body = next();
        break;
      case "--dest":
        flags.dest = next();
        break;
      case "--color": {
        const value = next();
        if (!(FLAG_COLORS as readonly string[]).includes(value)) {
          fail(`--color must be one of ${FLAG_COLORS.join(", ")}`);
        }
        flags.color = value as FlagColor;
        break;
      }
      case "--cross-account":
        flags.crossAccount = true;
        break;
      default:
        fail(`unknown option: ${arg}`);
    }
    if (inline !== undefined && !consumedInline) {
      fail(`${arg} takes no value`);
    }
  }
  if (flags.read && flags.unread) {
    fail("use only one of --read / --unread");
  }
  if (flags.flagged && flags.unflagged) {
    fail("use only one of --flagged / --unflagged");
  }
  return flags;
}

function searchQueryFromFlags(flags: Flags): BodySearchQuery {
  return {
    sender: flags.from,
    recipient: flags.to,
    subject: flags.subject,
    after: flags.after ? parseDateInput(flags.after) : undefined,
    before: flags.before ? parseDateInput(flags.before) : undefined,
    mailbox: flags.mailbox,
    read: flags.read ? true : flags.unread ? false : undefined,
    flagged: flags.flagged ? true : flags.unflagged ? false : undefined,
    includeDeleted: flags.includeDeleted,
    afterId: flags.afterId,
    body: flags.body,
    limit: flags.limit,
  };
}

function printJson(value: unknown): void {
  process.stdout.write(`${JSON.stringify(value, null, 2)}\n`);
}

function fail(message: string): never {
  process.stderr.write(`${message.trim()}\n`);
  process.exit(1);
}

try {
  await main();
} catch (error) {
  const message = error instanceof Error ? error.message : String(error);
  fail(message);
}
