//
//  config.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 21/10/2026.
//

import { readFileSync } from "node:fs";
import { join } from "node:path";

/**
 * Every switch any server reads, by the name of its environment variable. The
 * config file uses the same names, so there is one vocabulary for both.
 */
export const SWITCHES = [
  "APPLEMAIL_ENABLE_WRITE",
  "APPLEMAIL_ENABLE_COMPOSE",
  "APPLEMAIL_LAUNCH",
  "APPLECAL_ENABLE_WRITE",
  "APPLECAL_ENABLE_DELETE",
  "APPLEREM_ENABLE_WRITE",
] as const;

export type SwitchName = (typeof SWITCHES)[number];

export const CONFIG_ENV = "APPLEMAIL_CONFIG";

/**
 * Where the shared config file is (#80): APPLEMAIL_CONFIG if set, else
 * ~/.config/applemail/config.json. An empty APPLEMAIL_CONFIG means no file at
 * all, which is how the test suite and the deploy smoke check keep the user's
 * own file from changing what they verify.
 *
 * The home directory comes from `env` rather than os.homedir(), so an env
 * object without HOME — as tests pass — reads no file either.
 */
export function configPath(env: NodeJS.ProcessEnv = process.env): string | null {
  const explicit = env[CONFIG_ENV];
  if (explicit !== undefined) {
    return explicit === "" ? null : explicit;
  }
  return env.HOME ? join(env.HOME, ".config", "applemail", "config.json") : null;
}

export type SwitchState = {
  enabled: boolean;
  source: "env" | "file" | "default";
};

/**
 * One switch's effective value. A set environment variable always wins, even
 * an empty one: existing registrations keep working unchanged, and the deploy
 * smoke check can still force every switch off by setting it to "". Only an
 * unset variable falls through to the file, where nothing but `true` turns a
 * switch on. A missing, unreadable or malformed file leaves every switch off.
 */
export function switchState(name: SwitchName, env: NodeJS.ProcessEnv = process.env): SwitchState {
  const value = env[name];
  if (value !== undefined) {
    return { enabled: value === "1" || value.toLowerCase() === "true", source: "env" };
  }
  const { switches } = readConfig(env);
  if (switches && Object.hasOwn(switches, name)) {
    return { enabled: switches[name] === true, source: "file" };
  }
  return { enabled: false, source: "default" };
}

export function switchEnabled(name: SwitchName, env: NodeJS.ProcessEnv = process.env): boolean {
  return switchState(name, env).enabled;
}

export type ConfigFile = {
  path: string | null;
  /** null when there is no usable file; every switch is then off unless its env var is set. */
  switches: Record<string, unknown> | null;
  /** Why an existing file was ignored, for `applemail switches` to show. */
  problem: string | null;
};

/** Fails closed: anything but a readable `{"switches": {…}}` object reads as no switches. */
export function readConfig(env: NodeJS.ProcessEnv = process.env): ConfigFile {
  const path = configPath(env);
  if (!path) return { path, switches: null, problem: null };
  let text: string;
  try {
    text = readFileSync(path, "utf8");
  } catch (error) {
    const missing = (error as NodeJS.ErrnoException).code === "ENOENT";
    return { path, switches: null, problem: missing ? null : `cannot read it: ${(error as Error).message}` };
  }
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch (error) {
    return { path, switches: null, problem: `not valid JSON: ${(error as Error).message}` };
  }
  const switches = (parsed as { switches?: unknown } | null)?.switches;
  if (!switches || typeof switches !== "object" || Array.isArray(switches)) {
    return { path, switches: null, problem: 'no "switches" object' };
  }
  return { path, switches: switches as Record<string, unknown>, problem: null };
}
