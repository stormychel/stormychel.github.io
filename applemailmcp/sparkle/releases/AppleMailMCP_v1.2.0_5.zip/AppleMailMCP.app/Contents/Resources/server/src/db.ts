//
//  db.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 13/08/2026.
//

import { copyFileSync, existsSync, mkdtempSync, rmSync, statSync } from "node:fs";
import { tmpdir } from "node:os";
import { basename, join, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import { spawnSync } from "node:child_process";
import { DatabaseSync, constants } from "node:sqlite";
import { isInsideLiveMailStore } from "./store.ts";

const READ_ACTIONS = new Set<number>([
  constants.SQLITE_SELECT,
  constants.SQLITE_READ,
  constants.SQLITE_FUNCTION,
  constants.SQLITE_RECURSIVE,
]);

export const DEFAULT_LIMIT = 50;
export const MAX_LIMIT = 1000;

/**
 * Both stores this repo reads — Mail's envelope index and Calendar's
 * Calendar.sqlitedb — are owned by a daemon that writes to them continuously,
 * so the snapshot, authorizer and fingerprint machinery below is shared. Only
 * "which live store must SQLite never open" differs, and that is this hook.
 */
export type LiveStoreGuard = (path: string, home?: string) => boolean;

export type OpenIndexOptions = {
  /** Returns true when the path is (or hardlinks) the live store. */
  isLive?: LiveStoreGuard;
  /** Owner named in snapshot errors: "Mail", "Calendar". */
  label?: string;
};

export class ReadOnlyIndex {
  readonly path: string;
  readonly openedViaSnapshot: boolean;
  readonly snapshotDir: string | null;
  #db: DatabaseSync;

  constructor(db: DatabaseSync, path: string, snapshotDir: string | null) {
    this.#db = db;
    this.path = path;
    this.snapshotDir = snapshotDir;
    this.openedViaSnapshot = snapshotDir !== null;
  }

  all<T>(sql: string, params: unknown[] = []): T[] {
    assertSelect(sql);
    return this.#db.prepare(sql).all(...params) as T[];
  }

  get<T>(sql: string, params: unknown[] = []): T | undefined {
    assertSelect(sql);
    return this.#db.prepare(sql).get(...params) as T | undefined;
  }

  /**
   * Streams rows so a caller can stop early. Messages needs it: the message
   * body usually lives in an `attributedBody` blob, so matching text means
   * decoding in JS rather than in SQL, and `all()` would materialise every
   * candidate blob in the archive to return twenty rows.
   */
  *iterate<T>(sql: string, params: unknown[] = []): IterableIterator<T> {
    assertSelect(sql);
    yield* this.#db.prepare(sql).iterate(...params) as IterableIterator<T>;
  }

  close(): void {
    // The snapshot is a full clone of the index; if close() throws it must
    // still be removed, or every failing call leaks one under tmpdir.
    try {
      this.#db.close();
    } finally {
      if (this.snapshotDir) {
        rmSync(this.snapshotDir, { recursive: true, force: true });
      }
    }
  }
}

export function openIndex(
  indexPath: string,
  home?: string,
  options: OpenIndexOptions = {},
): ReadOnlyIndex {
  const isLive = options.isLive ?? isInsideLiveMailStore;
  const label = options.label ?? "Mail";
  const abs = resolve(indexPath);
  if (!existsSync(abs)) {
    throw new Error(`Database not found: ${abs}`);
  }

  if (isLive(abs, home)) {
    const snapshot = snapshotLiveIndex(abs, label);
    try {
      return openReadOnlyFile(snapshot.file, snapshot.dir, isLive, label);
    } catch (error) {
      rmSync(snapshot.dir, { recursive: true, force: true });
      throw error;
    }
  }

  return openReadOnlyFile(abs, null, isLive, label);
}

function openReadOnlyFile(
  filePath: string,
  snapshotDir: string | null,
  isLive: LiveStoreGuard,
  label: string,
): ReadOnlyIndex {
  if (isLive(filePath)) {
    throw new Error(
      `Refusing to let SQLite open the live ${label} store at ${filePath}. Snapshot it first.`,
    );
  }

  // Snapshots include a cloned -wal; immutable=1 would ignore it.
  // Fixtures / explicit --index files stay immutable so SQLite never
  // creates a sidecar next to a file we don't own.
  const uri = readOnlyUri(filePath, { immutable: snapshotDir === null });
  const db = new DatabaseSync(uri, { readOnly: true });
  try {
    db.enableDefensive(true);
    db.setAuthorizer((actionCode: number) =>
      READ_ACTIONS.has(actionCode) ? constants.SQLITE_OK : constants.SQLITE_DENY,
    );
  } catch (error) {
    db.close();
    throw error;
  }
  return new ReadOnlyIndex(db, filePath, snapshotDir);
}

export function readOnlyUri(filePath: string, opts: { immutable?: boolean } = {}): string {
  const uri = pathToFileURL(resolve(filePath));
  uri.searchParams.set("mode", "ro");
  if (opts.immutable !== false) {
    uri.searchParams.set("immutable", "1");
  }
  return uri.href;
}

const SNAPSHOT_ATTEMPTS = 3;

/**
 * The database and its -wal have to be cloned as two separate operations, so
 * Mail can checkpoint in between: the WAL is then reset with a fresh salt and
 * describes pages the cloned main image has never seen. SQLite replays it
 * anyway and the reads come back wrong.
 *
 * Detect it the cheap way — fingerprint the live files either side of the
 * clone and retry if anything moved. `PRAGMA quick_check` would be the
 * thorough answer, but it measures 374ms on a 52MB store and the MCP server
 * opens a fresh session per tool call, which would cost more than every query
 * it protects. The live store is only ever read here; a bad snapshot is
 * discarded, never written back.
 */
export function snapshotLiveIndex(
  liveIndexPath: string,
  label = "Mail",
): { dir: string; file: string } {
  const wal = liveIndexPath + "-wal";
  let lastFingerprint = "";

  let lastError: Error | null = null;

  for (let attempt = 0; attempt < SNAPSHOT_ATTEMPTS; attempt++) {
    const dir = mkdtempSync(join(tmpdir(), "applemailmcp-"));
    const file = join(dir, basename(liveIndexPath));
    // `return` inside the try still runs the finally, so the success path has
    // to opt out of cleanup explicitly or it deletes the snapshot it just took.
    let keepSnapshot = false;
    try {
      const before = fingerprint(liveIndexPath, wal);
      cloneFile(liveIndexPath, file);
      if (existsSync(wal)) {
        cloneFile(wal, file + "-wal");
      }
      const after = fingerprint(liveIndexPath, wal);
      if (before === after) {
        keepSnapshot = true;
        return { dir, file };
      }
      lastFingerprint = after;
    } catch (error) {
      // Mail closing the database can delete the -wal between existsSync and
      // cloneFile. That is the race we are already retrying for, not a reason
      // to give up on the first go.
      lastError = error as Error;
    } finally {
      if (!keepSnapshot) {
        rmSync(dir, { recursive: true, force: true });
      }
    }
  }

  throw new Error(
    `Could not take a consistent snapshot of ${liveIndexPath} in ${SNAPSHOT_ATTEMPTS} attempts. ` +
      (lastError
        ? `Last error: ${lastError.message}`
        : `${label} kept writing (last state ${lastFingerprint}).`) +
      " Retry in a moment.",
  );
}

/**
 * Size, mtime and inode generation of the whole trio. `bigint: true` is what
 * exposes mtimeNs — the default millisecond mtime is coarse enough to miss a
 * fast checkpoint.
 *
 * mtime resolution is a filesystem property, not a guarantee: on a 1-second
 * granularity volume (HFS+) a WAL restart within the same second that happens
 * to preserve file size would look unchanged. `ino` and `ctimeNs` are folded in
 * because a WAL restart replaces the file, which moves both.
 */
function fingerprint(indexPath: string, walPath: string): string {
  return [indexPath, walPath, walPath.replace(/-wal$/, "-shm")]
    .map((path) => {
      try {
        const stat = statSync(path, { bigint: true });
        return `${stat.size}:${stat.mtimeNs}:${stat.ctimeNs}:${stat.ino}`;
      } catch {
        return "-";
      }
    })
    .join("|");
}

function cloneFile(src: string, dest: string): void {
  if (process.platform === "darwin") {
    const cloned = spawnSync("cp", ["-c", src, dest], { encoding: "utf8" });
    if (cloned.status === 0) {
      return;
    }
  }
  copyFileSync(src, dest);
}

function assertSelect(sql: string): void {
  const stripped = sql
    .replace(/\/\*[\s\S]*?\*\//g, " ")
    .replace(/--[^\n]*/g, " ")
    .trim();
  if (!/^SELECT\b/i.test(stripped)) {
    throw new Error("only SELECT statements are allowed against the store");
  }
}
