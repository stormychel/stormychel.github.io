//
//  emlx.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 13/08/2026.
//

import {
  closeSync,
  createReadStream,
  existsSync,
  fstatSync,
  openSync,
  readdirSync,
  readSync,
  realpathSync,
  statSync,
} from "node:fs";
import { Readable } from "node:stream";
import { dirname, join, sep } from "node:path";
import type { BodyAvailability, MailStore } from "./types.ts";
import { parseMailboxUrl } from "./store.ts";

export type ResolvedBody = {
  status: BodyAvailability;
  path: string | null;
};

export function rowIdDataSubpath(rowId: number): string {
  const stem = String(Math.trunc(rowId)).slice(0, -3);
  const dirs = [...stem].reverse();
  return join("Data", ...dirs, "Messages");
}

export function peekBodyFile(store: MailStore, rowId: number, mailboxUrl: string): ResolvedBody {
  return resolveBodyFile(store, rowId, mailboxUrl);
}

export function resolveBodyFile(store: MailStore, rowId: number, mailboxUrl: string): ResolvedBody {
  // Anchor every check to the account directory, never to an intermediate one.
  // The UUID and Data directories between the .mbox and the message can be
  // symlinks too, and checking the file against its own parent would use that
  // already-external directory as the root.
  const parsed = parseMailboxUrl(mailboxUrl);
  if (!isSafeSegment(parsed.accountId)) {
    return { status: "unavailable", path: null };
  }
  const accountDir = join(store.versionDir, parsed.accountId);

  for (const messagesDir of messageDirs(store, mailboxUrl, rowId)) {
    const full = join(messagesDir, `${rowId}.emlx`);
    if (existsSync(full) && isContained(full, accountDir)) {
      return { status: "full", path: full };
    }
    const partial = join(messagesDir, `${rowId}.partial.emlx`);
    if (existsSync(partial) && isContained(partial, accountDir)) {
      return { status: "partial", path: partial };
    }
  }
  return { status: "unavailable", path: null };
}

/**
 * True when `candidate` really lives under `parent` once symlinks are resolved.
 *
 * Compared case-folded: APFS is case-insensitive by default, and a strict
 * comparison rejected legitimate paths whose casing differed from the parent's,
 * silently reporting their bodies as unavailable.
 *
 * This is containment, not a defence against a determined local attacker: the
 * path could still be swapped between this check and the read. Anyone able to
 * plant symlinks inside ~/Library/Mail already has write access to the home
 * directory.
 */
function isContained(candidate: string, parent: string): boolean {
  try {
    const root = statSync(realpathSync(parent));
    let current = realpathSync(candidate);

    // Walk up by device and inode rather than comparing path strings. A
    // case-sensitive comparison rejected legitimate paths on case-insensitive
    // APFS; case-folding then admitted a genuinely different directory on a
    // case-sensitive volume. Identity has neither failure mode.
    for (;;) {
      const here = statSync(current);
      if (here.dev === root.dev && here.ino === root.ino) {
        return true;
      }
      const next = dirname(current);
      if (next === current) {
        return false;
      }
      current = next;
    }
  } catch {
    return false;
  }
}

/** The length line is a decimal byte count padded to ten characters; 64 bytes is ample. */
const LENGTH_LINE_MAX = 64;

/**
 * Where the RFC 822 message sits inside an .emlx: after a length line, for the
 * number of bytes that line declares, followed by Mail's plist trailer.
 *
 * Only the first few bytes are read. A message with a 20 MB attachment would
 * otherwise be pulled into memory whole just to find where it starts (#36).
 */
export function emlxRfc822Range(filePath: string): { start: number; end: number } {
  const fd = openSync(filePath, "r");
  let head: Buffer;
  let fileSize: number;
  try {
    fileSize = fstatSync(fd).size;
    head = Buffer.alloc(Math.min(LENGTH_LINE_MAX, fileSize));
    // A short read would leave zeros where the length line should be, so the
    // count is used rather than trusted to fill the buffer.
    head = head.subarray(0, readSync(fd, head, 0, head.length, 0));
  } finally {
    closeSync(fd);
  }
  const nl = head.indexOf(0x0a);
  if (nl <= 0) {
    throw new Error(`invalid .emlx (no length line): ${filePath}`);
  }
  const declared = Number.parseInt(head.subarray(0, nl).toString("ascii").trim(), 10);
  if (!Number.isFinite(declared) || declared < 0) {
    throw new Error(`invalid .emlx length prefix: ${filePath}`);
  }
  const start = nl + 1;
  return { start, end: Math.min(start + declared, fileSize) };
}

/** The message bytes as a stream, never held in memory whole. */
export function openEmlxRfc822(filePath: string): Readable {
  return openEmlxRfc822Clipped(filePath).stream;
}

/**
 * As openEmlxRfc822, stopping after `maxBytes` and saying whether it did.
 * Body search uses it (#30): the text parts of a message come before its
 * attachments, and parsing a 19 MB attachment only to throw it away took 4 s
 * and 300 MB on a real store.
 */
export function openEmlxRfc822Clipped(filePath: string, maxBytes?: number): { stream: Readable; clipped: boolean } {
  const { start, end: fullEnd } = emlxRfc822Range(filePath);
  const clipped = maxBytes !== undefined && fullEnd - start > maxBytes;
  const end = clipped ? start + maxBytes : fullEnd;
  if (end <= start) {
    return { stream: Readable.from([]), clipped };
  }
  // createReadStream's `end` is inclusive.
  return { stream: createReadStream(filePath, { start, end: end - 1 }), clipped };
}

export function buildEmlx(rfc822: Buffer | string, trailer = ""): Buffer {
  const body = typeof rfc822 === "string" ? Buffer.from(rfc822, "utf8") : rfc822;
  const prefix = Buffer.from(`${String(body.length).padEnd(10)}\n`, "ascii");
  return Buffer.concat([prefix, body, Buffer.from(trailer, "utf8")]);
}

function messageDirs(store: MailStore, mailboxUrl: string, rowId: number): string[] {
  const subpath = rowIdDataSubpath(rowId);
  return mailboxRoots(store, mailboxUrl).map((root) => join(root, subpath));
}

function mailboxRoots(store: MailStore, mailboxUrl: string): string[] {
  const parsed = parseMailboxUrl(mailboxUrl);
  // The account id is decoded, so '%2e%2e' arrives as '..' and would walk out
  // of the version directory before any mailbox path is even considered.
  if (!isSafeSegment(parsed.accountId)) {
    return [];
  }
  const accountDir = join(store.versionDir, parsed.accountId);
  // The account directory itself can be a symlink out of the store, which would
  // otherwise become the containment root and legitimise everything under it.
  if (!existsSync(accountDir) || !isContained(accountDir, store.versionDir)) {
    return [];
  }
  const roots: string[] = [];
  for (const mbox of candidateMboxDirs(accountDir, parsed.path)) {
    for (const entry of safeReaddir(mbox)) {
      const root = join(mbox, entry);
      const data = join(root, "Data");
      if (existsSync(data) && isContained(root, accountDir) && isContained(data, accountDir)) {
        roots.push(root);
      }
    }
  }
  return roots;
}

/**
 * Mail nests a mailbox path segment-by-segment: `A/B/C` lives at
 * `A.mbox/B.mbox/C.mbox`. Special-casing only the first slash resolved two
 * segments and silently reported every deeper mailbox's bodies as
 * "unavailable" — a wrong answer rather than an error.
 *
 * The flat `A/B/C.mbox` form is kept as a fallback because some stores do use
 * it, and the older single-slash split is kept so nothing that resolved before
 * stops resolving now.
 */
/** A single path component that cannot be used to climb out of its parent. */
function isSafeSegment(segment: string): boolean {
  return segment.length > 0 && segment !== "." && segment !== ".." && !segment.includes(sep);
}

function candidateMboxDirs(accountDir: string, mailboxPath: string): string[] {
  if (!mailboxPath) {
    return [];
  }
  const segments = mailboxPath.split("/").filter((segment) => segment.length > 0);
  // mailboxes.url is decoded before it gets here, so '%2e%2e' arrives as '..'.
  // These paths come from the index rather than a tool argument, but a mailbox
  // name must never be able to walk out of its own account directory.
  if (segments.length === 0 || !segments.every(isSafeSegment)) {
    return [];
  }

  const safePath = segments.join("/");
  const candidates = [
    join(accountDir, ...segments.map((segment) => `${segment}.mbox`)),
    join(accountDir, `${safePath}.mbox`),
  ];
  if (segments.length > 2) {
    candidates.push(join(accountDir, `${segments[0]}.mbox`, `${segments.slice(1).join("/")}.mbox`));
  }

  // Containment has to be checked after resolving symlinks. `resolve` is
  // purely lexical, and statSync follows links, so a mailbox directory
  // symlinked outside the account passes a string comparison while the reads
  // land somewhere else entirely.
  const seen = new Set<string>();
  return candidates.filter((dir) => {
    if (seen.has(dir) || !existsSync(dir)) {
      return false;
    }
    seen.add(dir);
    try {
      if (!statSync(realpathSync(dir)).isDirectory()) {
        return false;
      }
    } catch {
      return false;
    }
    return isContained(dir, accountDir);
  });
}

function safeReaddir(dir: string): string[] {
  try {
    return readdirSync(dir);
  } catch {
    return [];
  }
}
