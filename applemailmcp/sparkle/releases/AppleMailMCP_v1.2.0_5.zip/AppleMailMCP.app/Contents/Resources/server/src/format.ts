//
//  format.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 13/08/2026.
//

export function epochToIso(epoch: number | null | undefined): string | null {
  if (epoch === null || epoch === undefined || !Number.isFinite(epoch)) {
    return null;
  }
  return new Date(epoch * 1000).toISOString();
}

export function parseDateInput(value: string): number {
  const trimmed = value.trim();
  // A negative epoch has to be caught before Date.parse sees it: "-86400"
  // parses as the year 86399, so a bound meant for 1969 silently matched
  // everything instead.
  if (/^-\d+$/.test(trimmed)) {
    const asNumber = Number(trimmed);
    return asNumber < -1e12 ? Math.floor(asNumber / 1000) : asNumber;
  }
  if (/^\d+$/.test(trimmed)) {
    // A compact date is far more likely than an epoch of the same shape:
    // "20240101" as seconds is August 1970, which silently matches everything.
    if (/^\d{8}$/.test(trimmed)) {
      const year = trimmed.slice(0, 4);
      const month = trimmed.slice(4, 6);
      const day = trimmed.slice(6, 8);
      const compact = Date.parse(`${year}-${month}-${day}T00:00:00Z`);
      // Date.parse silently rolls an impossible date forward — 2023-02-29
      // becomes 2023-03-01 — so check the parts survived the round trip rather
      // than quietly searching from the wrong day.
      const roundTrip = new Date(compact);
      if (
        !Number.isNaN(compact) &&
        roundTrip.getUTCFullYear() === Number(year) &&
        roundTrip.getUTCMonth() + 1 === Number(month) &&
        roundTrip.getUTCDate() === Number(day)
      ) {
        return Math.floor(compact / 1000);
      }
      throw new Error(`Invalid date: ${value} (use ISO-8601, e.g. 2024-01-01)`);
    }
    const asNumber = Number(trimmed);
    return asNumber > 1e12 ? Math.floor(asNumber / 1000) : asNumber;
  }
  const parsed = Date.parse(trimmed);
  if (Number.isNaN(parsed)) {
    throw new Error(`Invalid date: ${value} (use ISO-8601, e.g. 2024-01-01)`);
  }
  return Math.floor(parsed / 1000);
}

export function formatFrom(address: string | null | undefined, comment: string | null | undefined): string | null {
  const addr = address?.trim() || "";
  const name = comment?.trim() || "";
  if (!addr && !name) {
    return null;
  }
  if (name && addr) {
    return `${name} <${addr}>`;
  }
  return name || addr;
}

export function likeContains(value: string): string {
  return `%${escapeLike(value)}%`;
}

export function escapeLike(value: string): string {
  return value.replace(/[#%_]/g, "#$&");
}

export function clampLimit(limit: number | undefined, fallback: number, max: number): number {
  const n = limit === undefined ? fallback : Math.floor(limit);
  if (!Number.isFinite(n) || n < 1) {
    return fallback;
  }
  return Math.min(n, max);
}

export const LOCAL_ONLY_NOTE =
  "Results are from the local Mail store on this Mac only. A zero-result search means not found locally.";

export const NOT_FOUND_LOCALLY = "not found locally";
