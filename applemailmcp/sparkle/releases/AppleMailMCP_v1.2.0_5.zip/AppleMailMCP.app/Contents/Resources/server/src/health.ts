//
//  health.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 21/10/2026.
//

import { execFileSync } from "node:child_process";
import { closeSync, mkdirSync, openSync, readdirSync, renameSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";

/**
 * Whether a server can read its store, as seen by the app that started it
 * (#99). Full Disk Access belongs to that app — Claude, a terminal — not to
 * node, so the menu-bar app cannot test it by starting a server itself. Each
 * server instead records, once at startup, which app it ran under and whether
 * its store opened. No content is read or written: only the outcome.
 */
export type HealthState = "ok" | "denied" | "unavailable";

export type HealthReport = {
  server: string;
  /** The app macOS holds responsible for this process, e.g. "Claude" or "Terminal". */
  host: string;
  hostPath: string | null;
  state: HealthState;
  detail: string | null;
  at: string;
};

export const HEALTH_DIR_ENV = "APPLEMAIL_HEALTH_DIR";

/** APPLEMAIL_HEALTH_DIR if set (empty turns reporting off), else ~/.local/share/applemail/health. */
export function healthDir(env: NodeJS.ProcessEnv = process.env): string | null {
  const explicit = env[HEALTH_DIR_ENV];
  if (explicit !== undefined) return explicit === "" ? null : explicit;
  return env.HOME ? join(env.HOME, ".local/share/applemail/health") : null;
}

/**
 * Opens what `find` names for reading and closes it again, sorting any failure
 * into a state. The store finders test paths with existsSync, which turns a
 * TCC refusal into a plain "not found"; so when finding fails, listing `root`
 * — the protected folder the store lives in — tells a refusal from a store
 * that is really not there.
 */
export function probe(find: () => string, root?: string): { state: HealthState; detail: string | null } {
  try {
    closeSync(openSync(find(), "r"));
    return { state: "ok", detail: null };
  } catch (error) {
    if (isDenied(error)) return { state: "denied", detail: null };
    if (root !== undefined) {
      try {
        readdirSync(root);
      } catch (rootError) {
        if (isDenied(rootError)) return { state: "denied", detail: null };
      }
    }
    return { state: "unavailable", detail: error instanceof Error ? error.message : String(error) };
  }
}

// A TCC refusal surfaces as EPERM from open or readdir, whichever touches the store first.
function isDenied(error: unknown): boolean {
  const code = (error as { code?: string }).code ?? "";
  const message = error instanceof Error ? error.message : String(error);
  return code === "EPERM" || code === "EACCES" || /operation not permitted/i.test(message);
}

/**
 * The responsible app: the nearest ancestor running from inside an app bundle.
 * A terminal's shell and Claude Code's own binary sit between it and node, and
 * Claude Desktop starts servers from a helper inside its bundle, so the outermost
 * `.app` in the nearest such path is the one named. None means a background job.
 */
export function responsibleApp(table: Map<number, { ppid: number; comm: string }>, pid: number): { name: string; path: string | null } {
  const seen = new Set<number>();
  let current = table.get(pid);
  while (current && !seen.has(current.ppid) && current.ppid > 1) {
    seen.add(current.ppid);
    const parent = table.get(current.ppid);
    if (!parent) break;
    const at = parent.comm.indexOf(".app/");
    if (at !== -1) {
      const path = parent.comm.slice(0, at + 4);
      return { name: path.slice(path.lastIndexOf("/") + 1, -4), path };
    }
    current = parent;
  }
  return { name: "Background process", path: null };
}

export function processTable(): Map<number, { ppid: number; comm: string }> {
  const table = new Map<number, { ppid: number; comm: string }>();
  const output = execFileSync("/bin/ps", ["-axo", "pid=,ppid=,comm="], { encoding: "utf8", timeout: 2000 });
  for (const line of output.split("\n")) {
    const match = line.match(/^\s*(\d+)\s+(\d+)\s+(.*)$/);
    if (match) table.set(Number(match[1]), { ppid: Number(match[2]), comm: match[3] });
  }
  return table;
}

/**
 * Records this server's outcome, one file per server and app, replaced whole.
 * Never throws and never delays startup by more than a ps call: a report that
 * cannot be written must not cost the server.
 */
export function reportHealth(server: string, find: () => string, root?: string, env: NodeJS.ProcessEnv = process.env): void {
  let temporary: string | null = null;
  try {
    const dir = healthDir(env);
    if (!dir) return;
    const host = responsibleApp(processTable(), process.pid);
    const report: HealthReport = {
      server,
      host: host.name,
      hostPath: host.path,
      ...probe(find, root),
      at: new Date().toISOString(),
    };
    mkdirSync(dir, { recursive: true });
    const slug = host.name.replace(/[^A-Za-z0-9]+/g, "-");
    const file = join(dir, `${server}--${slug}.json`);
    temporary = `${file}.${process.pid}.tmp`;
    writeFileSync(temporary, `${JSON.stringify(report, null, 2)}\n`);
    renameSync(temporary, file);
  } catch {
    // Reporting is advisory; only a half-written temporary file is cleaned up.
    try {
      if (temporary) rmSync(temporary, { force: true });
    } catch {
      // Nor may the cleanup cost the server.
    }
  }
}
