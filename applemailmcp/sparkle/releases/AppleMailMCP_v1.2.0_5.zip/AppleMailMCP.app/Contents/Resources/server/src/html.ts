//
//  html.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 13/08/2026.
//

// Mail bodies are sender-controlled, so every step here is linear in the input.
// Regexes like /<[^>]+>/ backtrack quadratically on a run of unclosed '<', which
// let one hostile HTML message stall get_message and a body search far past its
// time budget; the passes below do the same work with forward indexOf scans.
export function htmlToText(html: string): string {
  const stripped = stripTags(removeBlocks(removeBlocks(html, "script"), "style")
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/p>/gi, "\n\n")
    .replace(/<\/div>/gi, "\n")
    .replace(/<\/h[1-6]>/gi, "\n\n")
    .replace(/<\/tr>/gi, "\n")
    .replace(/<\/li>/gi, "\n"));
  // One pass, so '&amp;' is never expanded early and re-read as the start of
  // another entity: '&amp;lt;' must stay '&lt;', not become '<'.
  // fromCodePoint, not fromCharCode, or astral entities like &#128512; garble.
  const decoded = stripped.replace(
    /&(nbsp|amp|lt|gt|quot|apos|#\d+|#x[0-9a-f]+);/gi,
    (match, token: string) => decodeEntity(token) ?? match,
  );
  return trimLineEnds(decoded).replace(/\n{3,}/g, "\n\n").trim();
}

/**
 * Drops every `<name …>…</name>` block, case-insensitively, as
 * /<name[\s\S]*?<\/name>/gi did. An opening tag with no closing one after it is
 * kept, as the regex left it, and ends the scan: no later block can close either.
 */
function removeBlocks(html: string, name: string): string {
  // ASCII-only folding: toLowerCase can change the length ("İ" becomes "i" plus a
  // combining dot), and offsets found in a longer copy would cut the wrong text.
  const lower = html.replace(/[A-Z]/g, (letter) => letter.toLowerCase());
  const open = `<${name}`;
  const close = `</${name}>`;
  let out = "";
  let position = 0;
  for (;;) {
    const start = lower.indexOf(open, position);
    if (start === -1) break;
    const end = lower.indexOf(close, start + open.length);
    if (end === -1) break;
    out += html.slice(position, start);
    position = end + close.length;
  }
  return out + html.slice(position);
}

/**
 * Removes `<…>` tags as /<[^>]+>/g did: '<' through the next '>', with at least
 * one character between them. A '<' with no '>' after it stays as text, and so
 * does everything after it, since no later tag can close.
 */
function stripTags(html: string): string {
  let out = "";
  let position = 0;
  for (;;) {
    let start = html.indexOf("<", position);
    if (start === -1) break;
    let end = html.indexOf(">", start + 1);
    if (end === -1) break;
    // "<>" is not a tag; the regex would then try the '<' of a later "<…>".
    while (end === start + 1) {
      start = html.indexOf("<", end + 1);
      if (start === -1) break;
      end = html.indexOf(">", start + 1);
      if (end === -1) break;
    }
    if (start === -1 || end === -1) break;
    out += html.slice(position, start);
    position = end + 1;
  }
  return out + html.slice(position);
}

/** /[ \t]+\n/g → "\n", without the regex's quadratic retries on a long run of blanks. */
function trimLineEnds(text: string): string {
  const lines = text.split("\n");
  for (let i = 0; i < lines.length - 1; i++) {
    const line = lines[i];
    let end = line.length;
    while (end > 0 && (line[end - 1] === " " || line[end - 1] === "\t")) end--;
    if (end !== line.length) lines[i] = line.slice(0, end);
  }
  return lines.join("\n");
}

const NAMED_ENTITIES: Record<string, string> = {
  nbsp: " ",
  amp: "&",
  lt: "<",
  gt: ">",
  quot: '"',
  apos: "'",
};

function decodeEntity(token: string): string | null {
  const named = NAMED_ENTITIES[token.toLowerCase()];
  if (named !== undefined) {
    return named;
  }
  const code = token.startsWith("#x") || token.startsWith("#X")
    ? parseInt(token.slice(2), 16)
    : Number(token.slice(1));
  // Lone surrogates and out-of-range values would throw out of fromCodePoint.
  if (!Number.isInteger(code) || code < 0 || code > 0x10ffff || (code >= 0xd800 && code <= 0xdfff)) {
    return null;
  }
  return String.fromCodePoint(code);
}
