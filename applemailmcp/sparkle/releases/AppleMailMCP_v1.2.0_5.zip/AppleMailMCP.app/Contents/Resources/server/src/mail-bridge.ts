//
//  mail-bridge.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 19/09/2026.
//

import { switchEnabled, type SwitchName } from "./config.ts";
import { appIsRunning, runOsascript, type RunOptions } from "./osascript.ts";
import { parseMailboxUrl } from "./store.ts";

/**
 * Where Mail.app keeps a message the envelope index knows by ROWID.
 *
 * Verified against Mail on macOS 26.6 on 2026-09-19, read-only:
 * - Mail's AppleScript `id` of a message is the index's ROWID (128097 was
 *   "RE: Contact" in both).
 * - The account part of an `imap://` mailbox URL is the AppleScript
 *   `account id` (4A248A75-… for iCloud, 01523694-… for Google).
 * - The path, URL-decoded, addresses the mailbox directly, nested ones
 *   included: `mailbox "[Gmail]/Important" of account id "…"`.
 * - `local://` mailboxes are "On My Mac" and are top-level `mailbox "Outbox"`,
 *   not mailboxes of any account.
 */
export type MailMessageRef = {
  /** null for an On My Mac mailbox, which belongs to no account. */
  accountId: string | null;
  mailbox: string;
  id: number;
};

const ACCOUNT_SCHEMES = new Set(["imap", "pop", "ews"]);

export function mailMessageRef(mailboxUrl: string, rowId: number): MailMessageRef {
  if (!Number.isInteger(rowId) || rowId <= 0) {
    throw new Error(`Invalid message id: ${rowId}`);
  }
  const parsed = parseMailboxUrl(mailboxUrl);
  if (!parsed.path) {
    throw new Error(`Cannot address a message in Mail.app from mailbox URL ${mailboxUrl}: it names no mailbox.`);
  }
  if (parsed.scheme === "local") {
    return { accountId: null, mailbox: parsed.path, id: rowId };
  }
  if (ACCOUNT_SCHEMES.has(parsed.scheme)) {
    return { accountId: parsed.accountId, mailbox: parsed.path, id: rowId };
  }
  // Refused rather than guessed: an unknown scheme is a store layout nobody
  // has checked, and a write aimed at the wrong mailbox is not undoable.
  throw new Error(`Cannot address a message in Mail.app from a ${parsed.scheme}:// mailbox (${mailboxUrl}).`);
}

/** The three `on run argv` arguments every message script starts with. */
export function refArgs(ref: MailMessageRef): string[] {
  return [ref.accountId ?? "", ref.mailbox, String(ref.id)];
}

/**
 * The shared lookup every Mail script uses to find its message: argv items
 * 1–3, as `refArgs` lays them out. By id within the one mailbox the index
 * placed it in, so a message is never matched by subject or sender, and a
 * missing one is an error naming what was looked for rather than whichever
 * message happened to be first.
 */
/**
 * The sentinel the in-script guard raises, distinctive so it cannot be
 * confused with an error that merely quotes a mailbox name.
 */
export const NOT_RUNNING_SENTINEL = "AppleMailMCP: Mail is not running";

/**
 * The error number the guard raises with it. Text is not enough on its own:
 * a mailbox could be named after the sentinel and appear inside an ordinary
 * "Can't get mailbox …" error. An error number cannot be spelled by data.
 * 8001 is inside the range AppleScript leaves to scripts (-2700 and 1000+).
 */
export const NOT_RUNNING_ERRNO = 8001;

/**
 * Re-checks that Mail is running in the same osascript run, immediately before
 * a `tell`. Asking whether an application is running never launches it;
 * telling it anything does. Called before every `tell` in every Mail script,
 * because the process check and each Apple Event are separated in time and
 * Mail can quit in between.
 *
 * `allowLaunch` is written into the script as a literal by runMailScript, not
 * taken from argv: with APPLEMAIL_LAUNCH=1 the caller has asked for Mail to be
 * started, so the guard must stand aside.
 */
export const REQUIRE_MAIL_HANDLER = `
on requireMail()
  if allowLaunch then return
  if not (application "Mail" is running) then error "${NOT_RUNNING_SENTINEL}" number ${NOT_RUNNING_ERRNO}
end requireMail
`;

export const LOCATE_MESSAGE_HANDLER = `
on locateMessage(accountId, mailboxName, messageId)
  my requireMail()
  tell application "Mail"
    if accountId is "" then
      set theMailbox to mailbox mailboxName
    else
      set theMailbox to mailbox mailboxName of account id accountId
    end if
    set matches to (messages of theMailbox whose id is messageId)
    if (count of matches) is 0 then error "No message with id " & messageId & " in mailbox " & mailboxName
    return item 1 of matches
  end tell
end locateMessage
`;

export const LAUNCH_ENV = "APPLEMAIL_LAUNCH" satisfies SwitchName;

export type MailRunOptions = Omit<RunOptions, "app" | "explain"> & {
  /** Overridden in tests; by default the process list is consulted. */
  isMailRunning?: () => boolean;
  env?: NodeJS.ProcessEnv;
};

/**
 * Every Mail script goes through here, so the same rule applies to reads and
 * writes: if Mail is not running, say so rather than starting it (#24).
 * `tell application "Mail"` launches Mail silently, and a background agent
 * starting Mail — and a full sync with it — is not something to do unasked.
 * `APPLEMAIL_LAUNCH=1` opts into the old behaviour.
 */
export function runMailScript(script: string, args: string[], options: MailRunOptions & { explain?: (message: string) => string | null } = {}): string | null {
  const { isMailRunning, env, explain, ...runOptions } = options;
  // Read once per call: the switch can come from the config file (#80), which
  // may change between two reads, and the check and the script must agree.
  const allowLaunch = launchEnabled(env);
  const running = isMailRunning ? isMailRunning() : appIsRunning("Mail");
  if (!running && !allowLaunch) {
    throw new Error(
      `Mail.app is not running, so this cannot be done. Open Mail and retry, or set ${LAUNCH_ENV}=1 (or in the config file) to let ` +
        "this tool launch it — which also starts a sync.",
    );
  }
  // A boolean this code computes, never caller text, so writing it into the
  // script cannot inject anything.
  const prelude = `property allowLaunch : ${allowLaunch ? "true" : "false"}\n`;
  return runOsascript(prelude + script + REQUIRE_MAIL_HANDLER, args, {
    ...runOptions,
    app: "Mail",
    explain: explain ?? explainMailFailure,
  });
}

export function launchEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
  return switchEnabled(LAUNCH_ENV, env);
}

export type MailProbe = {
  subject: string;
  sender: string;
  read: boolean;
  flagged: boolean;
};

export const PROBE_SCRIPT = `
on run argv
  set theMessage to locateMessage(item 1 of argv, item 2 of argv, (item 3 of argv) as integer)
  my requireMail()
  tell application "Mail"
    set fields to {subject of theMessage, sender of theMessage, read status of theMessage as text, flagged status of theMessage as text}
  end tell
  set AppleScript's text item delimiters to (character id 31)
  return fields as text
end run
${LOCATE_MESSAGE_HANDLER}`;

/** Mail-specific wording; the shared runner covers Automation denials and a missing app. */
export function explainMailFailure(message: string): string | null {
  // Matched on the error number where osascript prints it, at the very end:
  // verified that `error "…" number 8001` writes `… (8001)\n`. Anchored so a
  // mailbox named "Archive (8001)" quoted mid-message cannot pose as it.
  if (new RegExp(`\\(${NOT_RUNNING_ERRNO}\\)$`).test(message.trim())) {
    return (
      `Mail.app quit part-way through this call, so nothing was done. Reopen Mail and retry. (${message})`
    );
  }
  if (/No message with id/i.test(message)) {
    return `${message}. Mail.app no longer has it there — it may have been moved or deleted since the index was read.`;
  }
  if (/-1728|Can['’]t get (mailbox|account)/i.test(message)) {
    return `${message}. Mail.app has no such mailbox or account; the index may be out of date.`;
  }
  return null;
}

/**
 * Read-only: asks Mail.app for the message the index knows by `ref`. It is
 * how the bridge is checked end to end before anything is ever written
 * through it, and it changes nothing — not even the read flag.
 */
export function probeMessage(ref: MailMessageRef, options: MailRunOptions = {}): MailProbe {
  const out = runMailScript(PROBE_SCRIPT, refArgs(ref), options);
  const [subject = "", sender = "", read = "", flagged = ""] = (out ?? "").split("\u001f");
  return { subject, sender, read: read === "true", flagged: flagged === "true" };
}
