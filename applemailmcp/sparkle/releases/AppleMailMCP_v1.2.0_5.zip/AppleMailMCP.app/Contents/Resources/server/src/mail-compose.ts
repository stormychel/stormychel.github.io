//
//  mail-compose.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 21/10/2026.
//

import { switchEnabled, type SwitchName } from "./config.ts";
import { explainMailFailure, runMailScript, type MailRunOptions } from "./mail-bridge.ts";

export const COMPOSE_ENV = "APPLEMAIL_ENABLE_COMPOSE" satisfies SwitchName;

/**
 * Off unless explicitly set, and separate from APPLEMAIL_ENABLE_WRITE (#22).
 * The write switch covers changes to mail already here, each undone by the
 * opposite call. A compose window is the first step on the outbound path: one
 * click from a message leaving the machine, written by a model that may have
 * just read an email telling it what to write (#39). Turning on flagging must
 * not quietly turn that on as well, so it has a switch of its own.
 */
export function composeEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
  return switchEnabled(COMPOSE_ENV, env);
}

/** Recipients across to, cc and bcc together. */
export const MAX_RECIPIENTS = 50;
/** RFC 5322's line limit; a subject is one header line. */
export const MAX_SUBJECT_CHARS = 998;
export const MAX_BODY_CHARS = 100_000;

export type ComposeInput = {
  to?: string[];
  cc?: string[];
  bcc?: string[];
  subject?: string;
  /** Plain text. */
  body?: string;
  /** One of the user's own account addresses; Mail's default when absent. */
  from?: string;
};

export type ComposeResult = {
  dryRun: boolean;
  /** Whether a compose window was opened. Never true on a dry run. */
  opened: boolean;
  to: string[];
  cc: string[];
  bcc: string[];
  subject: string;
  bodyChars: number;
  from: string | null;
  note: string;
  arguments?: string[];
};

/**
 * A bare address and nothing else: no display name, no list, no comment.
 * Deliberately loose about what is valid — Mail and the server judge that —
 * and strict only about what could smuggle a second recipient or a header in.
 */
const ADDRESS = /^[^\s@<>,;:"()\[\]\\]+@[^\s@<>,;:"()\[\]\\]+\.[^\s@<>,;:"()\[\]\\]+$/;

function checkAddress(value: string, field: string): string {
  const address = value.trim();
  // \s misses most control characters, the unit separator that splits the
  // script's recipient lists among them.
  if (address.length === 0 || address.length > 254 || SUBJECT_CONTROL.test(address) || !ADDRESS.test(address)) {
    throw new Error(`${field}: ${JSON.stringify(value)} is not a bare email address (name@example.com).`);
  }
  return address;
}

// Control characters other than tab and line breaks; the unit separator
// among them, which the script uses to split the recipient lists.
const BODY_CONTROL = /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/;
const SUBJECT_CONTROL = /[\u0000-\u001f\u007f]/;

export function validateCompose(input: ComposeInput): Required<Omit<ComposeInput, "from">> & { from: string | null } {
  const to = (input.to ?? []).map((a) => checkAddress(a, "to"));
  const cc = (input.cc ?? []).map((a) => checkAddress(a, "cc"));
  const bcc = (input.bcc ?? []).map((a) => checkAddress(a, "bcc"));
  const count = to.length + cc.length + bcc.length;
  if (count > MAX_RECIPIENTS) {
    throw new Error(`At most ${MAX_RECIPIENTS} recipients across to, cc and bcc; got ${count}.`);
  }
  const subject = input.subject ?? "";
  if (subject.length > MAX_SUBJECT_CHARS) {
    throw new Error(`subject is ${subject.length} characters; the limit is ${MAX_SUBJECT_CHARS}.`);
  }
  // A line break in a subject is a header someone is trying to add.
  if (SUBJECT_CONTROL.test(subject)) {
    throw new Error("subject must be one line, with no control characters.");
  }
  const body = input.body ?? "";
  if (body.length > MAX_BODY_CHARS) {
    throw new Error(`body is ${body.length} characters; the limit is ${MAX_BODY_CHARS}.`);
  }
  if (BODY_CONTROL.test(body)) {
    throw new Error("body contains control characters other than tabs and line breaks.");
  }
  const from = input.from === undefined || input.from.trim() === "" ? null : checkAddress(input.from, "from");
  if (count === 0 && subject === "" && body === "") {
    throw new Error("Nothing to compose: give at least a recipient, a subject or a body.");
  }
  return { to, cc, bcc, subject, body, from };
}

/**
 * Opens a compose window in Mail.app, filled in, and leaves it to the user.
 *
 * Draft-first (#22) with the send half removed: there is no send verb in this
 * server at all, and none is planned. The confirmation is the user reading the
 * window and pressing Send — not a flag a model passes, because the model may
 * be acting on an email it just read.
 *
 * The window is created visible from the start. An invisible outgoing message
 * is what #58 hit: AppleScript cannot close or delete one, and it stopped Mail
 * from quitting. A visible one is an ordinary compose window the user can send,
 * save or close. Nothing here saves it either.
 */
export function composeDraft(input: ComposeInput, options: MailRunOptions & { dryRun?: boolean } = {}): ComposeResult {
  const { to, cc, bcc, subject, body, from } = validateCompose(input);
  const join = (list: string[]) => list.join("\u001f");
  const args = [subject, body, from ?? "", join(to), join(cc), join(bcc)];
  const base = { to, cc, bcc, subject, bodyChars: body.length, from };
  if (options.dryRun) {
    return {
      dryRun: true,
      opened: false,
      ...base,
      note: "Dry run — no window was opened, and Mail.app was not contacted, so the sender address is not checked.",
      arguments: args,
    };
  }
  const { dryRun: _dryRun, ...runOptions } = options;
  const out = runMailScript(COMPOSE_SCRIPT, args, { ...runOptions, explain: explainComposeFailure });
  if ((out ?? "").trim() !== "opened") {
    throw new Error(
      `Mail.app returned an unexpected answer (${JSON.stringify(out)}). A compose window may be open; ` +
        "check Mail before calling again.",
    );
  }
  return {
    dryRun: false,
    opened: true,
    ...base,
    note:
      "A compose window is open in Mail. Nothing has been sent or saved: the user reviews it and presses Send, " +
      "or closes it. Do not call again for the same message — that opens a second window.",
  };
}

function explainComposeFailure(message: string): string | null {
  if (/Compose window open but incomplete/i.test(message)) {
    return (
      `${message}. A compose window is already open in Mail with some fields missing. ` +
      "Finish or close it there rather than calling again."
    );
  }
  if (/Unknown sender/i.test(message)) {
    return `${message}. It is not an address of any account in Mail, so no window was opened.`;
  }
  return explainMailFailure(message);
}

/**
 * argv: subject, plain-text body, sender ("" for Mail's default), then the
 * to, cc and bcc addresses, each list joined by the unit separator. Every
 * value is an argument, never part of the script.
 *
 * The sender is checked against the accounts before any window opens. After
 * the window opens it is the user's, so a failure filling it in says the
 * window is there rather than reading as nothing having happened.
 *
 * There is no `send` and no `save` in this script, and a test pins that.
 */
const COMPOSE_SCRIPT = `
on run argv
  set theSubject to item 1 of argv
  set theBody to item 2 of argv
  set theSender to item 3 of argv
  set toList to my splitField(item 4 of argv)
  set ccList to my splitField(item 5 of argv)
  set bccList to my splitField(item 6 of argv)
  if theSender is not "" then
    set known to false
    my requireMail()
    tell application "Mail"
      repeat with anAccount in accounts
        if (email addresses of anAccount) contains theSender then set known to true
      end repeat
    end tell
    if not known then error "Unknown sender " & theSender
  end if
  my requireMail()
  tell application "Mail"
    set newMessage to make new outgoing message with properties {subject:theSubject, content:theBody, visible:true}
  end tell
  try
    my requireMail()
    tell application "Mail"
      if theSender is not "" then set sender of newMessage to theSender
      tell newMessage
        repeat with anAddress in toList
          make new to recipient at end of to recipients with properties {address:(contents of anAddress)}
        end repeat
        repeat with anAddress in ccList
          make new cc recipient at end of cc recipients with properties {address:(contents of anAddress)}
        end repeat
        repeat with anAddress in bccList
          make new bcc recipient at end of bcc recipients with properties {address:(contents of anAddress)}
        end repeat
      end tell
    end tell
  on error fillError
    error "Compose window open but incomplete: " & fillError
  end try
  return "opened"
end run

on splitField(value)
  if value is "" then return {}
  set AppleScript's text item delimiters to (character id 31)
  set parts to text items of value
  set AppleScript's text item delimiters to ""
  return parts
end splitField
`;

export { COMPOSE_SCRIPT };
