//
//  mail-write.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 19/09/2026.
//

import { switchEnabled, type SwitchName } from "./config.ts";
import type { ReadOnlyIndex } from "./db.ts";
import { NOT_FOUND_LOCALLY } from "./format.ts";
import { isTrashMailboxUrl, TRASH_MAILBOX_NAMES } from "./search.ts";
import { parseMailboxUrl } from "./store.ts";
import {
  explainMailFailure,
  LOCATE_MESSAGE_HANDLER,
  mailMessageRef,
  refArgs,
  runMailScript,
  type MailMessageRef,
  type MailRunOptions,
} from "./mail-bridge.ts";

export const WRITE_ENV = "APPLEMAIL_ENABLE_WRITE" satisfies SwitchName;

/**
 * Off unless explicitly set, and read when the server is built, so the mail
 * write tools are not merely refused — they do not exist in tools/list (#23).
 * Mail gets its own switch rather than sharing Calendar's or Reminders': each
 * server is registered separately, and enabling one kind of write must not
 * quietly enable another.
 */
export function writeEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
  return switchEnabled(WRITE_ENV, env);
}

export type WriteOptions = MailRunOptions & {
  dryRun?: boolean;
};

type TargetRow = {
  id: number;
  url: string;
  deleted: number;
  header: string | null;
};

/**
 * The index row a write is aimed at, with what Mail.app must agree on before
 * anything changes: where it lives and its Message-ID header.
 *
 * The header is the guard carried over from the #57 review. ROWIDs are
 * AUTOINCREMENT and never reused, but a mailbox rebuild recreates the index
 * and numbers from 1 again, so an id handed out before a rebuild can name a
 * different message after it. Matching the header as well means a stale id
 * fails instead of changing the wrong message.
 */
export function resolveWriteTarget(
  index: ReadOnlyIndex,
  id: number,
): { ref: MailMessageRef; messageIdHeader: string } {
  const hasGlobalData = index.get<{ n: number }>(
    `SELECT count(*) AS n FROM sqlite_master WHERE type = 'table' AND name = 'message_global_data'`,
  );
  if (!hasGlobalData?.n) {
    throw new Error("This envelope index has no message_global_data table, so a write cannot be verified. Refusing.");
  }
  const row = index.get<TargetRow>(
    `SELECT m.ROWID AS id, mb.url AS url, m.deleted AS deleted, g.message_id_header AS header
     FROM messages m
     JOIN mailboxes mb ON mb.ROWID = m.mailbox
     LEFT JOIN message_global_data g ON g.ROWID = m.global_message_id
     WHERE m.ROWID = ?`,
    [id],
  );
  if (!row) {
    throw new Error(`Message ${id}: ${NOT_FOUND_LOCALLY}`);
  }
  if (row.deleted) {
    throw new Error(`Message ${id} is deleted; refusing to change it.`);
  }
  const header = stripAngles(row.header);
  if (!header) {
    throw new Error(
      `Message ${id} has no Message-ID header in the index, so Mail.app's copy cannot be confirmed as the same message. Refusing.`,
    );
  }
  return { ref: mailMessageRef(row.url, id), messageIdHeader: header };
}

/** The index stores `<id@host>`; Mail's AppleScript `message id` has no brackets. */
function stripAngles(header: string | null): string {
  return (header ?? "").trim().replace(/^<(.*)>$/, "$1").trim();
}

/** The statuses Mail itself toggles, and how each is spoken about. */
const STATUSES = {
  flagged: { on: "flagged", off: "unflagged", doneOn: "Flagged", doneOff: "Unflagged" },
  read: { on: "read", off: "unread", doneOn: "Marked read", doneOff: "Marked unread" },
  junk: { on: "junk", off: "not junk", doneOn: "Marked junk", doneOff: "Marked not junk" },
} as const;

export type MailStatus = keyof typeof STATUSES;

type StatusResultBase = {
  id: number;
  dryRun: boolean;
  /** Whether Mail.app actually had to change anything; null on a dry run. */
  changed: boolean | null;
  note: string;
  arguments?: string[];
};

/** `flagged` is the flag as Mail.app reports it after the change; the requested value on a dry run. */
export type FlagResult = StatusResultBase & { flagged: boolean };

/** `read` is the read status as Mail.app reports it after the change; the requested value on a dry run. */
export type ReadResult = StatusResultBase & { read: boolean };

/**
 * `junk` is the junk status as Mail.app reports it after the change; the
 * requested value on a dry run; null when Mail could not be asked afterwards.
 */
export type JunkResult = StatusResultBase & { junk: boolean | null };

/**
 * Flags or unflags one message through Mail.app. The smallest write there is:
 * it changes a status Mail itself toggles, creates nothing, and is undone by
 * the opposite call.
 */
export function setFlag(index: ReadOnlyIndex, id: number, flagged: boolean, options: WriteOptions = {}): FlagResult {
  const { value, ...rest } = setStatus(index, id, "flagged", flagged, options);
  // Never null: only junk may come back unknown.
  return { ...rest, flagged: value === true };
}

/** Marks one message read or unread through Mail.app, on the same terms as setFlag. */
export function setRead(index: ReadOnlyIndex, id: number, read: boolean, options: WriteOptions = {}): ReadResult {
  const { value, ...rest } = setStatus(index, id, "read", read, options);
  return { ...rest, read: value === true };
}

/**
 * Marks one message junk or not junk through Mail.app, on the same terms as
 * setFlag (#64). It sets Mail's `junk mail status`, which is what trains the
 * junk filter; Mail's dictionary does not say it moves the message, and this
 * does not ask it to — moving to Junk is move_to_mailbox. Should Mail move it
 * anyway, the message can no longer be read back where it was, and the result
 * says the status is unknown rather than guessing.
 */
export function setJunk(index: ReadOnlyIndex, id: number, junk: boolean, options: WriteOptions = {}): JunkResult {
  const { value, ...rest } = setStatus(index, id, "junk", junk, options);
  return { ...rest, junk: value };
}

/**
 * Before touching the message, the script confirms Mail's copy has the
 * Message-ID header the index recorded; after, it reports the status Mail now
 * holds rather than the one that was asked for.
 */
function setStatus(
  index: ReadOnlyIndex,
  id: number,
  status: MailStatus,
  wanted: boolean,
  options: WriteOptions,
): StatusResultBase & { value: boolean | null } {
  const target = resolveWriteTarget(index, id);
  const args = [...refArgs(target.ref), target.messageIdHeader, wanted ? "1" : "0", status];
  const words = STATUSES[status];
  if (options.dryRun) {
    return {
      id,
      dryRun: true,
      value: wanted,
      changed: null,
      note: "Dry run — nothing was changed, and Mail.app was not contacted: the Message-ID is only checked on a real run.",
      arguments: args,
    };
  }
  const out = runMailScript(SET_STATUS_SCRIPT, args, { ...options, explain: explainWriteFailure });
  const fields = (out ?? "").split("\u001f");
  const [before, after] = fields;
  // Only junk may come back unknown afterwards: see SET_STATUS_SCRIPT.
  const unknownAfter = status === "junk" && after === "unknown";
  // Mail answered, but not in the shape this script returns. Reading defaults
  // out of it would report a status that was never observed, so it is an
  // error — and one that says the change may already have happened.
  if (fields.length !== 2 || !isBooleanText(before) || !(isBooleanText(after) || unknownAfter)) {
    throw new Error(
      `Mail.app returned an unexpected answer (${JSON.stringify(out)}), so message ${id}'s ${status} status is unknown. ` +
        "It may have changed; check the message in Mail before retrying.",
    );
  }
  if (unknownAfter) {
    return {
      id,
      dryRun: false,
      value: null,
      changed: null,
      note:
        `Asked Mail.app to mark it ${wanted ? words.on : words.off}, but could not read the message back where it was ` +
        "afterwards, so whether it changed is unknown. Mail may have moved it; search for it before retrying.",
    };
  }
  const now = after === "true";
  const word = now ? words.on : words.off;
  return {
    id,
    dryRun: false,
    value: now,
    changed: before !== after,
    note: before === after ? `Already ${word}; nothing changed.` : `${now ? words.doneOn : words.doneOff} in Mail.app.`,
  };
}

function isBooleanText(value: string | undefined): boolean {
  return value === "true" || value === "false";
}

function explainWriteFailure(message: string): string | null {
  if (/Move outcome unknown/i.test(message)) {
    return (
      `${message}. Mail.app raised an error while moving the message, so it may or may not have moved. ` +
      "Search for it before retrying; its id changes if it did move."
    );
  }
  if (/Junk outcome unknown/i.test(message)) {
    return (
      `${message}. Mail.app raised an error while changing the junk status, so it may or may not have changed. ` +
      "Check the message in Mail before retrying."
    );
  }
  if (/Message-ID mismatch/i.test(message)) {
    return (
      `${message}. Mail.app has a different message under this id than the index does — ` +
      "the index may have been rebuilt since the id was obtained. Nothing was changed; search again for a fresh id."
    );
  }
  return explainMailFailure(message);
}

/**
 * argv: accountId, mailbox, id (the locate triple), expected Message-ID,
 * "1"/"0", and which status: "flagged", "read" or "junk". The header check
 * comes before the write in the same script, so no other process can swap the
 * message in between.
 *
 * Junk is fenced like a move: if Mail did file a junk message elsewhere, the
 * reference to it would stop resolving, so an error from the write is
 * labelled as an unknown outcome and an unreadable status afterwards comes
 * back as "unknown" rather than as a plain failure.
 */
const SET_STATUS_SCRIPT = `
on run argv
  set theMessage to locateMessage(item 1 of argv, item 2 of argv, (item 3 of argv) as integer)
  set expectedHeader to item 4 of argv
  set wanted to (item 5 of argv is "1")
  set whichStatus to item 6 of argv
  if whichStatus is not "flagged" and whichStatus is not "read" and whichStatus is not "junk" then error "Unknown status " & whichStatus
  my requireMail()
  tell application "Mail"
    set actualHeader to message id of theMessage
  end tell
  -- AppleScript compares text case-insensitively unless told otherwise, and
  -- Message-IDs are case-sensitive.
  considering case
    if actualHeader is not expectedHeader then error "Message-ID mismatch for id " & (item 3 of argv)
  end considering
  my requireMail()
  tell application "Mail"
    if whichStatus is "flagged" then
      set wasSet to flagged status of theMessage
      if wasSet is not wanted then set flagged status of theMessage to wanted
      set nowSet to flagged status of theMessage
    else if whichStatus is "read" then
      set wasSet to read status of theMessage
      if wasSet is not wanted then set read status of theMessage to wanted
      set nowSet to read status of theMessage
    else
      set wasSet to junk mail status of theMessage
      if wasSet is not wanted then
        try
          set junk mail status of theMessage to wanted
        on error junkError
          error "Junk outcome unknown: " & junkError
        end try
      end if
      try
        set nowSet to junk mail status of theMessage
      on error
        set nowSet to "unknown"
      end try
    end if
  end tell
  set AppleScript's text item delimiters to (character id 31)
  return {wasSet as text, nowSet as text} as text
end run
${LOCATE_MESSAGE_HANDLER}`;

export { SET_STATUS_SCRIPT };

/**
 * Mail's flag colours in `flag index` order: 0 is red through 6 grey, and -1
 * is no flag. Checked against Mail's dictionary on macOS 26.6 ("The flag on
 * the message, or -1 if the message is not flagged") and a flagged message
 * reading back 2 for yellow on 2026-10-21.
 */
export const FLAG_COLORS = ["red", "orange", "yellow", "green", "blue", "purple", "gray"] as const;

export type FlagColor = (typeof FLAG_COLORS)[number];

/** `color` is the flag as Mail.app reports it after the change, null when unflagged; the requested value on a dry run. */
export type FlagColorResult = StatusResultBase & { flagged: boolean; color: FlagColor | null };

/**
 * Flags one message with a given colour through Mail.app (#64), or clears the
 * flag with null. The same terms as setFlag: Message-ID check first, then the
 * colour Mail holds afterwards is what is reported. Undo by setting the
 * previous colour, which the note names.
 */
export function setFlagColor(
  index: ReadOnlyIndex,
  id: number,
  color: FlagColor | null,
  options: WriteOptions = {},
): FlagColorResult {
  const wanted = color === null ? -1 : FLAG_COLORS.indexOf(color);
  if (color !== null && wanted < 0) {
    throw new Error(`Unknown flag colour ${JSON.stringify(color)}. Use one of ${FLAG_COLORS.join(", ")}.`);
  }
  const target = resolveWriteTarget(index, id);
  const args = [...refArgs(target.ref), target.messageIdHeader, String(wanted)];
  if (options.dryRun) {
    return {
      id,
      dryRun: true,
      flagged: color !== null,
      color,
      changed: null,
      note: "Dry run — nothing was changed, and Mail.app was not contacted: the Message-ID is only checked on a real run.",
      arguments: args,
    };
  }
  const out = runMailScript(SET_FLAG_COLOR_SCRIPT, args, { ...options, explain: explainWriteFailure });
  const fields = (out ?? "").split("\u001f");
  const [before, after] = fields.map(flagIndexColor);
  if (fields.length !== 2 || before === undefined || after === undefined) {
    throw new Error(
      `Mail.app returned an unexpected answer (${JSON.stringify(out)}), so message ${id}'s flag is unknown. ` +
        "It may have changed; check the message in Mail before retrying.",
    );
  }
  const name = (c: FlagColor | null) => (c === null ? "unflagged" : `flagged ${c}`);
  return {
    id,
    dryRun: false,
    flagged: after !== null,
    color: after,
    changed: before !== after,
    note: before === after ? `Already ${name(after)}; nothing changed.` : `Was ${name(before)}; now ${name(after)} in Mail.app.`,
  };
}

/** A `flag index` as Mail returns it, as a colour; null for -1; undefined for anything else. */
function flagIndexColor(text: string): FlagColor | null | undefined {
  if (!/^-?\d+$/.test(text)) return undefined;
  const n = Number(text);
  if (n === -1) return null;
  return FLAG_COLORS[n];
}

/**
 * argv: the locate triple, expected Message-ID, wanted `flag index` (-1 to
 * clear). Returns the flag index before and after, as integers.
 */
const SET_FLAG_COLOR_SCRIPT = `
on run argv
  set theMessage to locateMessage(item 1 of argv, item 2 of argv, (item 3 of argv) as integer)
  set expectedHeader to item 4 of argv
  set wanted to (item 5 of argv) as integer
  if wanted < -1 or wanted > 6 then error "Unknown flag index " & wanted
  my requireMail()
  tell application "Mail"
    set actualHeader to message id of theMessage
  end tell
  considering case
    if actualHeader is not expectedHeader then error "Message-ID mismatch for id " & (item 3 of argv)
  end considering
  my requireMail()
  tell application "Mail"
    set wasIndex to flag index of theMessage
    if wasIndex is not wanted then set flag index of theMessage to wanted
    set nowIndex to flag index of theMessage
  end tell
  set AppleScript's text item delimiters to (character id 31)
  return {wasIndex as text, nowIndex as text} as text
end run
${LOCATE_MESSAGE_HANDLER}`;

export { SET_FLAG_COLOR_SCRIPT };

export type MoveResult = {
  id: number;
  dryRun: boolean;
  from: string;
  to: string;
  /**
   * The message's id in the destination. Mail files a moved message as a new
   * one, so the old id stops working; null when the move happened but the
   * message had not appeared in the destination yet.
   */
  newId: number | null;
  /** Whether the destination belongs to a different account than the source. */
  crossAccount: boolean;
  /**
   * Whether the message is still in the source mailbox afterwards — a
   * cross-account move that copied but failed to delete leaves it in both.
   * null when the move was not run, or when Mail could not be asked.
   */
  sourceRemains: boolean | null;
  note: string;
  arguments?: string[];
};

/** How long to wait for a moved message to appear in its destination. Four seconds on the development store. */
export const MOVE_SETTLE_SECONDS = 20;

/**
 * The same wait for a cross-account move, which is a copy to another server
 * and not a re-filing within one: the message is uploaded before it can appear
 * in the destination, so the within-account figure is optimistic.
 */
export const CROSS_ACCOUNT_SETTLE_SECONDS = 60;

/**
 * Moves one message to another mailbox of the same account, through Mail.app.
 *
 * Checked on this Mac on 2026-09-19 with a move to Archive and back: Mail
 * files a moved message as a new one (128698 became 128699, then 128700), the
 * Message-ID header survives, and the copy took about four seconds to appear.
 * So the result carries the new id, found in the destination by Message-ID —
 * the id the caller had is dead after the move.
 *
 * The destination is the exact `url` list_mailboxes returns, so a mailbox is
 * never picked by a partial name. Moves across accounts need `allowCrossAccount`
 * (#66): Mail does those as a copy and a delete between two servers, which can
 * fail half-way and leave the message in both, so it is not something to do by
 * merely naming a mailbox that happens to be elsewhere.
 */
export function moveMessage(
  index: ReadOnlyIndex,
  id: number,
  destinationUrl: string,
  options: WriteOptions & { settleSeconds?: number; allowCrossAccount?: boolean } = {},
): MoveResult {
  const target = resolveWriteTarget(index, id);
  const from = index.get<{ url: string }>(
    `SELECT mb.url AS url FROM messages m JOIN mailboxes mb ON mb.ROWID = m.mailbox WHERE m.ROWID = ?`,
    [id],
  )!.url;
  const destination = index.get<{ url: string }>(`SELECT url FROM mailboxes WHERE url = ?`, [destinationUrl]);
  if (!destination) {
    throw new Error(`No mailbox with url ${destinationUrl}. Pass a url exactly as list_mailboxes returns it.`);
  }
  // Only the account and mailbox are needed; the id is a placeholder.
  const to = mailMessageRef(destination.url, 1);
  const crossAccount = to.accountId !== target.ref.accountId;
  if (crossAccount && options.allowCrossAccount !== true) {
    throw new Error(
      "Moving between accounts is refused unless it is asked for: Mail does it as a copy and a delete across " +
        "servers, which can fail half-way and leave the message in both. Pass allowCrossAccount (CLI: " +
        "--cross-account) to do it anyway, or pick a mailbox in the message's own account.",
    );
  }
  // Account as well as name: two accounts can both have an "Archive", and
  // within one account the url and the resolved name agree.
  if (!crossAccount && to.mailbox === target.ref.mailbox) {
    throw new Error(`Message ${id} is already in ${destination.url}.`);
  }

  // At least one second: at zero the script would not look even once, and
  // report every move as having no known new id.
  const fallback = crossAccount ? CROSS_ACCOUNT_SETTLE_SECONDS : MOVE_SETTLE_SECONDS;
  const asked = options.settleSeconds ?? fallback;
  const settle = Number.isFinite(asked) ? Math.max(1, Math.floor(asked)) : fallback;
  const args = [
    ...refArgs(target.ref),
    target.messageIdHeader,
    to.accountId ?? "",
    to.mailbox,
    String(settle),
  ];
  if (options.dryRun) {
    return {
      id,
      dryRun: true,
      from,
      to: destination.url,
      newId: null,
      crossAccount,
      sourceRemains: null,
      note:
        "Dry run — nothing was moved, and Mail.app was not contacted: the Message-ID is only checked on a real run." +
        (crossAccount ? " This is a cross-account move: a copy to the other server, then a delete here." : ""),
      arguments: args,
    };
  }
  const out = runMailScript(MOVE_SCRIPT, args, { ...options, explain: explainWriteFailure });
  // Two fields: the new id — or "moved" when the move happened but the copy
  // had not shown up within the settle time — and what the source mailbox
  // holds afterwards. Anything else means the answer cannot be trusted either
  // way, so no shape is guessed at.
  const answer = (out ?? "").trim();
  const fields = answer.split("\u001f");
  const [moved = "", source = ""] = fields;
  const known = moved === "moved" || /^\d+$/.test(moved);
  // The field count is part of the shape, as it is for setStatus: a third
  // field is an answer from a script this code does not know, and reading the
  // first two out of it would report a move it never confirmed.
  if (fields.length !== 2 || !known || !["gone", "remains", "unknown"].includes(source)) {
    throw new Error(
      `Mail.app returned an unexpected answer (${JSON.stringify(out)}), so it is unknown whether message ${id} moved. ` +
        "Check the message in Mail before retrying.",
    );
  }
  const newId = moved === "moved" ? null : Number(moved);
  return {
    id,
    dryRun: false,
    from,
    to: destination.url,
    newId,
    crossAccount,
    sourceRemains: source === "unknown" ? null : source === "remains",
    note: moveNote({ id, newId, source, settle, from, crossAccount }),
  };
}

/**
 * What the caller is told after a real move. Each clause answers a question
 * the next call depends on: which id to use now, whether to go looking rather
 * than retrying, and whether a copy was left behind that only the user can
 * clear up — there is no delete verb here to do it with.
 */
function moveNote(outcome: {
  id: number;
  newId: number | null;
  source: string;
  settle: number;
  from: string;
  crossAccount: boolean;
}): string {
  const { id, newId, source, settle, from, crossAccount } = outcome;
  const parts: string[] = [];
  if (newId === null) {
    parts.push(
      `Moved, but it had not appeared in the destination after ${settle}s, so its new id is not known yet. ` +
        "Search for it rather than moving it again.",
    );
  } else {
    parts.push(`Moved. Its id is now ${newId}; ${id} no longer refers to it.`);
  }
  if (source === "remains") {
    parts.push(
      `The message is still in ${from} as well` +
        (crossAccount
          ? ": Mail copies to the other account and then deletes here, and the delete did not take. " +
            "Delete the copy in Mail — this server has no delete verb."
          : ", which a move should not leave behind. Check it in Mail before acting on either copy."),
    );
  } else if (source === "unknown") {
    parts.push(`Whether anything is left in ${from} could not be confirmed; check it in Mail.`);
  } else if (newId !== null && !crossAccount) {
    parts.push(`Move ${newId} back to undo.`);
  } else if (newId !== null) {
    parts.push(`Gone from ${from}. Moving ${newId} back is itself another cross-account move.`);
  }
  return parts.join(" ");
}

/**
 * argv: the locate triple, expected Message-ID, destination account id ("" for
 * an On My Mac mailbox, which belongs to no account), destination mailbox,
 * seconds to wait for it to arrive. The destination account is its own
 * argument rather than the source's, which is what lets the destination be in
 * another account (#66). Copies already in the destination with the same
 * Message-ID are noted first, so the one returned is the copy this move made.
 *
 * Returns two fields: the new id or "moved", and what the source mailbox holds
 * afterwards. The source is checked by id, which is unambiguous: a message
 * Mail re-filed is gone from there under any id, while a cross-account copy
 * whose delete failed is still sitting there under the one it always had.
 */
const MOVE_SCRIPT = `
on run argv
  set accountId to item 1 of argv
  set mailboxName to item 2 of argv
  set messageId to (item 3 of argv) as integer
  set theMessage to locateMessage(accountId, mailboxName, messageId)
  set expectedHeader to item 4 of argv
  set destinationAccountId to item 5 of argv
  set destinationName to item 6 of argv
  set settleSeconds to (item 7 of argv) as integer
  my requireMail()
  tell application "Mail"
    set actualHeader to message id of theMessage
  end tell
  considering case
    if actualHeader is not expectedHeader then error "Message-ID mismatch for id " & messageId
  end considering
  my requireMail()
  tell application "Mail"
    if destinationAccountId is "" then
      set destinationMailbox to mailbox destinationName
    else
      set destinationMailbox to mailbox destinationName of account id destinationAccountId
    end if
    set existingIds to id of (messages of destinationMailbox whose message id is expectedHeader)
    -- Past this point the message may already have moved, so no error may
    -- read as a plain failure: that would invite a retry with a dead id, or a
    -- second move of a message that already went.
    try
      move theMessage to destinationMailbox
    on error moveError
      error "Move outcome unknown: " & moveError
    end try
  end tell
  set newId to "moved"
  -- The wait runs outside the tell, so each poll re-checks that Mail is still
  -- running: the loop is long enough for Mail to quit inside it, and an
  -- unguarded query would then relaunch it.
  try
    set waited to 0
    repeat while waited < settleSeconds * 2
      my requireMail()
      tell application "Mail"
        set candidates to (messages of destinationMailbox whose message id is expectedHeader)
        repeat with candidate in candidates
          set candidateId to id of candidate
          if existingIds does not contain candidateId then
            set newId to candidateId as text
            exit repeat
          end if
        end repeat
      end tell
      if newId is not "moved" then exit repeat
      delay 0.5
      set waited to waited + 1
    end repeat
  on error
    -- The move call returned, so the message went; only its new id is unknown.
    set newId to "moved"
  end try
  return newId & (character id 31) & my sourceState(accountId, mailboxName, messageId)
end run

-- Never raises: the move has already happened by the time this runs, so a
-- failure here may only downgrade the report to "unknown", not turn a
-- completed move into an error.
on sourceState(accountId, mailboxName, messageId)
  try
    my requireMail()
    tell application "Mail"
      if accountId is "" then
        set theMailbox to mailbox mailboxName
      else
        set theMailbox to mailbox mailboxName of account id accountId
      end if
      if (count of (messages of theMailbox whose id is messageId)) is 0 then return "gone"
    end tell
    return "remains"
  on error
    return "unknown"
  end try
end sourceState
${LOCATE_MESSAGE_HANDLER}`;

export { MOVE_SCRIPT };

/** The most ids one move_to_trash call takes, each being a move of its own. */
export const MAX_TRASH_IDS = 50;

export type TrashOutcome =
  | ({ ok: true; trash: string; guessed: boolean } & MoveResult)
  | { ok: false; id: number; error: string };

export type TrashResult = {
  dryRun: boolean;
  moved: number;
  failed: number;
  results: TrashOutcome[];
};

/**
 * Moves messages to their own account's Trash through Mail.app (#73), one at
 * a time, reporting each id's outcome so one failure does not hide the rest.
 *
 * Nothing is deleted. Mail's `delete` would do, but with an account's "move
 * deleted messages to the Trash" setting off it marks the message deleted in
 * place instead, and the server expunges it. So this is a plain move, to the
 * mailbox Mail itself names as that account's Trash, and an account Mail
 * names none for is refused. The index records no mailbox roles, so a dry run
 * cannot ask Mail and guesses from the name instead; `guessed` says so.
 */
export function trashMessages(
  index: ReadOnlyIndex,
  ids: number[],
  options: WriteOptions & { settleSeconds?: number } = {},
): TrashResult {
  const unique = [...new Set(ids)];
  if (unique.length === 0) {
    throw new Error("No message ids given.");
  }
  if (unique.length > MAX_TRASH_IDS) {
    throw new Error(`At most ${MAX_TRASH_IDS} messages per call; got ${unique.length}.`);
  }
  // Asked once per call, and only on a real run: a dry run does not contact Mail.
  let trashes: Map<string, string> | null = null;
  const results: TrashOutcome[] = [];
  for (const id of unique) {
    try {
      const target = resolveWriteTarget(index, id);
      const account = target.ref.accountId ?? "";
      let trash: string;
      let guessed: boolean;
      if (options.dryRun) {
        trash = guessTrashUrl(index, target.ref);
        guessed = true;
      } else {
        trashes ??= askTrashMailboxes(options);
        const path = trashes.get(account);
        if (path === undefined) {
          throw new Error(
            `Mail.app names no Trash mailbox for ${account ? `account ${account}` : "On My Mac"}, so message ${id} ` +
              "was not moved. Nothing is ever deleted outright.",
          );
        }
        trash = indexUrlFor(index, target.ref, path);
        guessed = false;
      }
      const moved = moveMessage(index, id, trash, options);
      results.push({ ok: true, trash, guessed, ...moved });
    } catch (error) {
      results.push({ ok: false, id, error: error instanceof Error ? error.message : String(error) });
    }
  }
  const moved = results.filter((r) => r.ok).length;
  return { dryRun: options.dryRun === true, moved, failed: results.length - moved, results };
}

/** The index mailbox, in the message's own account, whose url names a Trash; refused unless exactly one does. */
function guessTrashUrl(index: ReadOnlyIndex, ref: MailMessageRef): string {
  const found = sameAccountMailboxes(index, ref).filter((m) => isTrashMailboxUrl(m.url));
  // The same preference order as the names: iCloud also carries an unused
  // "Deleted Items", and its Trash is "Deleted Messages".
  for (const name of TRASH_MAILBOX_NAMES) {
    const match = found.filter((m) => m.path.split("/").pop()?.toLowerCase() === name.toLowerCase());
    if (match.length === 1) return match[0].url;
    if (match.length > 1) {
      throw new Error(`More than one mailbox in this account looks like its Trash: ${match.map((m) => m.url).join(", ")}.`);
    }
  }
  throw new Error(
    `No mailbox in this account is named like a Trash (${TRASH_MAILBOX_NAMES.join(", ")}). ` +
      "A real run asks Mail.app instead, which may still find one.",
  );
}

/** Mail's path for a Trash, as an index url in the message's own account. */
function indexUrlFor(index: ReadOnlyIndex, ref: MailMessageRef, path: string): string {
  // Mail's name and the index's encoded url need not use the same Unicode
  // normalisation, as search's mailbox filter already allows for.
  const wanted = path.normalize("NFC");
  const match = sameAccountMailboxes(index, ref).filter((m) => m.path.normalize("NFC") === wanted);
  if (match.length !== 1) {
    throw new Error(
      `Mail.app names "${path}" as this account's Trash, but the index has ${match.length === 0 ? "no" : "more than one"} ` +
        "mailbox of that path in the account. Nothing was moved.",
    );
  }
  return match[0].url;
}

function sameAccountMailboxes(index: ReadOnlyIndex, ref: MailMessageRef): { url: string; path: string }[] {
  return index
    .all<{ url: string }>(`SELECT url FROM mailboxes`)
    .map((row) => ({ url: row.url, parsed: parseMailboxUrl(row.url) }))
    .filter(({ parsed }) =>
      ref.accountId === null ? parsed.scheme === "local" : parsed.scheme !== "local" && parsed.accountId === ref.accountId,
    )
    .map(({ url, parsed }) => ({ url, path: parsed.path }));
}

/** Account id ("" for On My Mac) to the path of the mailbox Mail uses as its Trash. */
function askTrashMailboxes(options: MailRunOptions): Map<string, string> {
  const out = runMailScript(TRASH_MAILBOXES_SCRIPT, [], { ...options, explain: explainWriteFailure }) ?? "";
  const trashes = new Map<string, string>();
  for (const line of out.split("\n")) {
    if (!line.trim()) continue;
    const fields = line.split("\u001f");
    if (fields.length !== 2 || !fields[1]) {
      throw new Error(`Mail.app returned an unexpected answer (${JSON.stringify(out)}) when asked for its Trash mailboxes.`);
    }
    trashes.set(fields[0], fields[1]);
  }
  return trashes;
}

/**
 * Read-only. Lists the mailboxes inside Mail's top-level Trash, one per
 * account, each as its account id ("" for On My Mac) and its full path.
 * Mail's `name` is only the last segment — Gmail's Trash is "Trash" inside
 * "[Gmail]" — so the path is rebuilt through each mailbox's container.
 * Checked on 2026-10-20: iCloud gives "Deleted Messages", Google
 * "[Gmail]/Trash", On My Mac "Deleted Messages".
 */
const TRASH_MAILBOXES_SCRIPT = `
on run argv
  set rows to {}
  my requireMail()
  tell application "Mail"
    repeat with theMailbox in (mailboxes of trash mailbox)
      set accountId to ""
      try
        set accountId to id of (account of theMailbox)
      end try
      set end of rows to accountId & (character id 31) & my mailboxPath(theMailbox)
    end repeat
  end tell
  set AppleScript's text item delimiters to linefeed
  return rows as text
end run

-- "parent" is reserved in AppleScript, hence the longer names.
on mailboxPath(theMailbox)
  my requireMail()
  tell application "Mail"
    set thePath to name of theMailbox
    set current to theMailbox
    repeat 32 times
      try
        set enclosing to container of current
        set enclosingClass to class of enclosing as text
      on error
        exit repeat
      end try
      if enclosingClass is not "container" and enclosingClass is not "mailbox" then exit repeat
      set thePath to (name of enclosing) & "/" & thePath
      set current to enclosing
    end repeat
  end tell
  return thePath
end mailboxPath
`;

export { TRASH_MAILBOXES_SCRIPT };
