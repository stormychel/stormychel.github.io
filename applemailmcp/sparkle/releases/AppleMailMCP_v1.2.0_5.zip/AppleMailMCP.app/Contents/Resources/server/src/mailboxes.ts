//
//  mailboxes.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 13/08/2026.
//

import type { ReadOnlyIndex } from "./db.ts";
import { parseMailboxUrl } from "./store.ts";
import type { AccountRow, MailboxRow } from "./types.ts";

type RawMailbox = {
  id: number;
  url: string;
  total_count: number;
  unread_count: number;
};

export function listMailboxes(index: ReadOnlyIndex): MailboxRow[] {
  const rows = index.all<RawMailbox>(
    `SELECT ROWID AS id, url, total_count, unread_count
     FROM mailboxes
     ORDER BY url`,
  );
  return rows.map((row) => {
    const parsed = parseMailboxUrl(row.url);
    return {
      id: row.id,
      url: row.url,
      scheme: parsed.scheme,
      accountId: parsed.accountId,
      path: parsed.path,
      totalCount: row.total_count,
      unreadCount: row.unread_count,
    };
  });
}

export function listAccounts(index: ReadOnlyIndex): AccountRow[] {
  const counts = new Map<string, AccountRow>();
  for (const mailbox of listMailboxes(index)) {
    const key = `${mailbox.scheme}://${mailbox.accountId}`;
    const existing = counts.get(key);
    if (existing) {
      existing.mailboxCount += 1;
    } else {
      counts.set(key, {
        scheme: mailbox.scheme,
        id: mailbox.accountId,
        mailboxCount: 1,
      });
    }
  }
  return [...counts.values()].sort((a, b) => a.scheme.localeCompare(b.scheme) || a.id.localeCompare(b.id));
}
