//
//  message.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 13/08/2026.
//

import { MailParser, type AttachmentStream, type MessageText } from "mailparser";
import type { Readable } from "node:stream";
import type { ReadOnlyIndex } from "./db.ts";
import { openEmlxRfc822Clipped, resolveBodyFile } from "./emlx.ts";
import { htmlToText } from "./html.ts";
import { NOT_FOUND_LOCALLY } from "./format.ts";
import { wrapIndexError } from "./schema.ts";
import { search } from "./search.ts";
import type { AttachmentInfo, BodyAvailability, MailStore, SearchRow } from "./types.ts";

export const DEFAULT_BODY_CHARS = 8000;
export const MAX_BODY_CHARS = 20000;

export type MessageDetail = SearchRow & {
  bodyStatus: BodyAvailability;
  body: string | null;
  bodyLength: number;
  bodyOffset: number;
  bodyTruncated: boolean;
  nextOffset: number | null;
  attachments: AttachmentInfo[];
  note: string;
  /** Why a body file that exists could not be turned into text. */
  bodyError?: string;
};

/**
 * Errors that say something about the process rather than the message. ENOENT
 * is deliberately absent: a file removed between resolving and reading is this
 * message's body going away, which "unavailable" describes correctly.
 */
export const OPERATIONAL_CODES = new Set(["EACCES", "EPERM", "EMFILE", "ENFILE"]);

export type ThreadResult = {
  conversationId: number;
  count: number;
  limit: number;
  note: string;
  messages: SearchRow[];
};

export async function getMessage(
  index: ReadOnlyIndex,
  store: MailStore | null,
  id: number,
  options: { offset?: number; maxBodyChars?: number } = {},
): Promise<MessageDetail> {
  const found = search(index, { id, includeDeleted: true, limit: 1 }, { store });
  if (found.count === 0 || !found.messages[0]) {
    throw new Error(`Message ${id}: ${NOT_FOUND_LOCALLY}`);
  }
  const row = found.messages[0];
  const resolved = store ? resolveBodyFile(store, id, row.mailbox) : { status: "unavailable" as const, path: null };

  // A body that cannot be produced degrades to metadata, as the Stage 2
  // contract promises, rather than failing the whole call and hiding the
  // sender, subject and date the index already answered. The reason is kept
  // apart from "not found locally": the file is there, it just did not parse.
  //
  // Only for faults in this one message, though. A permission error or file
  // descriptor exhaustion is about the process, not the message, and folding
  // it in would scatter one operational fault across many "unreadable" results.
  let parsed: Awaited<ReturnType<typeof parseRfc822>> | null = null;
  let bodyError: string | null = null;
  if (resolved.path) {
    try {
      parsed = await parseRfc822(resolved.path);
    } catch (error) {
      if (OPERATIONAL_CODES.has((error as { code?: string }).code ?? "")) {
        throw wrapIndexError(error, `failed to read the body of message ${id}`);
      }
      bodyError = error instanceof Error ? error.message : String(error);
    }
  }
  const status: BodyAvailability = bodyError ? "unavailable" : resolved.status;
  const attachments = parsed?.attachments ?? indexAttachments(index, id);
  const rawBody = parsed?.text ?? null;
  const sliced = sliceBody(rawBody, options.offset ?? 0, options.maxBodyChars ?? DEFAULT_BODY_CHARS);

  return {
    ...row,
    "body-availability": status,
    "has-attachments": row["has-attachments"] || attachments.length > 0,
    bodyStatus: status,
    body: sliced.body,
    bodyLength: sliced.bodyLength,
    bodyOffset: sliced.bodyOffset,
    bodyTruncated: sliced.bodyTruncated,
    nextOffset: sliced.nextOffset,
    attachments,
    note: bodyError
      ? `The body file exists locally but could not be read: ${bodyError}`
      : status === "unavailable"
        ? NOT_FOUND_LOCALLY
        : found.note,
    ...(bodyError ? { bodyError } : {}),
  };
}

export function getThread(
  index: ReadOnlyIndex,
  store: MailStore | null,
  id: number,
  options: { limit?: number } = {},
): ThreadResult {
  const seed = search(index, { id, includeDeleted: true, limit: 1 }, { store });
  if (seed.count === 0 || !seed.messages[0]) {
    throw new Error(`Message ${id}: ${NOT_FOUND_LOCALLY}`);
  }
  const conversationId = seed.messages[0].conversationId;
  // A shared sentinel (0 or -1) means "not threaded". Treating only 0 that way
  // would return up to `limit` unrelated messages dressed up as a thread.
  if (!conversationId || conversationId <= 0) {
    return {
      conversationId: 0,
      count: 1,
      limit: 1,
      note: seed.note,
      messages: seed.messages,
    };
  }
  const thread = search(index, { conversationId, limit: options.limit }, { store });

  // The seed is looked up with includeDeleted, so a deleted message can be
  // asked about by id and then be missing from its own thread. Passing
  // includeDeleted to the thread query as well would fix that but expose
  // deleted siblings on every ordinary thread.
  //
  // Absence from the thread is not enough to justify re-adding it either: a
  // live message can simply have fallen outside `limit`, and re-adding it there
  // returns limit + 1 rows. Ask specifically whether the seed is deleted.
  const present = thread.messages.some((message) => message.id === id);
  const seedIsDeleted = !present && search(index, { id, limit: 1 }, { store }).count === 0;

  let messages = thread.messages;
  if (!present && seedIsDeleted) {
    // Re-adding the seed must not silently exceed the caller's limit, so drop
    // the oldest sibling to make room rather than returning limit + 1 rows.
    messages = [...thread.messages, ...seed.messages].sort(byNewestFirst);
    while (messages.length > thread.limit) {
      const lastOther = messages.map((message) => message.id).lastIndexOf(id) === messages.length - 1
        ? messages.length - 2
        : messages.length - 1;
      messages = messages.filter((_, index) => index !== lastOther);
    }
  }

  return {
    conversationId,
    count: messages.length,
    limit: thread.limit,
    note: thread.note,
    messages,
  };
}

/**
 * Matches the SQL ORDER BY date_received DESC; undated rows sort last.
 *
 * Compared as instants rather than as strings: an ISO year past 9999 is
 * formatted "+010000-…", which sorts before "9999-…" lexically and would
 * reverse the SQL ordering.
 */
function byNewestFirst(a: SearchRow, b: SearchRow): number {
  // Compared, not subtracted: two undated rows are both -Infinity, and
  // -Infinity minus -Infinity is NaN, which makes the comparator non-total.
  const left = instantOf(a);
  const right = instantOf(b);
  if (left === right) {
    return 0;
  }
  return left > right ? -1 : 1;
}

function instantOf(row: SearchRow): number {
  if (row.date === null) {
    return Number.NEGATIVE_INFINITY;
  }
  const parsed = Date.parse(row.date);
  return Number.isNaN(parsed) ? Number.NEGATIVE_INFINITY : parsed;
}

function sliceBody(
  text: string | null,
  offset: number,
  maxChars: number,
): { body: string | null; bodyLength: number; bodyOffset: number; bodyTruncated: boolean; nextOffset: number | null } {
  if (text === null) {
    return { body: null, bodyLength: 0, bodyOffset: 0, bodyTruncated: false, nextOffset: null };
  }
  const start = Math.max(0, Math.floor(offset));
  const cap = Math.min(Math.max(1, Math.floor(maxChars)), MAX_BODY_CHARS);
  const body = text.slice(start, start + cap);
  const truncated = start + body.length < text.length;
  return {
    body,
    bodyLength: text.length,
    bodyOffset: start,
    bodyTruncated: truncated,
    nextOffset: truncated ? start + body.length : null,
  };
}

/**
 * Streams the message through mailparser rather than buffering it (#36).
 * `simpleParser` needs the whole file in memory and then holds every decoded
 * attachment as well, only for this code to report their names and sizes: a
 * 23 MB message with four photos peaked at 297 MB. Here each attachment is
 * counted as it passes and let go, so memory no longer grows with it.
 */
export function parseRfc822(
  path: string,
  options: { textOnly?: boolean; maxBytes?: number } = {},
): Promise<{ text: string | null; attachments: AttachmentInfo[]; clipped: boolean }> {
  return new Promise((resolve, reject) => {
    const attachments: AttachmentInfo[] = [];
    let plain = "";
    let html = "";
    let settled = false;
    const fail = (error: unknown) => {
      if (!settled) {
        settled = true;
        source.destroy();
        parser.destroy();
        reject(error);
      }
    };

    // Opening reads and validates the length line synchronously, so a
    // malformed file rejects here with the same errors as before.
    let source: Readable;
    let clipped = false;
    try {
      ({ stream: source, clipped } = openEmlxRfc822Clipped(path, options.maxBytes));
    } catch (error) {
      reject(error);
      return;
    }
    // textOnly is the body search's mode (#30). mailparser otherwise renders
    // every plain part to HTML and every HTML-only part to text with its own
    // converter, which was most of a 21 ms per-message parse on a real store.
    // Skipping both leaves the HTML-only case to htmlToText below.
    const parser = new MailParser(
      options.textOnly
        ? { skipHtmlToText: true, skipTextToHtml: true, skipTextLinks: true, skipImageLinks: true }
        : {},
    );

    parser.on("data", (data: AttachmentStream | MessageText) => {
      if (data.type === "attachment") {
        const entry: AttachmentInfo = {
          name: data.filename ?? null,
          size: null,
          contentType: data.contentType ?? null,
        };
        attachments.push(entry);
        // The parser waits for release() before it moves on, and the content
        // must be read for the byte count to exist. resume() reads it without
        // keeping any of it.
        data.content.on("end", () => {
          entry.size = typeof data.size === "number" ? data.size : null;
          data.release();
        });
        data.content.on("error", fail);
        data.content.resume();
      } else if (data.type === "text") {
        plain = typeof data.text === "string" ? data.text : "";
        html = typeof data.html === "string" ? data.html : "";
      }
    });
    parser.on("error", fail);
    source.on("error", fail);
    parser.on("end", () => {
      if (settled) {
        return;
      }
      settled = true;
      const trimmed = plain.trim();
      resolve({ text: trimmed || (html ? htmlToText(html) : null), attachments, clipped });
    });
    source.pipe(parser);
  });
}

function indexAttachments(index: ReadOnlyIndex, messageId: number): AttachmentInfo[] {
  const rows = index.all<{ name: string | null }>(
    `SELECT name FROM attachments WHERE message = ?`,
    [messageId],
  );
  return rows.map((row) => ({ name: row.name, size: null, contentType: null }));
}
