#!/usr/bin/env node
//
//  messages-cli.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 09/09/2026.
//

import { parseDateInput } from "./format.ts";
import {
  decodeCursor,
  getConversation,
  listChats,
  listHandles,
  searchMessages,
} from "./messages/messages.ts";
import { openMessagesSession } from "./messages/session.ts";

const USAGE = `Usage:
  applemsg list-chats [options]
  applemsg list-handles [options]
  applemsg search [options]
  applemsg conversation --chat-id <n> [options]
  applemsg mcp

Read-only throughout: the live chat.db is never opened by SQLite, it is
APFS-cloned to a temp snapshot first. There is no write path.

Most messages store their body in an encoded attributedBody blob rather than in
the text column, so a --text search decodes as it scans. The output reports
scanned, scanTruncated and exhausted; only exhausted says whether every
candidate was examined, since filling the limit also stops the scan early.

Options:
  --db <path>            chat.db (skips live-store detection)
  --text <text>          Message body substring (search)
  --from <handle>        Sender handle substring (search)
  --chat <text>          Chat name / identifier / participant substring
  --chat-id <n>          chat.ROWID (search, conversation)
  --query <text>         Filter (list-chats, list-handles)
  --after <date>         Lower bound: ISO-8601, YYYYMMDD or unix epoch
  --before <date>        Upper bound, inclusive
  --cursor <token>       nextCursor from a previous conversation call
  --from-me              Only messages you sent
  --to-me                Only messages you received
  --service <name>       iMessage, SMS or RCS
  --with-attachments     Only messages carrying an attachment
  --reactions            Include tapback and sticker rows
  --system-events        Include renames, joins, leaves and calls
  --max-chars <n>        Truncate each body (conversation)
  --limit <n>            Max rows (default 50, hard cap 1000)
  --help                 Show this help
`;

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  if (args.length === 0 || args.includes("--help") || args.includes("-h")) {
    process.stdout.write(USAGE);
    process.exit(args.length === 0 ? 1 : 0);
  }

  const command = args[0];
  if (command.startsWith("-")) {
    fail(`missing command. ${USAGE}`);
  }

  if (command === "mcp") {
    const { startStdioServer } = await import("./messages-server.ts");
    await startStdioServer();
    return;
  }

  const flags = parseFlags(args.slice(1));
  const session = openMessagesSession({ dbPath: flags.db });
  try {
    if (command === "list-chats") {
      printJson(listChats(session.index, { query: flags.query, limit: flags.limit }));
      return;
    }
    if (command === "list-handles") {
      printJson(listHandles(session.index, { query: flags.query, limit: flags.limit }));
      return;
    }
    if (command === "search") {
      printJson(
        searchMessages(
          session.index,
          {
            text: flags.text,
            from: flags.from,
            chat: flags.chat,
            chatId: flags.chatId,
            after: flags.after ? parseDateInput(flags.after) : undefined,
            before: flags.before ? parseDateInput(flags.before) : undefined,
            isFromMe: flags.isFromMe,
            service: flags.service,
            withAttachments: flags.withAttachments,
            includeReactions: flags.reactions,
            includeSystemEvents: flags.systemEvents,
            limit: flags.limit,
          },
          { store: session.store },
        ),
      );
      return;
    }
    if (command === "conversation") {
      if (flags.chatId === undefined) {
        fail("--chat-id is required for conversation (list-chats shows them)");
      }
      printJson(
        getConversation(session.index, flags.chatId, {
          limit: flags.limit,
          before: flags.before ? parseDateInput(flags.before) : undefined,
          cursor: flags.cursor ? decodeCursor(flags.cursor) : undefined,
          maxChars: flags.maxChars,
          includeReactions: flags.reactions,
          includeSystemEvents: flags.systemEvents,
          store: session.store,
        }),
      );
      return;
    }
    fail(`unknown command: ${command}\n${USAGE}`);
  } finally {
    session.close();
  }
}

type Flags = {
  db?: string;
  text?: string;
  from?: string;
  chat?: string;
  chatId?: number;
  cursor?: string;
  query?: string;
  after?: string;
  before?: string;
  isFromMe?: boolean;
  service?: string;
  withAttachments?: boolean;
  reactions?: boolean;
  systemEvents?: boolean;
  maxChars?: number;
  limit?: number;
};

function parseFlags(argv: string[]): Flags {
  const flags: Flags = {};
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    const next = (): string => {
      const value = argv[i + 1];
      if (value === undefined) {
        fail(`missing value for ${arg}`);
      }
      i += 1;
      return value;
    };
    const nextNumber = (label: string): number => {
      const value = Number(next());
      if (!Number.isFinite(value)) {
        fail(`${label} must be a number`);
      }
      return value;
    };
    switch (arg) {
      case "--db":
        flags.db = next();
        break;
      case "--text":
        flags.text = next();
        break;
      case "--from":
        flags.from = next();
        break;
      case "--chat":
        flags.chat = next();
        break;
      case "--chat-id":
        flags.chatId = nextNumber("--chat-id");
        break;
      case "--cursor":
        flags.cursor = next();
        break;
      case "--query":
        flags.query = next();
        break;
      case "--after":
        flags.after = next();
        break;
      case "--before":
        flags.before = next();
        break;
      case "--from-me":
        flags.isFromMe = true;
        break;
      case "--to-me":
        flags.isFromMe = false;
        break;
      case "--service":
        flags.service = next();
        break;
      case "--with-attachments":
        flags.withAttachments = true;
        break;
      case "--reactions":
        flags.reactions = true;
        break;
      case "--system-events":
        flags.systemEvents = true;
        break;
      case "--max-chars":
        flags.maxChars = nextNumber("--max-chars");
        break;
      case "--limit":
        flags.limit = nextNumber("--limit");
        break;
      default:
        fail(`unknown option: ${arg}`);
    }
  }
  return flags;
}

function printJson(value: unknown): void {
  process.stdout.write(`${JSON.stringify(value, null, 2)}\n`);
}

function fail(message: string): never {
  process.stderr.write(`${message}\n`);
  process.exit(1);
}

main().catch((error) => {
  process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
  process.exit(1);
});
