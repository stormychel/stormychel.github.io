#!/usr/bin/env node
//
//  messages-server.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 09/09/2026.
//

import { basename } from "node:path";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { reportHealth } from "./health.ts";
import { findMessagesStore, messagesRootForHome } from "./messages/store.ts";
import { parseDateInput } from "./format.ts";
import {
  decodeCursor,
  getConversation,
  listChats,
  listHandles,
  searchMessages,
} from "./messages/messages.ts";
import { openMessagesSession, type MessagesSession } from "./messages/session.ts";

export const MCP_DEFAULT_LIMIT = 20;
export const MCP_MAX_LIMIT = 50;

const READ_ONLY = {
  readOnlyHint: true,
  destructiveHint: false,
  idempotentHint: true,
  openWorldHint: false,
} as const;

const limitSchema = z.number().int().min(1).max(MCP_MAX_LIMIT).optional();

export function createMessagesServer(
  sessionFactory: () => MessagesSession = () => openMessagesSession(),
): McpServer {
  const server = new McpServer({
    name: "applemessages",
    version: "0.4.0",
    title: "Apple Messages (read-only)",
  });

  const withSession = async (fn: (session: MessagesSession) => Promise<unknown> | unknown) => {
    // Opening the session is inside the try on purpose: a locked database, an
    // exhausted snapshot retry or a missing Full Disk Access grant has to come
    // back in the same {error: ...} envelope as every other failure.
    let session: MessagesSession | null = null;
    try {
      session = sessionFactory();
      const result = await fn(session);
      return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      return {
        isError: true,
        content: [{ type: "text" as const, text: JSON.stringify({ error: message }, null, 2) }],
      };
    } finally {
      session?.close();
    }
  };

  server.registerTool(
    "search_messages",
    {
      title: "Search Messages",
      description:
        "Read-only search of the Messages store on this Mac, across iMessage, SMS and RCS. " +
        "Most messages keep their body in an encoded blob rather than a text column, so matching " +
        "happens after decoding — a text search is therefore a scan. `exhausted` says whether every " +
        "candidate was examined; a short or empty result with exhausted:false means the scan stopped, " +
        "not that nothing more exists. A zero-result search means not found locally. Bodies come back as " +
        "snippets; use get_conversation for full text. Reactions and system events are excluded " +
        "unless asked for. Results are capped.",
      inputSchema: {
        text: z.string().optional().describe("Substring of the message body, case-insensitive"),
        from: z.string().optional().describe("Sender handle substring (phone number or email)"),
        chat: z
          .string()
          .optional()
          .describe("Chat name, identifier or participant handle substring"),
        chatId: z.number().int().positive().optional().describe("chat.ROWID from list_chats"),
        after: z.string().optional().describe("Lower bound: ISO-8601, YYYYMMDD, or a unix epoch of 9+ digits"),
        before: z.string().optional().describe("Upper bound: ISO-8601, YYYYMMDD, or a unix epoch of 9+ digits"),
        isFromMe: z.boolean().optional().describe("true for messages you sent, false for received"),
        service: z.string().optional().describe("Exact service: iMessage, SMS or RCS"),
        withAttachments: z.boolean().optional().describe("Only messages carrying an attachment"),
        includeReactions: z.boolean().optional().describe("Include tapback and sticker rows"),
        includeSystemEvents: z.boolean().optional().describe("Include renames, joins, leaves and calls"),
        limit: limitSchema.describe(`Max rows (default ${MCP_DEFAULT_LIMIT}, cap ${MCP_MAX_LIMIT})`),
      },
      annotations: READ_ONLY,
    },
    async (args) =>
      withSession((session) =>
        searchMessages(
          session.index,
          {
            text: args.text,
            from: args.from,
            chat: args.chat,
            chatId: args.chatId,
            after: args.after ? parseDateInput(args.after) : undefined,
            before: args.before ? parseDateInput(args.before) : undefined,
            isFromMe: args.isFromMe,
            service: args.service,
            withAttachments: args.withAttachments,
            includeReactions: args.includeReactions,
            includeSystemEvents: args.includeSystemEvents,
            limit: args.limit ?? MCP_DEFAULT_LIMIT,
          },
          { store: session.store },
        ),
      ),
  );

  server.registerTool(
    "get_conversation",
    {
      title: "Get Conversation",
      description:
        "Read-only transcript of one chat, oldest first, with full message bodies. To page " +
        "backwards, pass the returned nextCursor straight back as cursor; it is null once the " +
        "chat's first message is in the page. Do not build a cursor from a timestamp — the date " +
        "column is finer-grained than any timestamp you can write, so a hand-made one skips " +
        "messages. Capped.",
      inputSchema: {
        chatId: z.number().int().positive().describe("chat.ROWID, as returned by list_chats"),
        cursor: z
          .string()
          .optional()
          .describe("Opaque token from a previous call's nextCursor — the exact previous page"),
        before: z
          .string()
          .optional()
          .describe("Coarse inclusive upper bound (ISO-8601, YYYYMMDD or unix epoch). For paging, use cursor"),
        maxChars: z.number().int().min(1).max(20000).optional().describe("Truncate each body to this length"),
        includeReactions: z.boolean().optional(),
        includeSystemEvents: z.boolean().optional(),
        limit: limitSchema.describe(`Max rows (default ${MCP_DEFAULT_LIMIT}, cap ${MCP_MAX_LIMIT})`),
      },
      annotations: READ_ONLY,
    },
    async (args) =>
      withSession((session) =>
        getConversation(session.index, args.chatId, {
          limit: args.limit ?? MCP_DEFAULT_LIMIT,
          before: args.before ? parseDateInput(args.before) : undefined,
          cursor: args.cursor ? decodeCursor(args.cursor) : undefined,
          maxChars: args.maxChars,
          includeReactions: args.includeReactions,
          includeSystemEvents: args.includeSystemEvents,
          store: session.store,
        }),
      ),
  );

  server.registerTool(
    "list_chats",
    {
      title: "List Chats",
      description:
        "Read-only list of conversations, most recently active first, with participants and message " +
        "counts. Use the returned id with get_conversation.",
      inputSchema: {
        query: z
          .string()
          .optional()
          .describe("Filter by chat name, identifier or participant handle substring"),
        limit: limitSchema.describe(`Max rows (default ${MCP_DEFAULT_LIMIT}, cap ${MCP_MAX_LIMIT})`),
      },
      annotations: READ_ONLY,
    },
    async (args) =>
      withSession((session) =>
        listChats(session.index, { query: args.query, limit: args.limit ?? MCP_DEFAULT_LIMIT }),
      ),
  );

  server.registerTool(
    "list_handles",
    {
      title: "List Handles",
      description:
        "Read-only list of the phone numbers and email addresses known to Messages, busiest first. " +
        "Handles are stored canonicalised (E.164), so search by the trailing digits rather than the " +
        "national form.",
      inputSchema: {
        query: z.string().optional().describe("Filter by handle substring"),
        limit: limitSchema.describe(`Max rows (default ${MCP_DEFAULT_LIMIT}, cap ${MCP_MAX_LIMIT})`),
      },
      annotations: READ_ONLY,
    },
    async (args) =>
      withSession((session) =>
        listHandles(session.index, { query: args.query, limit: args.limit ?? MCP_DEFAULT_LIMIT }),
      ),
  );

  return server;
}

export async function startStdioServer(): Promise<void> {
  // Which app started this server, and whether its store opened under it (#99).
  reportHealth("messages", () => findMessagesStore().dbPath, messagesRootForHome());
  const server = createMessagesServer();
  const transport = new StdioServerTransport();
  await server.connect(transport);
}

// basename, not endsWith, for the same reason as the mail server: a suffix test
// would start this server whenever another *-server.ts is the entry point and
// anything pulls this module in — two servers on one stdio.
const entry = basename(process.argv[1] ?? "");
if (entry === "messages-server.ts" || entry === "messages-server.js") {
  startStdioServer().catch((error) => {
    process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
    process.exit(1);
  });
}
