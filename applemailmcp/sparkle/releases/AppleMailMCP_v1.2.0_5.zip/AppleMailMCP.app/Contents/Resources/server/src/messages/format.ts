//
//  format.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 09/09/2026.
//

import { epochToIso, parseDateInput } from "../format.ts";
import { APPLE_EPOCH_OFFSET } from "../calendar/format.ts";
import type { ClassicReaction, ReactionRow } from "./types.ts";

/**
 * Messages writes `date` as **nanoseconds** since 2001-01-01 on macOS 10.13+,
 * and as **seconds** since the same epoch on anything older. Stores migrated
 * across that boundary carry both, so the scale is decided per value rather than
 * per database: a seconds value large enough to be mistaken for nanoseconds
 * would be the year 25146, and a nanosecond value small enough to pass as
 * seconds would be 1970 — neither is reachable, so the threshold is unambiguous.
 *
 * The scaling normally happens in SQL (see `appleSeconds` in ./messages.ts —
 * nanosecond values exceed 2^53 and `node:sqlite` refuses to narrow them), so
 * values usually arrive here already in seconds. The threshold is kept because
 * this function is the one place that owns the conversion, and a caller reading
 * a raw column directly should still get the right answer rather than a date
 * 25,000 years out.
 */
const NANOSECOND_THRESHOLD = 1e12;

export function appleDateToUnix(value: number | null | undefined): number | null {
  if (value === null || value === undefined || !Number.isFinite(value) || value === 0) {
    return null;
  }
  const seconds = Math.abs(value) > NANOSECOND_THRESHOLD ? value / 1e9 : value;
  return seconds + APPLE_EPOCH_OFFSET;
}

export function appleDateToIso(value: number | null | undefined): string | null {
  return epochToIso(appleDateToUnix(value));
}

export function unixToAppleSeconds(unixSeconds: number): number {
  return unixSeconds - APPLE_EPOCH_OFFSET;
}

export function unixToAppleNanoseconds(unixSeconds: number): number {
  return unixToAppleSeconds(unixSeconds) * 1e9;
}

/**
 * Keeps sub-second precision, which `parseDateInput` deliberately discards.
 * A conversation cursor needs it: several messages can share a second, and a
 * cursor floored to that second either repeats them or skips them.
 *
 * The all-digit forms (`YYYYMMDD`, a unix epoch) have no sub-second part to
 * preserve, so they are handed to the shared parser rather than reimplemented —
 * including its guard against reading a compact date as an epoch.
 */
export function parseInstant(value: string): number {
  const trimmed = value.trim();
  if (/^\d+$/.test(trimmed)) {
    return parseDateInput(trimmed);
  }
  const parsed = Date.parse(trimmed);
  if (Number.isNaN(parsed)) {
    throw new Error(`Invalid date: ${value} (use ISO-8601, e.g. 2024-01-01T12:00:00.500Z)`);
  }
  return parsed / 1000;
}

const CLASSIC_REACTIONS: readonly ClassicReaction[] = [
  "love",
  "like",
  "dislike",
  "laugh",
  "emphasize",
  "question",
];

/**
 * `associated_message_type` encodes both the reaction and whether it was added
 * or taken back: 2000–2005 add a classic tapback, 3000–3005 remove the same one
 * in the same order, and 2006/3006 are the emoji tapbacks macOS 14 added. 1000
 * is a sticker stuck onto a message. Every value observed on the store checked
 * here is covered; an unknown one returns null rather than being reported as
 * some neighbouring reaction.
 */
export function resolveReaction(
  associatedType: number | null,
  targetGuid: string | null,
  emoji: string | null,
): ReactionRow | null {
  if (associatedType === null || associatedType === 0) {
    return null;
  }
  const target = normalizeTargetGuid(targetGuid);
  if (associatedType >= 2000 && associatedType <= 2005) {
    return { action: "add", kind: "classic", type: CLASSIC_REACTIONS[associatedType - 2000], emoji: null, targetGuid: target };
  }
  if (associatedType >= 3000 && associatedType <= 3005) {
    return { action: "remove", kind: "classic", type: CLASSIC_REACTIONS[associatedType - 3000], emoji: null, targetGuid: target };
  }
  if (associatedType === 2006) {
    return { action: "add", kind: "emoji", type: null, emoji, targetGuid: target };
  }
  if (associatedType === 3006) {
    return { action: "remove", kind: "emoji", type: null, emoji, targetGuid: target };
  }
  if (associatedType === 1000) {
    return { action: "add", kind: "sticker", type: null, emoji: null, targetGuid: target };
  }
  return null;
}

/** True for the rows a plain conversation read should leave out. */
export function isReactionType(associatedType: number | null): boolean {
  if (associatedType === null || associatedType === 0) {
    return false;
  }
  return (
    associatedType === 1000 ||
    (associatedType >= 2000 && associatedType <= 3006)
  );
}

/**
 * `associated_message_guid` is prefixed with the part of the message the
 * reaction landed on — `p:0/<guid>` for the first part, `bp:<guid>` for a
 * whole-balloon reaction. The prefix is dropped so the value joins against
 * `message.guid`.
 */
function normalizeTargetGuid(guid: string | null): string | null {
  if (guid === null || guid === "") {
    return null;
  }
  const slash = guid.lastIndexOf("/");
  if (slash >= 0) {
    return guid.slice(slash + 1);
  }
  const colon = guid.indexOf(":");
  return colon >= 0 ? guid.slice(colon + 1) : guid;
}

/**
 * `item_type` marks rows that are not messages at all but records of something
 * happening to the chat. They are excluded by default because a search for
 * "Michel" should not return the day someone named a group after him.
 *
 * Only what is verifiable on a real store is named. `item_type = 2` was
 * confirmed by reading `group_title`, which holds the new name; `item_type = 1`
 * splits cleanly on `group_action_type` 0/1 across 142 rows. `item_type` 4 and 6
 * appear with `text`, `group_title` and `group_action_type` all empty, so there
 * is nothing here to establish what they mean — they get a label that says which
 * type it was rather than a confident guess at a neighbouring meaning.
 *
 * `group_action_type` is deliberately not consulted for `item_type = 3`: it
 * takes five distinct values there, none of which this store explains.
 */
export function systemEventLabel(
  itemType: number | null,
  groupActionType: number | null,
  groupTitle: string | null,
): string | null {
  if (itemType === null || itemType === 0) {
    return null;
  }
  switch (itemType) {
    case 1:
      return groupActionType === 1 ? "participant removed" : "participant added";
    case 2:
      return groupTitle === null || groupTitle === ""
        ? "group renamed"
        : `group renamed to ${groupTitle}`;
    case 3:
      return "participant left";
    default:
      return `chat event (item_type ${itemType})`;
  }
}

/** chat.style: 43 is a group, 45 is one-to-one. */
export const GROUP_CHAT_STYLE = 43;
