//
//  messages.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 09/09/2026.
//

import { join } from "node:path";
import { DEFAULT_LIMIT, MAX_LIMIT, type ReadOnlyIndex } from "../db.ts";
import { clampLimit, likeContains } from "../format.ts";
import {
  appleDateToIso,
  appleDateToUnix,
  GROUP_CHAT_STYLE,
  isReactionType,
  resolveReaction,
  systemEventLabel,
  unixToAppleNanoseconds,
  unixToAppleSeconds,
} from "./format.ts";
import { isPlaceholderOnly, messageText } from "./typedstream.ts";
import type {
  AttachmentRow,
  ChatRow,
  HandleRow,
  MessageQuery,
  MessageRow,
  MessagesStore,
} from "./types.ts";

/** Characters of body text kept per row in a search result. */
export const SNIPPET_CHARS = 280;

/**
 * Ceiling on rows examined for one text search. A text match is decided in JS,
 * so an unmatched query would otherwise walk the whole archive; scanning stops
 * here and the result says so, which is the difference between "no more matches"
 * and "stopped looking".
 */
export const MAX_SCAN = 60_000;

const LOCAL_ONLY_NOTE =
  "Results are from the Messages store on this Mac only. A zero-result search means not found locally, not that the message never existed.";

const NOT_FOUND_LOCALLY = "not found locally";

/**
 * `message.date` is nanoseconds since 2001-01-01, which for any recent message
 * exceeds 2^53 — `node:sqlite` refuses to narrow such an integer to a JavaScript
 * number and throws rather than silently losing precision. Scaling to seconds in
 * SQL keeps the value inside the safe range before it is ever bound.
 *
 * The scale is decided per row for the reason given in ./format.ts: a store
 * migrated across macOS 10.13 carries both nanosecond and second values. A
 * comparison against both bounds is used rather than `ABS`, which SQLite
 * refuses on the most negative int64 ("integer overflow") — an unreachable date,
 * but a query that throws is a worse answer than one that returns nothing.
 * NULL compares false either way, so an absent date falls through and stays NULL.
 *
 * Only the SELECT list is scaled. Range bounds stay on the raw column so
 * `message_idx_date` is still usable, and the rounding a double introduces
 * there is under a microsecond.
 */
function appleSeconds(column: string): string {
  return (
    `CASE WHEN ${column} > 1e12 OR ${column} < -1e12` +
    ` THEN ${column} / 1000000000.0 ELSE ${column} * 1.0 END`
  );
}

/**
 * A range bound has to be stated on both date scales, because which one a row
 * uses is a property of the row (see ./format.ts). Comparing a nanosecond bound
 * against a seconds-scale row is wrong in both directions: `after` drops a 2012
 * message that does match, and `before` admits one that does not.
 *
 * Each disjunct keeps a bare `m.date <op> ?` term so `message_idx_date` stays
 * usable for it; the range test only narrows which rows the branch owns. A row
 * with no date at all (0) cannot satisfy a range and is excluded outright,
 * rather than comparing as the year 2001.
 */
function dateBound(comparison: ">=" | "<=", unixSeconds: number): {
  sql: string;
  params: unknown[];
} {
  return {
    sql:
      `(m.date != 0 AND (` +
      `((m.date > 1e12 OR m.date < -1e12) AND m.date ${comparison} ?)` +
      ` OR (m.date <= 1e12 AND m.date >= -1e12 AND m.date ${comparison} ?)))`,
    params: [unixToAppleNanoseconds(unixSeconds), unixToAppleSeconds(unixSeconds)],
  };
}

type RawMessage = {
  id: number;
  guid: string | null;
  text: string | null;
  attributedBody: unknown;
  /** Scaled to seconds, for display. Lossy above 2^53 — never used to page. */
  date: number | null;
  /** The column verbatim, as text so 64 bits survive. The paging key. */
  date_raw: string | null;
  date_edited: number | null;
  date_retracted: number | null;
  is_from_me: number;
  item_type: number | null;
  group_action_type: number | null;
  group_title: string | null;
  associated_message_type: number | null;
  associated_message_guid: string | null;
  service: string | null;
  handle: string | null;
  destination_caller_id: string | null;
  chat_id: number | null;
  chat_name: string | null;
  chat_style: number | null;
  has_attachments: number;
};

export type SearchResult = {
  count: number;
  limit: number;
  scanned: number;
  /** True when MAX_SCAN was hit before the candidate set ran out. */
  scanTruncated: boolean;
  /**
   * True only when every candidate row was examined. `scanTruncated: false` on
   * its own does not mean this — a search that filled its limit also stopped
   * early — so the one question a caller actually has ("is a zero or short
   * result the whole answer?") is answered directly rather than inferred.
   */
  exhausted: boolean;
  note: string;
  source: "local";
  snapshot: boolean;
  messages: MessageRow[];
};

export function searchMessages(
  index: ReadOnlyIndex,
  query: MessageQuery = {},
  options: { store?: MessagesStore | null; maxScan?: number } = {},
): SearchResult {
  // Overridable only so a test can actually reach the ceiling; no fixture is
  // going to hold 60,000 messages, and a ceiling nothing exercises is a ceiling
  // that can be deleted without a test noticing.
  const maxScan = options.maxScan ?? MAX_SCAN;
  const limit = clampLimit(query.limit, DEFAULT_LIMIT, MAX_LIMIT);
  const needle = query.text?.toLowerCase();
  const { sql, params } = buildMessageSql(query, needle === undefined ? limit : null);

  const store = options.store ?? null;
  const collected: MessageRow[] = [];
  let scanned = 0;
  let scanTruncated = false;
  let stoppedEarly = false;

  for (const raw of index.iterate<RawMessage>(sql, params)) {
    scanned++;
    // Matched against the whole body and only then trimmed to a snippet.
    // Trimming first would make anything past SNIPPET_CHARS unfindable, which
    // is the same confident-empty-answer failure as not decoding the blob.
    const row = toMessageRow(raw, store);
    if (needle !== undefined && !(row.text ?? "").toLowerCase().includes(needle)) {
      if (scanned >= maxScan) {
        scanTruncated = true;
        stoppedEarly = true;
        break;
      }
      continue;
    }
    collected.push(applySnippet(row, SNIPPET_CHARS));
    if (collected.length >= limit) {
      stoppedEarly = true;
      break;
    }
    if (scanned >= maxScan) {
      scanTruncated = true;
      stoppedEarly = true;
      break;
    }
  }

  // Attachments are fetched for the rows that survived, not for every row
  // scanned — a text search can walk tens of thousands of candidates.
  attachRows(index, collected, store);

  return {
    count: collected.length,
    limit,
    scanned,
    scanTruncated,
    exhausted: !stoppedEarly,
    note: collected.length === 0 ? NOT_FOUND_LOCALLY : LOCAL_ONLY_NOTE,
    source: "local",
    snapshot: index.openedViaSnapshot,
    messages: collected,
  };
}

export type ConversationResult = {
  chat: ChatRow | null;
  count: number;
  limit: number;
  note: string;
  snapshot: boolean;
  /**
   * Opaque token for the previous page — pass straight back as `cursor`. Null
   * when the chat's first message is already in this page. Handing the caller a
   * token beats documenting how to build one: every timestamp a caller could
   * reconstruct is coarser than the column, so it would either repeat the
   * boundary row or skip its neighbours.
   */
  nextCursor: string | null;
  messages: MessageRow[];
};

/**
 * One chat's messages, newest last so the transcript reads in order. Reactions
 * are folded onto nothing — they come back as their own rows when asked for,
 * because attributing them to a target needs a second pass the caller may not
 * want to pay for.
 */
export function getConversation(
  index: ReadOnlyIndex,
  chatId: number,
  options: {
    limit?: number;
    /** Coarse inclusive upper bound in unix seconds, as in search. */
    before?: number;
    /** Exact exclusive paging cursor, from a previous call's nextCursor. */
    cursor?: { rawDate: bigint | null; id: number };
    maxChars?: number;
    includeReactions?: boolean;
    includeSystemEvents?: boolean;
    store?: MessagesStore | null;
  } = {},
): ConversationResult {
  const limit = clampLimit(options.limit, DEFAULT_LIMIT, MAX_LIMIT);
  const chat = getChat(index, chatId);
  if (chat === null) {
    throw new Error(`No chat with ROWID ${chatId}. Use list_chats to find one.`);
  }

  // One more than asked for, purely to learn whether an older page exists —
  // the extra row is dropped rather than returned.
  const { sql, params } = buildMessageSql(
    {
      chatId,
      before: options.before,
      cursor: options.cursor,
      includeReactions: options.includeReactions,
      includeSystemEvents: options.includeSystemEvents,
    },
    limit + 1,
  );
  const store = options.store ?? null;
  const raws = index.all<RawMessage>(sql, params);
  const hasOlder = raws.length > limit;
  const kept = raws.slice(0, limit);
  // Built from the raw scaled value, before it is narrowed to an ISO string.
  const last = kept.at(-1);
  const rows = kept
    .map((raw) => applySnippet(toMessageRow(raw, store), options.maxChars))
    .reverse();
  attachRows(index, rows, store);

  return {
    chat,
    count: rows.length,
    limit,
    note: LOCAL_ONLY_NOTE,
    snapshot: index.openedViaSnapshot,
    // A dateless boundary row still yields a cursor — see encodeCursor.
    nextCursor: hasOlder && last != null ? encodeCursor(last.date_raw, last.id) : null,
    messages: rows,
  };
}

export function listChats(
  index: ReadOnlyIndex,
  options: { query?: string; limit?: number } = {},
): { count: number; limit: number; snapshot: boolean; chats: ChatRow[] } {
  const limit = clampLimit(options.limit, DEFAULT_LIMIT, MAX_LIMIT);
  const where: string[] = [];
  const params: unknown[] = [];
  if (options.query) {
    where.push(
      `(c.display_name LIKE ? ESCAPE '#' OR c.chat_identifier LIKE ? ESCAPE '#' OR EXISTS (
         SELECT 1 FROM chat_handle_join chj JOIN handle h ON h.ROWID = chj.handle_id
         WHERE chj.chat_id = c.ROWID AND h.id LIKE ? ESCAPE '#'
       ))`,
    );
    const like = likeContains(options.query);
    params.push(like, like, like);
  }
  params.push(limit);

  const rows = index.all<{
    id: number;
    guid: string | null;
    identifier: string | null;
    name: string | null;
    service: string | null;
    style: number | null;
    message_count: number;
    last_message: number | null;
  }>(
    `SELECT
       c.ROWID AS id,
       c.guid AS guid,
       c.chat_identifier AS identifier,
       c.display_name AS name,
       c.service_name AS service,
       c.style AS style,
       (SELECT COUNT(*) FROM chat_message_join cmj WHERE cmj.chat_id = c.ROWID) AS message_count,
       (SELECT ${appleSeconds("MAX(m.date)")} FROM chat_message_join cmj
          JOIN message m ON m.ROWID = cmj.message_id
          WHERE cmj.chat_id = c.ROWID) AS last_message
     FROM chat c
     ${where.length > 0 ? `WHERE ${where.join(" AND ")}` : ""}
     ORDER BY last_message DESC
     LIMIT ?`,
    params,
  );

  const chats = rows.map((row) => ({
    id: row.id,
    guid: row.guid,
    identifier: row.identifier,
    name: row.name === "" ? null : row.name,
    service: row.service,
    isGroup: row.style === GROUP_CHAT_STYLE,
    participants: participantsFor(index, row.id),
    messageCount: row.message_count,
    lastMessage: appleDateToIso(row.last_message),
  }));

  return { count: chats.length, limit, snapshot: index.openedViaSnapshot, chats };
}

export function listHandles(
  index: ReadOnlyIndex,
  options: { query?: string; limit?: number } = {},
): { count: number; limit: number; snapshot: boolean; handles: HandleRow[] } {
  const limit = clampLimit(options.limit, DEFAULT_LIMIT, MAX_LIMIT);
  const where: string[] = [];
  const params: unknown[] = [];
  if (options.query) {
    where.push("(h.id LIKE ? ESCAPE '#' OR h.uncanonicalized_id LIKE ? ESCAPE '#')");
    const like = likeContains(options.query);
    params.push(like, like);
  }
  params.push(limit);

  const rows = index.all<{
    id: number;
    handle: string | null;
    service: string | null;
    uncanonicalized: string | null;
    chat_count: number;
  }>(
    `SELECT
       h.ROWID AS id,
       h.id AS handle,
       h.service AS service,
       h.uncanonicalized_id AS uncanonicalized,
       (SELECT COUNT(*) FROM chat_handle_join chj WHERE chj.handle_id = h.ROWID) AS chat_count
     FROM handle h
     ${where.length > 0 ? `WHERE ${where.join(" AND ")}` : ""}
     ORDER BY chat_count DESC, h.id ASC
     LIMIT ?`,
    params,
  );

  return {
    count: rows.length,
    limit,
    snapshot: index.openedViaSnapshot,
    handles: rows.map((row) => ({
      id: row.id,
      handle: row.handle,
      service: row.service,
      uncanonicalized: row.uncanonicalized,
      chatCount: row.chat_count,
    })),
  };
}

function getChat(index: ReadOnlyIndex, chatId: number): ChatRow | null {
  const row = index.get<{
    id: number;
    guid: string | null;
    identifier: string | null;
    name: string | null;
    service: string | null;
    style: number | null;
    message_count: number;
    last_message: number | null;
  }>(
    `SELECT
       c.ROWID AS id, c.guid AS guid, c.chat_identifier AS identifier,
       c.display_name AS name, c.service_name AS service, c.style AS style,
       (SELECT COUNT(*) FROM chat_message_join cmj WHERE cmj.chat_id = c.ROWID) AS message_count,
       (SELECT ${appleSeconds("MAX(m.date)")} FROM chat_message_join cmj
          JOIN message m ON m.ROWID = cmj.message_id WHERE cmj.chat_id = c.ROWID) AS last_message
     FROM chat c WHERE c.ROWID = ?`,
    [chatId],
  );
  if (row === undefined) {
    return null;
  }
  return {
    id: row.id,
    guid: row.guid,
    identifier: row.identifier,
    name: row.name === "" ? null : row.name,
    service: row.service,
    isGroup: row.style === GROUP_CHAT_STYLE,
    participants: participantsFor(index, row.id),
    messageCount: row.message_count,
    lastMessage: appleDateToIso(row.last_message),
  };
}

function participantsFor(index: ReadOnlyIndex, chatId: number): string[] {
  return index
    .all<{ handle: string | null }>(
      `SELECT h.id AS handle FROM chat_handle_join chj
       JOIN handle h ON h.ROWID = chj.handle_id
       WHERE chj.chat_id = ? ORDER BY h.id`,
      [chatId],
    )
    .map((row) => row.handle)
    .filter((handle): handle is string => handle !== null && handle !== "");
}

function buildMessageSql(
  query: MessageQuery,
  limit: number | null,
): { sql: string; params: unknown[] } {
  const where: string[] = [];
  const params: unknown[] = [];

  if (query.chatId !== undefined) {
    where.push("cmj.chat_id = ?");
    params.push(query.chatId);
  }
  if (query.chat) {
    where.push(
      `(c.display_name LIKE ? ESCAPE '#' OR c.chat_identifier LIKE ? ESCAPE '#' OR EXISTS (
         SELECT 1 FROM chat_handle_join chj JOIN handle h2 ON h2.ROWID = chj.handle_id
         WHERE chj.chat_id = c.ROWID AND h2.id LIKE ? ESCAPE '#'
       ))`,
    );
    const like = likeContains(query.chat);
    params.push(like, like, like);
  }
  if (query.from) {
    where.push("h.id LIKE ? ESCAPE '#'");
    params.push(likeContains(query.from));
  }
  if (query.after !== undefined) {
    const bound = dateBound(">=", query.after);
    where.push(bound.sql);
    params.push(...bound.params);
  }
  if (query.before !== undefined) {
    const bound = dateBound("<=", query.before);
    where.push(bound.sql);
    params.push(...bound.params);
  }
  if (query.cursor !== undefined) {
    // Strictly after the cursor row in the (date DESC, ROWID DESC) order.
    //
    // Compared against the raw column, not the scaled one, so the predicate and
    // the ORDER BY are the same key. Scaling to seconds loses precision above
    // 2^53 — roughly 128ns at present timestamps — so two rows the sort
    // separates can compare equal once scaled, and the ROWID tiebreak then
    // discards one of them. Bound as BigInt because that is the whole point:
    // a JS number cannot hold the value the column does.
    if (query.cursor.rawDate === null) {
      // Already in the dateless tail; only lower ROWIDs remain after it.
      where.push("(m.date IS NULL AND m.ROWID < ?)");
      params.push(query.cursor.id);
    } else {
      where.push("(m.date IS NULL OR m.date < ? OR (m.date = ? AND m.ROWID < ?))");
      params.push(query.cursor.rawDate, query.cursor.rawDate, query.cursor.id);
    }
  }
  if (query.isFromMe !== undefined) {
    where.push("m.is_from_me = ?");
    params.push(query.isFromMe ? 1 : 0);
  }
  if (query.service) {
    where.push("m.service = ?");
    params.push(query.service);
  }
  if (query.withAttachments) {
    where.push(
      `EXISTS (SELECT 1 FROM message_attachment_join maj WHERE maj.message_id = m.ROWID)`,
    );
  }
  if (!query.includeReactions) {
    // 1000 sticker, 2000-3006 tapbacks. Excluded by default so a search for a
    // word does not come back with the dozen "Liked ..." rows it produced.
    where.push(
      `(m.associated_message_type IS NULL OR m.associated_message_type = 0
        OR NOT (m.associated_message_type = 1000
                OR (m.associated_message_type >= 2000 AND m.associated_message_type <= 3006)))`,
    );
  }
  if (!query.includeSystemEvents) {
    where.push("(m.item_type IS NULL OR m.item_type = 0)");
  }

  const whereSql = where.length > 0 ? `WHERE ${where.join(" AND ")}` : "";
  const limitSql = limit === null ? "" : "LIMIT ?";
  if (limit !== null) {
    params.push(limit);
  }

  // LEFT JOIN on chat_message_join, not INNER: a message whose chat row has
  // been removed is still a message, and dropping it would silently shrink the
  // archive being searched.
  const sql = `
    SELECT
      m.ROWID AS id,
      m.guid AS guid,
      m.text AS text,
      m.attributedBody AS attributedBody,
      ${appleSeconds("m.date")} AS date,
      CAST(m.date AS TEXT) AS date_raw,
      ${appleSeconds("m.date_edited")} AS date_edited,
      ${appleSeconds("m.date_retracted")} AS date_retracted,
      m.is_from_me AS is_from_me,
      m.item_type AS item_type,
      m.group_action_type AS group_action_type,
      m.group_title AS group_title,
      m.associated_message_type AS associated_message_type,
      m.associated_message_guid AS associated_message_guid,
      m.service AS service,
      m.destination_caller_id AS destination_caller_id,
      h.id AS handle,
      cmj.chat_id AS chat_id,
      COALESCE(NULLIF(c.display_name, ''), c.chat_identifier) AS chat_name,
      c.style AS chat_style,
      m.cache_has_attachments AS has_attachments
    FROM message m
    LEFT JOIN handle h ON h.ROWID = m.handle_id
    LEFT JOIN chat_message_join cmj ON cmj.message_id = m.ROWID
    LEFT JOIN chat c ON c.ROWID = cmj.chat_id
    ${whereSql}
    -- ROWID breaks the tie deterministically. Without it, rows sharing a
    -- timestamp come back in ascending ROWID order, which is the opposite of
    -- the direction the keyset cursor pages in — the cursor then asks for rows
    -- older than the oldest one already returned and a pager stalls.
    --
    -- NULL dates need no clause of their own: SQLite treats NULL as smaller
    -- than every value, so DESC already places them last, ordered among
    -- themselves by the same ROWID tiebreak. Leading with an IS NULL term
    -- instead makes the first sort key an expression, which costs the ordered
    -- scan of message_idx_date and adds a TEMP B-TREE over the whole candidate
    -- set - defeating the early exit a text scan depends on.
    ORDER BY m.date DESC, m.ROWID DESC
    ${limitSql}
  `;

  return { sql, params };
}

/**
 * The exact scaled date SQL produced, paired with the ROWID, encoded as one
 * opaque token.
 *
 * It cannot be an ISO timestamp. `message.date` has nanosecond resolution, ISO
 * carries milliseconds, and `new Date()` truncates — so a cursor round-tripped
 * through ISO lands up to a millisecond *before* the row it names, and every
 * message in that window is skipped. That window is populated: 423 distinct
 * milliseconds on the development store carry more than one message.
 *
 * Nor can it be the seconds-scaled double the rows display. That value is lossy
 * above 2^53 — about 128ns at present timestamps — while ORDER BY sorts the raw
 * 64-bit column, so two rows the sort separates can scale to one value and the
 * ROWID tiebreak then drops one. The closest pair on the development store is
 * 896ns apart, which clears it by a factor of seven, not by design.
 *
 * So the key is the column verbatim, carried as text and rebound as a BigInt.
 *
 * This assumes the column holds an integer, which SQLite's INTEGER affinity
 * guarantees for any value imagent writes — a losslessly-integral REAL is
 * converted on storage. A deliberately fractional date would stringify as
 * "1.5" and be rejected on the way back in, which stops paging rather than
 * paging wrongly; that is the right side to fail on.
 */
function encodeCursor(rawDate: string | null, id: number): string {
  // An empty date half means "dateless". SQLite sorts NULL dates last under
  // DESC, so those rows are the tail of a transcript; without a token that can
  // name one, paging stops at the first of them and the rest are unreachable.
  return `${rawDate ?? ""}:${id}`;
}

/** SQLite stores INTEGER as signed 64-bit; a wider value cannot be bound. */
const INT64_MIN = -(2n ** 63n);
const INT64_MAX = 2n ** 63n - 1n;

export function decodeCursor(token: string): { rawDate: bigint | null; id: number } {
  const at = token.lastIndexOf(":");
  if (at < 0) {
    throw new Error(`Malformed cursor: ${token}. Pass back the nextCursor a previous call returned.`);
  }
  const datePart = token.slice(0, at);
  const idPart = token.slice(at + 1);
  if (!/^-?\d+$/.test(idPart) || (datePart !== "" && !/^-?\d+$/.test(datePart))) {
    throw new Error(`Malformed cursor: ${token}. Pass back the nextCursor a previous call returned.`);
  }
  const id = Number(idPart);
  if (!Number.isSafeInteger(id)) {
    throw new Error(`Malformed cursor: ${token}. Pass back the nextCursor a previous call returned.`);
  }
  const rawDate = datePart === "" ? null : BigInt(datePart);
  // Rejected here rather than at bind time, where it surfaces as an opaque
  // "BigInt value is too large to bind" instead of naming the real problem.
  if (rawDate !== null && (rawDate < INT64_MIN || rawDate > INT64_MAX)) {
    throw new Error(`Malformed cursor: ${token}. Pass back the nextCursor a previous call returned.`);
  }
  return { rawDate, id };
}

/** Trims a row's body in place and flags it, so the caller can match first. */
function applySnippet(row: MessageRow, cap: number | undefined): MessageRow {
  if (cap === undefined || row.text === null || row.text.length <= cap) {
    return row;
  }
  row.text = row.text.slice(0, cap);
  row.truncated = true;
  return row;
}

function toMessageRow(raw: RawMessage, store: MessagesStore | null): MessageRow {
  const decodedText = messageText(raw.text, raw.attributedBody);
  const usedBlob = decodedText !== null && (raw.text === null || raw.text === "");
  const text = decodedText;

  const row: MessageRow = {
    id: raw.id,
    guid: raw.guid,
    date: appleDateToIso(raw.date),
    text,
    from: raw.is_from_me === 1 ? "me" : raw.handle,
    isFromMe: raw.is_from_me === 1,
    chatId: raw.chat_id,
    chatName: raw.chat_name,
    isGroup: raw.chat_style === GROUP_CHAT_STYLE,
    service: raw.service,
    attachments: [],
  };

  if (usedBlob) {
    row.decoded = true;
  }

  const reaction = resolveReaction(
    raw.associated_message_type,
    raw.associated_message_guid,
    isReactionType(raw.associated_message_type) && decodedText !== null && !isPlaceholderOnly(decodedText)
      ? decodedText
      : null,
  );
  if (reaction !== null) {
    row.reaction = reaction;
  }

  if (raw.date_edited !== null && raw.date_edited !== 0) {
    const edited = appleDateToIso(raw.date_edited);
    if (edited !== null) {
      row.edited = edited;
    }
  }
  if (raw.date_retracted !== null && raw.date_retracted !== 0) {
    row.unsent = true;
  }

  const event = systemEventLabel(raw.item_type, raw.group_action_type, raw.group_title);
  if (event !== null) {
    row.systemEvent = event;
  }

  // A body that is nothing but U+FFFC is an attachment, not text.
  if (text !== null && isPlaceholderOnly(text)) {
    row.text = null;
  }

  void store;
  return row;
}

/** Fills in attachments for the rows kept, in one query rather than per row. */
function attachRows(
  index: ReadOnlyIndex,
  rows: MessageRow[],
  store: MessagesStore | null,
): void {
  const ids = rows.filter((row) => row.attachments.length === 0).map((row) => row.id);
  if (ids.length === 0) {
    return;
  }
  const placeholders = ids.map(() => "?").join(",");
  const found = index.all<{
    message_id: number;
    transfer_name: string | null;
    mime_type: string | null;
    total_bytes: number | null;
    is_sticker: number | null;
    filename: string | null;
  }>(
    `SELECT maj.message_id AS message_id, a.transfer_name AS transfer_name,
            a.mime_type AS mime_type, a.total_bytes AS total_bytes,
            a.is_sticker AS is_sticker, a.filename AS filename
     FROM message_attachment_join maj
     JOIN attachment a ON a.ROWID = maj.attachment_id
     WHERE maj.message_id IN (${placeholders})`,
    ids,
  );

  const byMessage = new Map<number, AttachmentRow[]>();
  for (const row of found) {
    const list = byMessage.get(row.message_id) ?? [];
    list.push({
      name: row.transfer_name,
      mimeType: row.mime_type,
      bytes: row.total_bytes,
      isSticker: row.is_sticker === 1,
      path: resolveAttachmentPath(row.filename, store),
    });
    byMessage.set(row.message_id, list);
  }
  for (const row of rows) {
    row.attachments = byMessage.get(row.id) ?? [];
  }
}

/**
 * `attachment.filename` is stored with a literal `~`, which no consumer can
 * open. It is resolved against the store's own attachments directory rather
 * than by reconstructing a home from the root: an explicit `--db` need not sit
 * under `Library/Messages` at all, and string-replacing that suffix off a path
 * like `/tmp/export` silently no-ops, yielding
 * `/tmp/export/Library/Messages/Attachments/...` for a file that is really at
 * `/tmp/export/Attachments/...`.
 */
const ATTACHMENTS_SEGMENT = "/Attachments/";

function resolveAttachmentPath(
  filename: string | null,
  store: MessagesStore | null,
): string | null {
  if (filename === null || filename === "") {
    return null;
  }
  if (store === null || !filename.startsWith("~/")) {
    return filename;
  }
  const at = filename.indexOf(ATTACHMENTS_SEGMENT);
  if (at < 0) {
    // Not the shape this store writes; expanding it would be a guess.
    return filename;
  }
  return join(store.attachmentsDir, filename.slice(at + ATTACHMENTS_SEGMENT.length));
}
