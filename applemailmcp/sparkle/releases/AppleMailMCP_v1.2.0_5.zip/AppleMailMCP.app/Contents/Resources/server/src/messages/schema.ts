//
//  schema.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 09/09/2026.
//

import type { ReadOnlyIndex } from "../db.ts";

const REQUIRED_TABLES = [
  "message",
  "chat",
  "handle",
  "attachment",
  "chat_message_join",
  "chat_handle_join",
  "message_attachment_join",
] as const;

/** Every `message` column this code reads. */
const REQUIRED_MESSAGE_COLUMNS = [
  "guid",
  "text",
  "attributedBody",
  "handle_id",
  "service",
  "date",
  "date_edited",
  "date_retracted",
  "is_from_me",
  "item_type",
  "group_action_type",
  "group_title",
  "associated_message_guid",
  "associated_message_type",
  "cache_has_attachments",
] as const;

/**
 * Messages carries no schema version worth pinning — `_SqliteDatabaseProperties`
 * tracks CloudKit sync state, not a layout number, and the table grows columns
 * with most macOS releases without changing what the existing ones mean. So the
 * assertion is the same as Calendar's: the columns actually read must exist, and
 * a missing one is named rather than guessed at.
 */
export function assertKnownMessagesSchema(index: ReadOnlyIndex): void {
  const tables = new Set(
    index
      .all<{ name: string }>(`SELECT name FROM sqlite_master WHERE type = 'table'`)
      .map((row) => row.name),
  );
  const missingTables = REQUIRED_TABLES.filter((name) => !tables.has(name));
  if (missingTables.length > 0) {
    throw new Error(
      `Unknown Messages schema: missing tables ${missingTables.join(", ")}. Refusing to guess column meanings.`,
    );
  }

  // Same reasoning as the Calendar guard: the read-only authorizer denies
  // SQLITE_PRAGMA, so `pragma_table_info` is unreachable and relaxing it would
  // widen what every other query may do. A prepare against a missing column
  // fails, and LIMIT 0 means no row is ever read.
  const missingColumns = REQUIRED_MESSAGE_COLUMNS.filter((name) => {
    try {
      index.all(`SELECT "${name}" FROM message LIMIT 0`);
      return false;
    } catch {
      return true;
    }
  });
  if (missingColumns.length > 0) {
    throw new Error(
      `Unknown Messages schema: message is missing ${missingColumns.join(", ")}. ` +
        `Refusing to guess column meanings.`,
    );
  }
}

export function wrapMessagesError(error: unknown, fallback: string): Error {
  const err = error as { message?: string; code?: string };
  const message = err.message ?? String(error);
  const code = err.code ?? "";
  if (code === "SQLITE_BUSY" || /locked|SQLITE_BUSY/i.test(message)) {
    return new Error(`Messages database is locked or busy. ${message}`);
  }
  if (code === "EACCES" || code === "EPERM" || /permission denied|unable to open/i.test(message)) {
    return new Error(
      `Cannot read the Messages store (${message}). Grant Full Disk Access to the terminal / Node / MCP host — ` +
        `chat.db is protected by TCC even for the user who owns it.`,
    );
  }
  if (code === "ENOENT") {
    return new Error(message);
  }
  return new Error(`${fallback}: ${message}`);
}
