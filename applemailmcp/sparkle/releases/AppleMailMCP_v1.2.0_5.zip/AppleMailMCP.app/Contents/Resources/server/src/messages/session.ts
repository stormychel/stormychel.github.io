//
//  session.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 09/09/2026.
//

import { existsSync } from "node:fs";
import { resolve } from "node:path";
import { openIndex, type ReadOnlyIndex } from "../db.ts";
import { assertKnownMessagesSchema, wrapMessagesError } from "./schema.ts";
import { findMessagesStore, inferStoreFromDbPath, isInsideLiveMessagesStore } from "./store.ts";
import type { MessagesStore } from "./types.ts";

export type MessagesSession = {
  index: ReadOnlyIndex;
  store: MessagesStore | null;
  close: () => void;
};

export function openMessagesSession(
  options: { dbPath?: string; home?: string } = {},
): MessagesSession {
  try {
    const resolved = resolveStoreAndDb(options);
    const index = openIndex(resolved.dbPath, options.home, {
      isLive: isInsideLiveMessagesStore,
      label: "Messages",
    });
    try {
      assertKnownMessagesSchema(index);
    } catch (error) {
      index.close();
      throw error;
    }
    return { index, store: resolved.store, close: () => index.close() };
  } catch (error) {
    throw wrapMessagesError(error, "failed to open Messages session");
  }
}

function resolveStoreAndDb(options: { dbPath?: string; home?: string }): {
  dbPath: string;
  store: MessagesStore | null;
} {
  if (!options.dbPath) {
    const store = findMessagesStore(options.home);
    return { dbPath: store.dbPath, store };
  }
  const dbPath = resolve(options.dbPath);
  if (!existsSync(dbPath)) {
    throw new Error(`Messages database not found: ${dbPath}`);
  }
  return { dbPath, store: inferStoreFromDbPath(dbPath) };
}
