//
//  store.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 09/09/2026.
//

import { existsSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
import { canonicalPath, isInsideCanonical, sharesInodeWith, sqliteFamily } from "../store.ts";
import type { MessagesStore } from "./types.ts";

const DB_NAME = "chat.db";

/**
 * Unversioned, unlike Mail's V10: `~/Library/Messages/chat.db` has been the path
 * since iChat, so there is no version directory to discover. The sibling
 * `Attachments` tree is part of the same store and is guarded with it — a
 * snapshot of the database is worthless if SQLite could still be pointed at a
 * live sidecar next to it.
 */
export function messagesRootForHome(home: string = homedir()): string {
  return join(home, "Library", "Messages");
}

export function isInsideLiveMessagesStore(path: string, home: string = homedir()): boolean {
  if (isInsideCanonical(path, messagesRootForHome(home))) {
    return true;
  }
  return sharesInodeWith(canonicalPath(path), () => sqliteFamily(findMessagesStore(home).dbPath));
}

export function findMessagesStore(home: string = homedir()): MessagesStore {
  const root = messagesRootForHome(home);
  if (!existsSync(root)) {
    throw new Error(
      `Messages store not found at ${root}. Messages has to have been set up on this Mac.`,
    );
  }
  const dbPath = join(root, DB_NAME);
  if (!existsSync(dbPath)) {
    throw new Error(`${DB_NAME} missing at ${dbPath}.`);
  }
  return { root, dbPath, attachmentsDir: join(root, "Attachments") };
}

export function inferStoreFromDbPath(dbPath: string): MessagesStore | null {
  const abs = canonicalPath(dbPath);
  if (!abs.endsWith(`/${DB_NAME}`)) {
    return null;
  }
  const root = abs.slice(0, -(DB_NAME.length + 1));
  return { root, dbPath: abs, attachmentsDir: join(root, "Attachments") };
}
