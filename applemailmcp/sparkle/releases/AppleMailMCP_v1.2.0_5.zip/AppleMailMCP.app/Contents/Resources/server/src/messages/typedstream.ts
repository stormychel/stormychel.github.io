//
//  typedstream.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 09/09/2026.
//

/**
 * Messages stores almost nothing in `message.text`. On the store checked here
 * only 1,514 of 42,385 rows carry usable text; the other 40,456 keep their
 * content in `attributedBody`, a NSArchiver **typedstream** blob. A server that
 * searches `text` alone therefore answers "not found" for 96% of the archive,
 * which is exactly the confident-empty-answer failure this project exists to
 * avoid — so decoding this blob is load-bearing, not an enhancement.
 *
 * SQL cannot stand in for it. `attributedBody LIKE '%macbook%'` finds 1 of the
 * 82 rows that actually contain the word, because the framing bytes below sit
 * between the length and the characters. Decoding all 42,392 rows takes 43ms,
 * so the honest path is also the fast one.
 *
 * Only the message string is extracted. Full attribute runs would mean a
 * complete typedstream object graph (shared references, class versioning); the
 * text is the first NSString payload in the stream, and the attribute names
 * that follow it (`__kIMFileTransferGUIDAttributeName` and friends) are exactly
 * what must not leak into a search result.
 */

/** `0x04 0x0b "streamtyped"` — the NSArchiver signature, version 4. */
const HEADER = Buffer.from("\x04\x0bstreamtyped", "binary");

/**
 * Anchor for the payload. The class chain is written outermost-first
 * (`NSMutableAttributedString` → `NSAttributedString` → `NSObject` →
 * `NSMutableString` → `NSString`), so the first occurrence of this name is the
 * innermost string class and the text follows it. "NSString" is not a substring
 * of "NSMutableString", so the anchor is unambiguous.
 */
const NSSTRING = Buffer.from("NSString", "latin1");

/** typedstream type code for a C string: '+'. */
const CSTRING = 0x2b;

/**
 * Bytes between the anchor and the payload marker: a couple of class-version
 * and object-reference bytes (`01 94 84 01` / `01 95 84 01`). Bounded so a blob
 * whose text was somehow absent cannot make this walk into unrelated bytes and
 * return an attribute name as the message.
 */
const MARKER_SEARCH_WINDOW = 32;

/**
 * typedstream integers are variable width: a byte of 0x00–0x7f is the value
 * itself, 0x81 introduces a little-endian uint16 and 0x82 a uint32. 0x80–0xff
 * would be a negative signed byte, which is not a valid length, so those are
 * rejected rather than reinterpreted — the surrounding 0x84–0x9f bytes are
 * structural markers and must never be mistaken for a size.
 */
function readLength(buf: Buffer, i: number): { value: number; next: number } | null {
  const tag = buf[i];
  if (tag === undefined) {
    return null;
  }
  if (tag === 0x81) {
    return i + 3 <= buf.length ? { value: buf.readUInt16LE(i + 1), next: i + 3 } : null;
  }
  if (tag === 0x82) {
    return i + 5 <= buf.length ? { value: buf.readUInt32LE(i + 1), next: i + 5 } : null;
  }
  if (tag <= 0x7f) {
    return { value: tag, next: i + 1 };
  }
  return null;
}

/**
 * The decoded message text, or null when the blob is absent, is not a
 * typedstream, or does not carry a string payload where one is expected.
 * Returning null is deliberate: the caller reports the text as unavailable
 * rather than presenting a guess as the message.
 */
export function decodeAttributedBody(blob: unknown): string | null {
  const buf = toBuffer(blob);
  if (buf === null || !buf.subarray(0, HEADER.length).equals(HEADER)) {
    return null;
  }

  const anchor = buf.indexOf(NSSTRING);
  if (anchor < 0) {
    return null;
  }

  let i = anchor + NSSTRING.length;
  const limit = Math.min(buf.length, i + MARKER_SEARCH_WINDOW);
  while (i < limit && buf[i] !== CSTRING) {
    i++;
  }
  if (i >= limit) {
    return null;
  }

  const length = readLength(buf, i + 1);
  if (length === null || length.value === 0) {
    return null;
  }
  const end = length.next + length.value;
  if (end > buf.length) {
    return null;
  }
  return buf.subarray(length.next, end).toString("utf8");
}

/**
 * `node:sqlite` hands back a Uint8Array, not a Buffer, so the Buffer helpers
 * this decoder relies on are not present on the value as it arrives.
 */
function toBuffer(blob: unknown): Buffer | null {
  if (blob == null) {
    return null;
  }
  if (Buffer.isBuffer(blob)) {
    return blob;
  }
  if (blob instanceof Uint8Array) {
    return Buffer.from(blob.buffer, blob.byteOffset, blob.byteLength);
  }
  return null;
}

/**
 * Messages substitutes U+FFFC OBJECT REPLACEMENT CHARACTER for each attachment,
 * so an image-only message decodes to a string of them. Callers surface that as
 * an attachment rather than as body text.
 */
export const ATTACHMENT_PLACEHOLDER = "￼";

export function isPlaceholderOnly(text: string): boolean {
  return text.replaceAll(ATTACHMENT_PLACEHOLDER, "").trim() === "";
}

/** The body of a message, preferring `text` and falling back to the blob. */
export function messageText(text: string | null, attributedBody: unknown): string | null {
  if (text !== null && text !== "") {
    return text;
  }
  return decodeAttributedBody(attributedBody);
}
