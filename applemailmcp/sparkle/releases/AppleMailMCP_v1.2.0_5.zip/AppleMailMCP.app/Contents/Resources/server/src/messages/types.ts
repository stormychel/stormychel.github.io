//
//  types.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 09/09/2026.
//

export type MessagesStore = {
  root: string;
  dbPath: string;
  attachmentsDir: string;
};

export type ChatRow = {
  id: number;
  guid: string | null;
  /** Phone number, email or group id Messages addresses the chat by. */
  identifier: string | null;
  name: string | null;
  service: string | null;
  isGroup: boolean;
  participants: string[];
  messageCount: number;
  lastMessage: string | null;
};

export type HandleRow = {
  id: number;
  handle: string | null;
  service: string | null;
  /** The number as typed, before Messages canonicalised it to E.164. */
  uncanonicalized: string | null;
  chatCount: number;
};

export type MessageRow = {
  id: number;
  guid: string | null;
  date: string | null;
  /** null when neither `text` nor `attributedBody` yielded a string. */
  text: string | null;
  /** Set when the body came out of the typedstream blob rather than `text`. */
  decoded?: boolean;
  truncated?: boolean;
  from: string | null;
  isFromMe: boolean;
  chatId: number | null;
  chatName: string | null;
  isGroup: boolean;
  service: string | null;
  attachments: AttachmentRow[];
  reaction?: ReactionRow;
  /** Present only when set, to keep the common row small. */
  edited?: string;
  unsent?: boolean;
  systemEvent?: string;
};

export type AttachmentRow = {
  name: string | null;
  mimeType: string | null;
  bytes: number | null;
  isSticker: boolean;
  /** Kept so a host can open the file; never read by this server. */
  path: string | null;
};

export type ReactionRow = {
  action: "add" | "remove";
  kind: "classic" | "emoji" | "sticker";
  type: ClassicReaction | null;
  emoji: string | null;
  /** The message this reaction is attached to. */
  targetGuid: string | null;
};

export type ClassicReaction = "love" | "like" | "dislike" | "laugh" | "emphasize" | "question";

export type MessageQuery = {
  /** Substring match against the decoded body, case-insensitive. */
  text?: string;
  /** Substring match against the sender handle. */
  from?: string;
  /** Substring match against chat name, identifier or a participant handle. */
  chat?: string;
  chatId?: number;
  /** Unix seconds; compared on whichever scale each row uses. */
  after?: number;
  before?: number;
  /**
   * Keyset cursor for paging backwards: rows strictly older than this point in
   * the (date DESC, ROWID DESC) order, with `id` breaking the tie between
   * messages sharing a timestamp. The date is the raw column value, which is
   * why it is a BigInt — see encodeCursor.
   */
  cursor?: { rawDate: bigint | null; id: number };
  isFromMe?: boolean;
  service?: string;
  withAttachments?: boolean;
  /** Reactions and system events are excluded unless asked for. */
  includeReactions?: boolean;
  includeSystemEvents?: boolean;
  limit?: number;
};
