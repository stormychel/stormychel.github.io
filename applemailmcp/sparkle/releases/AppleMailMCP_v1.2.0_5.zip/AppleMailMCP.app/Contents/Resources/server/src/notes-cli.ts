#!/usr/bin/env node
//
//  notes-cli.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 15/10/2026.
//

import { parseRangeBound } from "./calendar/format.ts";
import { getNote, listNoteFolders, searchNotes } from "./notes/notes.ts";
import { openNotesSession } from "./notes/session.ts";

const USAGE = `Usage:
  applenote folders [options]
  applenote search [options]
  applenote get --id <uuid> [options]
  applenote mcp

Read-only. NoteStore.sqlite is APFS-cloned to a temp snapshot before SQLite
opens it; the Notes group container is never opened in place.

Options:
  --db <path>              A NoteStore.sqlite to read instead (skips discovery)
  --text <text>            Title or body substring (search); bodies are decoded, so this scans
  --folder <name|id>       Folder name substring or folder id (search)
  --modified-from <date>   Modified on or after; a bare date is the start of that local day
  --modified-to <date>     Modified on or before; a bare date is the end of that local day
  --include-deleted        Include notes in Recently Deleted (search)
  --id <uuid>              Note id (get)
  --offset <n>             Character offset into the body (get)
  --max-chars <n>          Body characters to return (get; default 8000, cap 20000)
  --limit <n>              Max rows (default 50, hard cap 1000)
  --help                   Show this help
`;

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  if (args.length === 0 || args.includes("--help") || args.includes("-h")) {
    process.stdout.write(USAGE);
    process.exit(args.length === 0 ? 1 : 0);
  }

  const command = args[0];
  if (command.startsWith("-")) {
    fail(`missing command. ${USAGE}`);
  }

  if (command === "mcp") {
    const { startStdioServer } = await import("./notes-server.ts");
    await startStdioServer();
    return;
  }

  const flags = parseFlags(args.slice(1));
  const session = openNotesSession({ dbPath: flags.db });
  try {
    if (command === "folders") {
      printJson(listNoteFolders(session));
      return;
    }
    if (command === "search") {
      printJson(
        searchNotes(session, {
          text: flags.text,
          folder: flags.folder,
          modifiedFrom: flags.modifiedFrom ? parseRangeBound(flags.modifiedFrom, "from") : undefined,
          modifiedTo: flags.modifiedTo ? parseRangeBound(flags.modifiedTo, "to") : undefined,
          includeDeleted: flags.includeDeleted,
          limit: flags.limit,
        }),
      );
      return;
    }
    if (command === "get") {
      if (!flags.id) {
        fail("--id is required for get (search shows them)");
      }
      printJson(getNote(session, flags.id, { offset: flags.offset, maxChars: flags.maxChars }));
      return;
    }
    fail(`unknown command: ${command}\n${USAGE}`);
  } finally {
    session.close();
  }
}

type Flags = {
  db?: string;
  text?: string;
  folder?: string;
  modifiedFrom?: string;
  modifiedTo?: string;
  includeDeleted?: boolean;
  id?: string;
  offset?: number;
  maxChars?: number;
  limit?: number;
};

function parseFlags(argv: string[]): Flags {
  const flags: Flags = {};
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    const next = (): string => {
      const value = argv[i + 1];
      if (value === undefined) {
        fail(`missing value for ${arg}`);
      }
      i += 1;
      return value;
    };
    const number = (): number => {
      const value = Number(next());
      if (!Number.isFinite(value)) {
        fail(`${arg} must be a number`);
      }
      return value;
    };
    switch (arg) {
      case "--db":
        flags.db = next();
        break;
      case "--text":
        flags.text = next();
        break;
      case "--folder":
        flags.folder = next();
        break;
      case "--modified-from":
        flags.modifiedFrom = next();
        break;
      case "--modified-to":
        flags.modifiedTo = next();
        break;
      case "--include-deleted":
        flags.includeDeleted = true;
        break;
      case "--id":
        flags.id = next();
        break;
      case "--offset":
        flags.offset = number();
        break;
      case "--max-chars":
        flags.maxChars = number();
        break;
      case "--limit":
        flags.limit = number();
        break;
      default:
        fail(`unknown option: ${arg}`);
    }
  }
  return flags;
}

function printJson(value: unknown): void {
  process.stdout.write(`${JSON.stringify(value, null, 2)}\n`);
}

function fail(message: string): never {
  process.stderr.write(`${message}\n`);
  process.exit(1);
}

main().catch((error) => {
  process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
  process.exit(1);
});
