#!/usr/bin/env node
//
//  notes-server.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 15/10/2026.
//

import { basename } from "node:path";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { reportHealth } from "./health.ts";
import { findNotesStore, notesContainerForHome } from "./notes/store.ts";
import { parseRangeBound } from "./calendar/format.ts";
import { DEFAULT_BODY_CHARS, getNote, listNoteFolders, MAX_BODY_CHARS, searchNotes } from "./notes/notes.ts";
import { openNotesSession, type NotesSession } from "./notes/session.ts";

export const MCP_DEFAULT_LIMIT = 20;
export const MCP_MAX_LIMIT = 50;

const READ_ONLY = {
  readOnlyHint: true,
  destructiveHint: false,
  idempotentHint: true,
  openWorldHint: false,
} as const;

const limitSchema = z.number().int().min(1).max(MCP_MAX_LIMIT).optional();

export function createNotesServer(
  sessionFactory: () => NotesSession = () => openNotesSession(),
): McpServer {
  const server = new McpServer({
    name: "applenotes",
    version: "0.1.0",
    title: "Apple Notes (read-only)",
  });

  const withSession = async (fn: (session: NotesSession) => unknown) => {
    // Opening is inside the try for the same reason as the other servers: a
    // locked store or a missing Full Disk Access grant has to come back in the
    // same {error: ...} envelope as every other failure.
    let session: NotesSession | null = null;
    try {
      session = sessionFactory();
      const result = fn(session);
      return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      return {
        isError: true,
        content: [{ type: "text" as const, text: JSON.stringify({ error: message }, null, 2) }],
      };
    } finally {
      session?.close();
    }
  };

  server.registerTool(
    "list_note_folders",
    {
      title: "List Note Folders",
      description:
        "Read-only list of the Apple Notes folders on this Mac, across every account, with each folder's " +
        "account, parent folder and note count. Use a returned id or name as the folder filter of search_notes.",
      inputSchema: {},
      annotations: READ_ONLY,
    },
    async () => withSession((session) => listNoteFolders(session)),
  );

  server.registerTool(
    "search_notes",
    {
      title: "Search Notes",
      description:
        "Read-only search of Apple Notes on this Mac, most recently modified first. Note bodies are stored " +
        "as encoded blobs, so a text search decodes each note and matches title and body after decoding — " +
        "it is a scan. `exhausted` says whether every candidate was examined; a short or empty result with " +
        "exhausted:false means the scan stopped, not that nothing more exists. Locked notes are matched on " +
        "their title only and come back marked locked. Notes in Recently Deleted are left out unless " +
        "includeDeleted or a folder is given. A zero-result search means not found locally. Rows carry a " +
        "snippet; use get_note for the full text. Results are capped.",
      inputSchema: {
        text: z.string().optional().describe("Substring of the title or body, case-insensitive"),
        folder: z.string().optional().describe("Folder name substring, or a folder id from list_note_folders"),
        modifiedFrom: z
          .string()
          .optional()
          .describe("Modified on or after: a bare date means the start of that local day; ISO-8601 or YYYYMMDD"),
        modifiedTo: z
          .string()
          .optional()
          .describe("Modified on or before: a bare date means the end of that local day; ISO-8601 or YYYYMMDD"),
        includeDeleted: z.boolean().optional().describe("Include notes in Recently Deleted"),
        limit: limitSchema.describe(`Max rows (default ${MCP_DEFAULT_LIMIT}, cap ${MCP_MAX_LIMIT})`),
      },
      annotations: READ_ONLY,
    },
    async (args) =>
      withSession((session) =>
        searchNotes(session, {
          text: args.text,
          folder: args.folder,
          modifiedFrom: args.modifiedFrom ? parseRangeBound(args.modifiedFrom, "from") : undefined,
          modifiedTo: args.modifiedTo ? parseRangeBound(args.modifiedTo, "to") : undefined,
          includeDeleted: args.includeDeleted,
          limit: args.limit ?? MCP_DEFAULT_LIMIT,
        }),
      ),
  );

  server.registerTool(
    "get_note",
    {
      title: "Get Note",
      description:
        "Read-only fetch of one note: decoded body as plain text (checklists as - [ ] / - [x], attachments " +
        "as [attachment: name (type)] markers), folder, account, dates and attachment names and types. " +
        "bodyStatus is decoded | locked | unfetched | undecodable; a locked note returns metadata only. Long " +
        "bodies are sliced; pass nextOffset back as offset to continue. Takes the id returned by search_notes.",
      inputSchema: {
        id: z.string().describe("Note id (a UUID) from search_notes"),
        offset: z.number().int().min(0).optional().describe("Character offset into the decoded body"),
        maxChars: z
          .number()
          .int()
          .min(1)
          .max(MAX_BODY_CHARS)
          .optional()
          .describe(`Body characters to return (default ${DEFAULT_BODY_CHARS})`),
      },
      annotations: READ_ONLY,
    },
    async (args) =>
      withSession((session) => getNote(session, args.id, { offset: args.offset, maxChars: args.maxChars })),
  );

  return server;
}

export async function startStdioServer(): Promise<void> {
  // Which app started this server, and whether its store opened under it (#99).
  reportHealth("notes", () => findNotesStore().dbPath, notesContainerForHome());
  const server = createNotesServer();
  const transport = new StdioServerTransport();
  await server.connect(transport);
}

// basename, not endsWith: a suffix test would start this server whenever
// another *-server.ts is the entry point and anything pulls this module in.
const entry = basename(process.argv[1] ?? "");
if (entry === "notes-server.ts" || entry === "notes-server.js") {
  startStdioServer().catch((error) => {
    process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
    process.exit(1);
  });
}
