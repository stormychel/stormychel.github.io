//
//  notebody.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 15/10/2026.
//

import { gunzipSync } from "node:zlib";

/**
 * A note's body is not text in a column. `ZICNOTEDATA.ZDATA` is a gzipped
 * protobuf, so SQL alone reaches only the title and Notes' short `ZSNIPPET`, and
 * a search for a word in the middle of a note finds nothing.
 *
 * The layout below was verified on a live store (macOS 26.6, 2026-10-15), not
 * taken on trust from the public reverse-engineering: all 317 unlocked bodies
 * there start with the gzip magic, every one parses to this shape, the run
 * lengths sum to exactly the text's length in UTF-16 code units in all 317, and
 * each of the 191 U+FFFC characters sits in a run of length 1 carrying an
 * attachment reference — no run carries one without the other.
 *
 *   NoteStoreProto
 *     2: Document
 *          3: Note
 *               2: note_text (string)
 *               5: AttributeRun (repeated)
 *                    1: length (UTF-16 code units)
 *                    2: ParagraphStyle
 *                         1: style_type   (0 title, 1 heading, 2 subheading, 4 monospaced,
 *                                          100 dotted, 101 dashed, 102 numbered, 103 checklist)
 *                         4: indent_amount
 *                         5: Checklist { 1: uuid (bytes), 2: done (0/1) }
 *                    12: AttachmentInfo { 1: attachment identifier, 2: type UTI }
 *
 * Field 3 of Note (the CRDT substring graph), the font, link and timestamp
 * fields of a run are all present and all ignored: the text field already holds
 * the document in order, and the attribute runs only need to say which lines
 * are list items and where attachments sit.
 *
 * A locked note's body is not this at all — it is AES-wrapped, starts with no
 * gzip magic, and is never handed here.
 */

const GZIP_MAGIC_0 = 0x1f;
const GZIP_MAGIC_1 = 0x8b;

/** A note body is a few KB; this only bounds a hostile or corrupt blob. */
const MAX_INFLATED_BYTES = 64 * 1024 * 1024;

export const STYLE = {
  title: 0,
  heading: 1,
  subheading: 2,
  monospaced: 4,
  dotted: 100,
  dashed: 101,
  numbered: 102,
  checklist: 103,
} as const;

/** Notes' object replacement character: one per attachment in the text. */
export const ATTACHMENT_CHAR = "￼";

export type ParagraphStyle = {
  type: number | null;
  indent: number;
  /** Set on checklist items only. */
  checked: boolean | null;
};

export type AttributeRun = {
  length: number;
  style: ParagraphStyle | null;
  attachment: { id: string; type: string | null } | null;
};

export type NoteDocument = { text: string; runs: AttributeRun[] };

// MARK: - Protobuf

type Field =
  | { field: number; wire: 0; value: number }
  | { field: number; wire: 1 | 2 | 5; bytes: Buffer };

class ProtobufError extends Error {}

/**
 * Fields kept per message before the blob is treated as hostile. The store
 * checked peaks well under a thousand attribute runs in one note; a crafted
 * body inflating to 64 MiB of two-byte fields would otherwise become tens of
 * millions of objects and exhaust the heap, which no catch can recover from.
 */
export const MAX_KEPT_FIELDS = 100_000;

/**
 * The four wire types this format uses. Values past 2^53 lose precision, which
 * only touches fields this code ignores (timestamps, hashes); lengths and enums
 * are small. Groups (wire 3/4) are deprecated and absent here, so meeting one
 * means the bytes are not what this code thinks they are.
 *
 * Only the field numbers in `keep` are materialised; every other field is
 * walked past without allocating, so the CRDT graph, fonts and timestamps cost
 * nothing however many of them a blob carries. At most `MAX_KEPT_FIELDS` are
 * kept.
 */
export function readFields(buf: Buffer, keep?: ReadonlySet<number>): Field[] {
  const fields: Field[] = [];
  let i = 0;
  const varint = (): number => {
    let value = 0;
    let scale = 1;
    for (let n = 0; n < 10; n++) {
      if (i >= buf.length) {
        throw new ProtobufError("truncated varint");
      }
      const byte = buf[i++];
      value += (byte & 0x7f) * scale;
      if ((byte & 0x80) === 0) {
        return value;
      }
      scale *= 128;
    }
    throw new ProtobufError("varint longer than 10 bytes");
  };
  const take = (length: number): Buffer => {
    if (i + length > buf.length) {
      throw new ProtobufError("field runs past the end of its message");
    }
    const bytes = buf.subarray(i, i + length);
    i += length;
    return bytes;
  };
  while (i < buf.length) {
    const key = varint();
    const field = Math.floor(key / 8);
    const wire = key % 8;
    if (field === 0) {
      throw new ProtobufError("field number 0");
    }
    let entry: Field;
    if (wire === 0) {
      entry = { field, wire, value: varint() };
    } else if (wire === 2) {
      entry = { field, wire, bytes: take(varint()) };
    } else if (wire === 1) {
      entry = { field, wire, bytes: take(8) };
    } else if (wire === 5) {
      entry = { field, wire, bytes: take(4) };
    } else {
      throw new ProtobufError(`unsupported wire type ${wire}`);
    }
    if (keep && !keep.has(field)) {
      continue;
    }
    if (fields.length >= MAX_KEPT_FIELDS) {
      throw new ProtobufError(`more than ${MAX_KEPT_FIELDS} fields in one message`);
    }
    fields.push(entry);
  }
  return fields;
}

// The fields each message is read for; everything else is skipped.
const ROOT_FIELDS = new Set([2]);
const DOCUMENT_FIELDS = new Set([3]);
const NOTE_FIELDS = new Set([2, 5]);
const RUN_FIELDS = new Set([1, 2, 12]);
const STYLE_FIELDS = new Set([1, 4, 5]);
const CHECKLIST_FIELDS = new Set([2]);
const ATTACHMENT_FIELDS = new Set([1, 2]);

function message(fields: Field[], field: number): Buffer | null {
  for (const f of fields) {
    if (f.field === field && f.wire === 2) {
      return f.bytes;
    }
  }
  return null;
}

function scalar(fields: Field[], field: number): number | null {
  for (const f of fields) {
    if (f.field === field && f.wire === 0) {
      return f.value;
    }
  }
  return null;
}

// MARK: - Document

/**
 * The note's text and attribute runs, or null when the blob is absent, is not
 * gzip, or does not parse to the verified layout. Null is deliberate: the
 * caller reports the body as undecodable rather than presenting a guess.
 */
export function parseNoteBody(blob: unknown): NoteDocument | null {
  const buf = toBuffer(blob);
  if (buf === null || buf.length < 2 || buf[0] !== GZIP_MAGIC_0 || buf[1] !== GZIP_MAGIC_1) {
    return null;
  }
  try {
    const raw = gunzipSync(buf, { maxOutputLength: MAX_INFLATED_BYTES });
    const document = message(readFields(raw, ROOT_FIELDS), 2);
    const note = document && message(readFields(document, DOCUMENT_FIELDS), 3);
    if (!note) {
      return null;
    }
    const noteFields = readFields(note, NOTE_FIELDS);
    const text = message(noteFields, 2);
    if (text === null) {
      return null;
    }
    const runs: AttributeRun[] = [];
    for (const f of noteFields) {
      if (f.field === 5 && f.wire === 2) {
        runs.push(parseRun(readFields(f.bytes, RUN_FIELDS)));
      }
    }
    return { text: text.toString("utf8"), runs };
  } catch {
    return null;
  }
}

function parseRun(fields: Field[]): AttributeRun {
  const styleBytes = message(fields, 2);
  const attachmentBytes = message(fields, 12);
  return {
    length: scalar(fields, 1) ?? 0,
    style: styleBytes ? parseStyle(readFields(styleBytes, STYLE_FIELDS)) : null,
    attachment: attachmentBytes ? parseAttachment(readFields(attachmentBytes, ATTACHMENT_FIELDS)) : null,
  };
}

function parseStyle(fields: Field[]): ParagraphStyle {
  const checklist = message(fields, 5);
  const done = checklist ? scalar(readFields(checklist, CHECKLIST_FIELDS), 2) : null;
  return {
    type: scalar(fields, 1),
    indent: scalar(fields, 4) ?? 0,
    checked: checklist ? done === 1 : null,
  };
}

function parseAttachment(fields: Field[]): { id: string; type: string | null } | null {
  const id = message(fields, 1);
  if (!id) {
    return null;
  }
  const type = message(fields, 2);
  return { id: id.toString("utf8"), type: type ? type.toString("utf8") : null };
}

/** Attachment references in document order, duplicates kept once. */
export function attachmentRefs(doc: NoteDocument): { id: string; type: string | null }[] {
  const seen = new Set<string>();
  const refs: { id: string; type: string | null }[] = [];
  for (const run of doc.runs) {
    if (run.attachment && !seen.has(run.attachment.id)) {
      seen.add(run.attachment.id);
      refs.push(run.attachment);
    }
  }
  return refs;
}

// MARK: - Rendering

/** An indent level is two spaces; capped so a corrupt value cannot pad a line out. */
const MAX_INDENT = 8;

/**
 * Plain text with list structure kept: checklist items as `- [ ]` / `- [x]`,
 * dashed and dotted items as `- ` and `• `, numbered items counted per indent
 * level, and indentation as two spaces a level. Each U+FFFC becomes whatever
 * `label` says for the attachment its run names.
 *
 * A paragraph takes the style of the run its first character is in. Notes
 * applies a paragraph style to the whole paragraph, newline included, so the
 * first character and the newline agree; an empty paragraph is just its
 * newline.
 */
export function renderNoteText(
  doc: NoteDocument,
  label: (attachment: { id: string; type: string | null } | null) => string,
): string {
  const { text } = doc;
  const starts: number[] = [];
  let offset = 0;
  for (const run of doc.runs) {
    starts.push(offset);
    offset += run.length;
  }
  let cursor = 0;
  const runAt = (position: number): AttributeRun | null => {
    // Paragraphs are visited in order, so a forward-only cursor suffices.
    while (cursor + 1 < starts.length && starts[cursor + 1] <= position) {
      cursor++;
    }
    const run = doc.runs[cursor];
    return run && position >= starts[cursor] && position < starts[cursor] + run.length ? run : null;
  };

  const lines: string[] = [];
  const counters: number[] = [];
  let start = 0;
  while (start <= text.length) {
    const newline = text.indexOf("\n", start);
    const end = newline === -1 ? text.length : newline;
    if (start === text.length && newline === -1 && start > 0) {
      // Text ending in a newline: nothing follows it.
      break;
    }
    const style = start < text.length ? runAt(start)?.style ?? null : null;
    let body = "";
    for (let i = start; i < end; i++) {
      const ch = text[i];
      if (ch === ATTACHMENT_CHAR) {
        body += label(runAt(i)?.attachment ?? null);
      } else {
        body += ch;
      }
    }
    lines.push(prefix(style, counters) + body);
    if (newline === -1) {
      break;
    }
    start = newline + 1;
  }
  return lines.join("\n");
}

function prefix(style: ParagraphStyle | null, counters: number[]): string {
  const type = style?.type ?? null;
  const indent = Math.min(Math.max(0, style?.indent ?? 0), MAX_INDENT);
  const pad = "  ".repeat(indent);
  if (type !== STYLE.numbered) {
    // Anything else at this level ends the numbering here and deeper, but an
    // outer numbered list survives an indented bullet: "1. a / - x / 2. b".
    // An unindented plain paragraph therefore ends every list.
    counters.length = Math.min(counters.length, indent);
  }
  switch (type) {
    case STYLE.checklist:
      return `${pad}- [${style?.checked ? "x" : " "}] `;
    case STYLE.dashed:
      return `${pad}- `;
    case STYLE.dotted:
      return `${pad}• `;
    case STYLE.numbered: {
      // A deeper item starts its own count; returning to a shallower one
      // resumes that level's.
      counters.length = indent + 1;
      counters[indent] = (counters[indent] ?? 0) + 1;
      return `${pad}${counters[indent]}. `;
    }
    default:
      return pad;
  }
}

/**
 * `node:sqlite` hands back a Uint8Array, not a Buffer, so the Buffer helpers
 * this decoder relies on are not present on the value as it arrives.
 */
function toBuffer(blob: unknown): Buffer | null {
  if (blob == null) {
    return null;
  }
  if (Buffer.isBuffer(blob)) {
    return blob;
  }
  if (blob instanceof Uint8Array) {
    return Buffer.from(blob.buffer, blob.byteOffset, blob.byteLength);
  }
  return null;
}
