//
//  notes.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 15/10/2026.
//

import { DEFAULT_LIMIT, MAX_LIMIT } from "../db.ts";
import { clampLimit, epochToIso, likeContains } from "../format.ts";
import { appleToUnix } from "../calendar/format.ts";
import { attachmentRefs, parseNoteBody, renderNoteText, type NoteDocument } from "./notebody.ts";
import type { NotesSession } from "./session.ts";
import type {
  BodyStatus,
  FolderType,
  NoteAttachment,
  NoteDetail,
  NoteFolderRow,
  NoteQuery,
  NoteRow,
} from "./types.ts";

const OBJECTS = "ZICCLOUDSYNCINGOBJECT";

export const DEFAULT_BODY_CHARS = 8000;
export const MAX_BODY_CHARS = 20000;

/** Characters of context kept per search row. */
export const SNIPPET_CHARS = 200;

/**
 * Ceiling on notes decoded for one text search. A match is decided after
 * decoding, so an unmatched query walks every note; the store checked holds
 * 318 and decodes them all in well under a second, but the ceiling is what
 * makes "stopped looking" distinguishable from "no more matches".
 */
export const MAX_SCAN = 20_000;

/** ZFOLDERTYPE of the Recently Deleted folder, verified on the store checked. */
const TRASH_FOLDER_TYPE = 1;

const LOCAL_ONLY_NOTE =
  "Results are from the Notes store on this Mac only. A zero-result search means not found locally.";

const NOT_FOUND_LOCALLY = "not found locally";

const UNFETCHED_NOTE =
  "Notes on this Mac that have no title, folder, date or body yet: placeholders Notes creates from an " +
  "iCloud per-user record (last-viewed state) whose note itself was never downloaded. There is nothing in " +
  "them to search, so they are counted here rather than returned.";

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

type RawNote = {
  pk: number;
  id: string;
  title: string | null;
  snippet: string | null;
  created: number | null;
  modified: number | null;
  pinned: number | null;
  locked: number | null;
  folder: string | null;
  folder_id: string | null;
  account: string | null;
  has_data: number;
  data?: Uint8Array | null;
};

/**
 * Soft-deleted notes stay in the file until notesd purges them, so
 * ZMARKEDFORDELETION rows are excluded, and so are notes in a folder that is
 * itself marked for deletion. Notes in Recently Deleted are a different thing
 * — still notes, in a folder of ZFOLDERTYPE 1 — and are filtered by the caller.
 */
function noteSelect(session: NotesSession, withData: boolean): { sql: string; params: number[] } {
  const { columns: c, entities: e } = session.schema;
  return {
    sql: `
  SELECT
    n.Z_PK AS pk,
    n.ZIDENTIFIER AS id,
    n."${c.noteTitle}" AS title,
    n.ZSNIPPET AS snippet,
    n."${c.noteCreated}" AS created,
    n."${c.noteModified}" AS modified,
    n.ZISPINNED AS pinned,
    n.ZISPASSWORDPROTECTED AS locked,
    f."${c.folderTitle}" AS folder,
    f.ZIDENTIFIER AS folder_id,
    a.ZNAME AS account,
    (d.ZDATA IS NOT NULL) AS has_data${withData ? ",\n    d.ZDATA AS data" : ""}
  FROM ${OBJECTS} n
  LEFT JOIN ${OBJECTS} f ON f.Z_PK = n.ZFOLDER AND f.Z_ENT = ?
  LEFT JOIN ${OBJECTS} a ON a.Z_PK = n."${c.noteAccount}" AND a.Z_ENT = ?
  LEFT JOIN ZICNOTEDATA d ON d.Z_PK = n.ZNOTEDATA
  WHERE n.Z_ENT = ?
    AND COALESCE(n.ZMARKEDFORDELETION, 0) = 0
    AND (f.Z_PK IS NULL OR COALESCE(f.ZMARKEDFORDELETION, 0) = 0)`,
    params: [e.folder, e.account, e.note],
  };
}

/** The placeholder test, shared so search and the count can never disagree. */
function unfetchedSql(session: NotesSession): string {
  return `(n."${session.schema.columns.noteTitle}" IS NULL AND d.ZDATA IS NULL)`;
}

export function countUnfetched(session: NotesSession): number {
  const { sql, params } = noteSelect(session, false);
  const row = session.index.get<{ count: number }>(
    `SELECT count(*) AS count FROM (${sql} AND ${unfetchedSql(session)})`,
    params,
  );
  return row?.count ?? 0;
}

export function listNoteFolders(session: NotesSession) {
  const { columns: c, entities: e } = session.schema;
  const rows = session.index.all<{
    id: string;
    name: string | null;
    account: string | null;
    parent_id: string | null;
    parent_name: string | null;
    folder_type: number | null;
    smart: number;
    note_count: number;
  }>(
    `
    SELECT
      f.ZIDENTIFIER AS id,
      f."${c.folderTitle}" AS name,
      a.ZNAME AS account,
      p.ZIDENTIFIER AS parent_id,
      p."${c.folderTitle}" AS parent_name,
      f.ZFOLDERTYPE AS folder_type,
      (f.ZSMARTFOLDERQUERYJSON IS NOT NULL) AS smart,
      (SELECT count(*) FROM ${OBJECTS} n
        WHERE n.Z_ENT = ? AND n.ZFOLDER = f.Z_PK
          AND COALESCE(n.ZMARKEDFORDELETION, 0) = 0) AS note_count
    FROM ${OBJECTS} f
    LEFT JOIN ${OBJECTS} a ON a.Z_PK = f."${c.folderAccount}" AND a.Z_ENT = ?
    LEFT JOIN ${OBJECTS} p ON p.Z_PK = f.ZPARENT AND p.Z_ENT = ?
    WHERE f.Z_ENT = ?
      AND COALESCE(f.ZMARKEDFORDELETION, 0) = 0
    ORDER BY a.ZNAME, f.ZFOLDERTYPE, f."${c.folderTitle}", f.ZIDENTIFIER
    `,
    [e.note, e.account, e.folder, e.folder],
  );
  const folders: NoteFolderRow[] = rows.map((row) => ({
    id: row.id,
    name: row.name,
    account: row.account,
    parentId: row.parent_id,
    parentName: row.parent_name,
    type: folderType(row.folder_type),
    smart: row.smart === 1,
    noteCount: row.note_count,
  }));
  return {
    count: folders.length,
    ...envelope(session),
    unfetchedNotes: countUnfetched(session),
    unfetchedNote: UNFETCHED_NOTE,
    folders,
  };
}

export type NoteSearchResult = {
  count: number;
  limit: number;
  /** Notes examined. Equal to `count` for a search without text. */
  scanned: number;
  scanTruncated: boolean;
  /** True only when every candidate was examined; see search_notes. */
  exhausted: boolean;
  /** Locked candidates, matched on their title only: the body is encrypted. */
  lockedTitleOnly: number;
  /** Candidates whose body did not decode, matched on their title only. */
  undecodable: number;
  unfetchedNotes: number;
  note: string;
  source: "local";
  snapshot: boolean;
  notes: NoteRow[];
};

export function searchNotes(
  session: NotesSession,
  query: NoteQuery = {},
  options: { maxScan?: number } = {},
): NoteSearchResult {
  // Overridable only so a test can reach the ceiling.
  const maxScan = options.maxScan ?? MAX_SCAN;
  const limit = clampLimit(query.limit, DEFAULT_LIMIT, MAX_LIMIT);
  const needle = query.text?.toLowerCase() || undefined;
  const { columns: c } = session.schema;

  const base = noteSelect(session, needle !== undefined);
  const where: string[] = [`NOT ${unfetchedSql(session)}`];
  const params: unknown[] = [...base.params];

  if (query.folder) {
    const folder = query.folder.trim();
    if (UUID.test(folder)) {
      where.push("upper(f.ZIDENTIFIER) = ?");
      params.push(folder.toUpperCase());
    } else {
      where.push(`f."${c.folderTitle}" LIKE ? ESCAPE '#'`);
      params.push(likeContains(folder));
    }
  } else if (!query.includeDeleted) {
    where.push(`(f.Z_PK IS NULL OR COALESCE(f.ZFOLDERTYPE, 0) != ${TRASH_FOLDER_TYPE})`);
  }
  if (query.modifiedFrom !== undefined) {
    where.push(`n."${c.noteModified}" >= ?`);
    params.push(query.modifiedFrom);
  }
  if (query.modifiedTo !== undefined) {
    where.push(`n."${c.noteModified}" <= ?`);
    params.push(query.modifiedTo);
  }

  // Without text the limit is applied in SQL; with it, after decoding.
  const sql = `${base.sql}${where.map((clause) => `\n    AND ${clause}`).join("")}
    ORDER BY n."${c.noteModified}" DESC NULLS LAST, n.ZIDENTIFIER ASC${needle === undefined ? "\n    LIMIT ?" : ""}`;
  if (needle === undefined) {
    params.push(limit);
  }

  const labels = attachmentLabeller(session);
  const notes: NoteRow[] = [];
  let scanned = 0;
  let scanTruncated = false;
  let stoppedEarly = false;
  let lockedTitleOnly = 0;
  let undecodable = 0;

  for (const raw of session.index.iterate<RawNote>(sql, params)) {
    scanned++;
    if (needle === undefined) {
      notes.push({ ...toRow(raw), ...notesSnippet(raw.snippet) });
      continue;
    }
    let body: string | null = null;
    if (raw.locked === 1) {
      lockedTitleOnly++;
    } else if (raw.data != null) {
      const doc = parseNoteBody(raw.data);
      if (doc === null) {
        undecodable++;
      } else {
        body = renderNoteText(doc, labels.label(doc));
      }
    }
    // Matched against the whole body and only then cut to a snippet; cutting
    // first would make anything past the snippet unfindable.
    const titleHit = (raw.title ?? "").toLowerCase().includes(needle);
    const bodyAt = body === null ? -1 : body.toLowerCase().indexOf(needle);
    if (titleHit || bodyAt >= 0) {
      notes.push({
        ...toRow(raw),
        ...(bodyAt >= 0 ? { snippet: contextSnippet(body!, bodyAt, needle.length) } : notesSnippet(raw.snippet)),
      });
      if (notes.length >= limit) {
        stoppedEarly = true;
        break;
      }
    }
    if (scanned >= maxScan) {
      scanTruncated = true;
      stoppedEarly = true;
      break;
    }
  }

  return {
    count: notes.length,
    limit,
    scanned,
    scanTruncated,
    exhausted: needle === undefined ? notes.length < limit : !stoppedEarly,
    lockedTitleOnly,
    undecodable,
    unfetchedNotes: countUnfetched(session),
    note: notes.length === 0 ? NOT_FOUND_LOCALLY : LOCAL_ONLY_NOTE,
    ...envelope(session),
    notes,
  };
}

export function getNote(
  session: NotesSession,
  id: string,
  options: { offset?: number; maxChars?: number } = {},
): NoteDetail & { source: "local"; snapshot: boolean; note?: string } {
  const trimmed = id.trim();
  if (!UUID.test(trimmed)) {
    throw new Error(`Invalid note id: ${id} (expected a UUID from search_notes)`);
  }
  const base = noteSelect(session, true);
  const raw = session.index.get<RawNote>(`${base.sql}\n    AND upper(n.ZIDENTIFIER) = ?`, [
    ...base.params,
    trimmed.toUpperCase(),
  ]);
  if (!raw) {
    throw new Error(`Note ${id} ${NOT_FOUND_LOCALLY}.`);
  }

  let status: BodyStatus;
  let text: string | null = null;
  let attachments: NoteAttachment[] = [];
  let note: string | undefined;
  if (raw.locked === 1) {
    status = "locked";
    note = "This note is locked. Its body is encrypted and is not read; only its metadata is returned.";
  } else if (raw.data == null) {
    status = "unfetched";
    note = UNFETCHED_NOTE;
  } else {
    const doc = parseNoteBody(raw.data);
    if (doc === null) {
      status = "undecodable";
      note = "The body is stored in a layout this code does not recognise, so it is not shown rather than guessed at.";
    } else {
      status = "decoded";
      const labels = attachmentLabeller(session);
      text = renderNoteText(doc, labels.label(doc));
      attachments = attachmentRefs(doc).map((ref) => labels.describe(ref));
    }
  }

  return {
    ...toRow(raw),
    bodyStatus: status,
    ...sliceBody(text, options.offset ?? 0, options.maxChars ?? DEFAULT_BODY_CHARS),
    attachments,
    ...envelope(session),
    ...(note ? { note } : {}),
  };
}

/**
 * Looks attachments up by the identifiers a body references, one query per
 * note that has any, cached across notes in one call.
 */
function attachmentLabeller(session: NotesSession) {
  const { columns: c, entities: e } = session.schema;
  const cache = new Map<string, NoteAttachment>();
  const typeExpr =
    c.inlineType && e.inlineAttachment !== null
      ? `CASE WHEN a.Z_ENT = ${e.inlineAttachment} THEN a."${c.inlineType}" ELSE a."${c.attachmentType}" END`
      : `a."${c.attachmentType}"`;
  const entities = [e.attachment, ...(e.inlineAttachment !== null ? [e.inlineAttachment] : [])];

  const load = (ids: string[]) => {
    const wanted = ids.filter((id) => !cache.has(id));
    if (wanted.length === 0) {
      return;
    }
    const rows = session.index.all<{ id: string; type: string | null; name: string | null }>(
      `
      SELECT
        a.ZIDENTIFIER AS id,
        ${typeExpr} AS type,
        COALESCE(a.ZUSERTITLE, a."${c.attachmentTitle}", m.ZFILENAME) AS name
      FROM ${OBJECTS} a
      LEFT JOIN ${OBJECTS} m ON m.Z_PK = a.ZMEDIA
      WHERE a.Z_ENT IN (${entities.map(() => "?").join(", ")})
        AND a.ZIDENTIFIER IN (${wanted.map(() => "?").join(", ")})
      `,
      [...entities, ...wanted],
    );
    for (const row of rows) {
      cache.set(row.id, { id: row.id, type: row.type, name: row.name });
    }
  };

  const describe = (ref: { id: string; type: string | null }): NoteAttachment => {
    load([ref.id]);
    const found = cache.get(ref.id);
    // The body names a type too; it stands in when the row is gone.
    return { id: ref.id, type: found?.type ?? ref.type, name: found?.name ?? null };
  };

  return {
    describe,
    label: (doc: NoteDocument) => {
      load(attachmentRefs(doc).map((ref) => ref.id));
      return (ref: { id: string; type: string | null } | null): string => {
        if (ref === null) {
          return "[attachment]";
        }
        const { type, name } = describe(ref);
        if (name && type) return `[attachment: ${name} (${type})]`;
        if (name || type) return `[attachment: ${name ?? type}]`;
        return "[attachment]";
      };
    },
  };
}

function sliceBody(text: string | null, offset: number, maxChars: number) {
  if (text === null) {
    return { body: null, bodyLength: 0, bodyOffset: 0, bodyTruncated: false, nextOffset: null };
  }
  const start = Math.max(0, Math.floor(offset));
  const cap = Math.min(Math.max(1, Math.floor(maxChars)), MAX_BODY_CHARS);
  let end = Math.min(text.length, start + cap);
  // Never end a slice between the two halves of a surrogate pair, or the emoji
  // is lost from both pages. Cut back one; if that would leave the page empty
  // (maxChars 1 on a pair), take the whole pair instead so paging still moves.
  if (end < text.length && isHighSurrogate(text.charCodeAt(end - 1))) {
    end = end - 1 > start ? end - 1 : end + 1;
  }
  const body = text.slice(start, end);
  const truncated = start + body.length < text.length;
  return {
    body,
    bodyLength: text.length,
    bodyOffset: start,
    bodyTruncated: truncated,
    nextOffset: truncated ? start + body.length : null,
  };
}

function isHighSurrogate(code: number): boolean {
  return code >= 0xd800 && code <= 0xdbff;
}

function toRow(raw: RawNote): NoteRow {
  return {
    id: raw.id,
    title: raw.title,
    folder: raw.folder,
    folderId: raw.folder_id,
    account: raw.account,
    created: epochToIso(appleToUnix(raw.created)),
    modified: epochToIso(appleToUnix(raw.modified)),
    pinned: raw.pinned === 1,
    locked: raw.locked === 1,
  };
}

function folderType(value: number | null): FolderType {
  if (value === null || value === 0) return "default";
  if (value === TRASH_FOLDER_TYPE) return "recently-deleted";
  return `type ${value}`;
}

function notesSnippet(snippet: string | null): { snippet?: string } {
  const flat = snippet?.replace(/\s+/g, " ").trim();
  if (!flat) {
    return {};
  }
  return { snippet: flat.length > SNIPPET_CHARS ? `${flat.slice(0, SNIPPET_CHARS)}…` : flat };
}

/** The match with some text either side, whitespace flattened. */
function contextSnippet(body: string, at: number, length: number): string {
  const lead = Math.floor((SNIPPET_CHARS - length) / 2);
  const start = Math.max(0, at - Math.max(0, lead));
  const end = Math.min(body.length, start + Math.max(SNIPPET_CHARS, length));
  const flat = body.slice(start, end).replace(/\s+/g, " ").trim();
  return `${start > 0 ? "…" : ""}${flat}${end < body.length ? "…" : ""}`;
}

function envelope(session: NotesSession) {
  return { source: "local" as const, snapshot: session.index.openedViaSnapshot };
}
