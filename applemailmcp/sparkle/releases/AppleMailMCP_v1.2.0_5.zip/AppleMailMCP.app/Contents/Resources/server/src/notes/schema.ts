//
//  schema.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 15/10/2026.
//

import type { ReadOnlyIndex } from "../db.ts";

const OBJECTS = "ZICCLOUDSYNCINGOBJECT";

const REQUIRED_TABLES = [OBJECTS, "ZICNOTEDATA", "Z_PRIMARYKEY"] as const;

/** Every column this code reads by its plain name, per table. */
const REQUIRED_COLUMNS: Record<string, readonly string[]> = {
  [OBJECTS]: [
    "Z_PK",
    "Z_ENT",
    "ZIDENTIFIER",
    "ZMARKEDFORDELETION",
    "ZISPASSWORDPROTECTED",
    "ZISPINNED",
    "ZSNIPPET",
    "ZFOLDER",
    "ZNOTEDATA",
    "ZPARENT",
    "ZFOLDERTYPE",
    "ZSMARTFOLDERQUERYJSON",
    "ZNAME",
    "ZMEDIA",
    "ZFILENAME",
    "ZUSERTITLE",
  ],
  ZICNOTEDATA: ["Z_PK", "ZNOTE", "ZDATA"],
  Z_PRIMARYKEY: ["Z_ENT", "Z_NAME"],
};

/**
 * Core Data numbers its entities per model, so they are looked up by name on
 * every open and never hard-coded. The store checked has ICNote at 12, ICFolder
 * 15, ICAccount 14, ICAttachment 5 and ICInlineAttachment 9.
 */
export type NotesEntities = {
  note: number;
  folder: number;
  account: number;
  attachment: number;
  /** Absent from older models; inline attachments (hashtags, mentions) came later. */
  inlineAttachment: number | null;
};

/**
 * Every entity shares the one single-table-inheritance table, so a property
 * two entities both declare becomes several numbered columns, and which number
 * an entity got depends on the model version. On the store checked, of seven
 * creation/modification-date candidates notes populate only `ZCREATIONDATE3`
 * and `ZMODIFICATIONDATE1`; the title is `ZTITLE1` on a note, `ZTITLE2` on a
 * folder and `ZTITLE` on an attachment. So each of these is resolved by
 * probing which candidate the entity actually populates.
 */
export type NotesColumns = {
  noteTitle: string;
  noteCreated: string;
  noteModified: string;
  noteAccount: string;
  folderTitle: string;
  folderAccount: string;
  attachmentTitle: string;
  attachmentType: string;
  /** Null when the model has no inline-attachment entity. */
  inlineType: string | null;
};

export type NotesSchema = { entities: NotesEntities; columns: NotesColumns };

/** How far a numbered family is probed: `ZTITLE`, `ZTITLE1` … `ZTITLE12`. */
const MAX_SUFFIX = 12;

type Probe = {
  role: keyof NotesColumns;
  family: string;
  entity: keyof NotesEntities;
  /** What the verified store uses, for an entity with no rows to probe. */
  fallback: string;
};

const PROBES: Probe[] = [
  { role: "noteTitle", family: "ZTITLE", entity: "note", fallback: "ZTITLE1" },
  { role: "noteCreated", family: "ZCREATIONDATE", entity: "note", fallback: "ZCREATIONDATE3" },
  { role: "noteModified", family: "ZMODIFICATIONDATE", entity: "note", fallback: "ZMODIFICATIONDATE1" },
  { role: "noteAccount", family: "ZACCOUNT", entity: "note", fallback: "ZACCOUNT7" },
  { role: "folderTitle", family: "ZTITLE", entity: "folder", fallback: "ZTITLE2" },
  { role: "folderAccount", family: "ZACCOUNT", entity: "folder", fallback: "ZACCOUNT8" },
  { role: "attachmentTitle", family: "ZTITLE", entity: "attachment", fallback: "ZTITLE" },
  { role: "attachmentType", family: "ZTYPEUTI", entity: "attachment", fallback: "ZTYPEUTI" },
  { role: "inlineType", family: "ZTYPEUTI", entity: "inlineAttachment", fallback: "ZTYPEUTI1" },
];

const ENTITY_NAMES: Record<keyof NotesEntities, string> = {
  note: "ICNote",
  folder: "ICFolder",
  account: "ICAccount",
  attachment: "ICAttachment",
  inlineAttachment: "ICInlineAttachment",
};

/**
 * Asserts the tables and plain columns this code reads, resolves the entity
 * numbers by name, and resolves every numbered column by probing. Anything
 * missing is named rather than guessed at.
 */
export function assertKnownNotesSchema(index: ReadOnlyIndex): NotesSchema {
  const tables = new Set(
    index
      .all<{ name: string }>(`SELECT name FROM sqlite_master WHERE type = 'table'`)
      .map((row) => row.name),
  );
  const missingTables = REQUIRED_TABLES.filter((name) => !tables.has(name));
  if (missingTables.length > 0) {
    throw new Error(
      `Unknown Notes schema: missing tables ${missingTables.join(", ")}. Refusing to guess column meanings.`,
    );
  }

  // As in the other guards: the authorizer denies PRAGMA, so a LIMIT 0
  // prepare is how a missing column is detected without reading a row.
  const missing: string[] = [];
  for (const [table, columns] of Object.entries(REQUIRED_COLUMNS)) {
    for (const column of columns) {
      if (!hasColumn(index, table, column)) {
        missing.push(`${table}.${column}`);
      }
    }
  }
  if (missing.length > 0) {
    throw new Error(`Unknown Notes schema: missing ${missing.join(", ")}. Refusing to guess column meanings.`);
  }

  const entities = resolveEntities(index);
  const columns = {} as NotesColumns;
  const unresolved: string[] = [];
  for (const probe of PROBES) {
    const entity = entities[probe.entity];
    if (entity === null) {
      (columns as Record<string, string | null>)[probe.role] = null;
      continue;
    }
    const resolved = probeFamily(index, probe.family, entity, probe.fallback);
    if (resolved === null) {
      unresolved.push(`${probe.family}* for ${ENTITY_NAMES[probe.entity]} (${probe.role})`);
    } else {
      (columns as Record<string, string | null>)[probe.role] = resolved;
    }
  }
  if (unresolved.length > 0) {
    throw new Error(
      `Unknown Notes schema: no column found for ${unresolved.join(", ")}. Refusing to guess column meanings.`,
    );
  }
  return { entities, columns };
}

function resolveEntities(index: ReadOnlyIndex): NotesEntities {
  const byName = new Map(
    index
      .all<{ Z_ENT: number; Z_NAME: string }>(`SELECT Z_ENT, Z_NAME FROM Z_PRIMARYKEY`)
      .map((row) => [row.Z_NAME, row.Z_ENT]),
  );
  const required: (keyof NotesEntities)[] = ["note", "folder", "account", "attachment"];
  const absent = required.filter((key) => !byName.has(ENTITY_NAMES[key])).map((key) => ENTITY_NAMES[key]);
  if (absent.length > 0) {
    throw new Error(`Unknown Notes schema: Z_PRIMARYKEY has no ${absent.join(", ")} entity.`);
  }
  return {
    note: byName.get("ICNote")!,
    folder: byName.get("ICFolder")!,
    account: byName.get("ICAccount")!,
    attachment: byName.get("ICAttachment")!,
    inlineAttachment: byName.get("ICInlineAttachment") ?? null,
  };
}

/**
 * The family member this entity populates most. When the entity has no rows
 * with any of them set — an empty store, or a folder-less one — there is
 * nothing to be wrong about, so the verified name is used if it exists, and
 * failing that the first member that does.
 */
function probeFamily(index: ReadOnlyIndex, family: string, entity: number, fallback: string): string | null {
  const candidates = [family, ...Array.from({ length: MAX_SUFFIX }, (_, i) => `${family}${i + 1}`)].filter(
    (column) => hasColumn(index, OBJECTS, column),
  );
  if (candidates.length === 0) {
    return null;
  }
  const counts = index.get<Record<string, number>>(
    `SELECT ${candidates.map((c, i) => `count("${c}") AS c${i}`).join(", ")} FROM ${OBJECTS} WHERE Z_ENT = ?`,
    [entity],
  )!;
  let best: string | null = null;
  let bestCount = 0;
  for (const [i, column] of candidates.entries()) {
    const count = counts[`c${i}`];
    if (count > bestCount) {
      best = column;
      bestCount = count;
    }
  }
  if (best !== null) {
    return best;
  }
  return candidates.includes(fallback) ? fallback : candidates[0];
}

function hasColumn(index: ReadOnlyIndex, table: string, column: string): boolean {
  try {
    index.all(`SELECT "${column}" FROM "${table}" LIMIT 0`);
    return true;
  } catch {
    return false;
  }
}

export function wrapNotesError(error: unknown, fallback: string): Error {
  const err = error as { message?: string; code?: string };
  const message = err.message ?? String(error);
  const code = err.code ?? "";
  if (code === "SQLITE_BUSY" || /locked|SQLITE_BUSY/i.test(message)) {
    return new Error(`Notes database is locked or busy. ${message}`);
  }
  if (code === "EACCES" || code === "EPERM" || /permission denied|unable to open/i.test(message)) {
    return new Error(
      `Cannot read the Notes store (${message}). Grant Full Disk Access to the terminal / Node / MCP host — ` +
        `the group container is protected by TCC even for the user who owns it.`,
    );
  }
  if (code === "ENOENT") {
    return new Error(message);
  }
  return new Error(`${fallback}: ${message}`);
}
