//
//  session.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 15/10/2026.
//

import { existsSync } from "node:fs";
import { resolve } from "node:path";
import { openIndex, type ReadOnlyIndex } from "../db.ts";
import { assertKnownNotesSchema, wrapNotesError, type NotesSchema } from "./schema.ts";
import { findNotesStore, isInsideLiveNotesStore } from "./store.ts";

export type NotesSession = {
  index: ReadOnlyIndex;
  schema: NotesSchema;
  close: () => void;
};

export function openNotesSession(options: { dbPath?: string; home?: string } = {}): NotesSession {
  try {
    const dbPath = resolveDbPath(options);
    const index = openIndex(dbPath, options.home, {
      isLive: isInsideLiveNotesStore,
      label: "Notes",
    });
    try {
      const schema = assertKnownNotesSchema(index);
      return { index, schema, close: () => index.close() };
    } catch (error) {
      index.close();
      throw error;
    }
  } catch (error) {
    throw wrapNotesError(error, "failed to open Notes session");
  }
}

function resolveDbPath(options: { dbPath?: string; home?: string }): string {
  if (!options.dbPath) {
    return findNotesStore(options.home).dbPath;
  }
  const abs = resolve(options.dbPath);
  if (!existsSync(abs)) {
    throw new Error(`Notes database not found: ${abs}`);
  }
  return abs;
}
