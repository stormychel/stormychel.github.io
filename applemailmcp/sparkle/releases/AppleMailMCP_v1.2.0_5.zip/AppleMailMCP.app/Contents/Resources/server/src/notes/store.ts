//
//  store.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 15/10/2026.
//

import { existsSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
import { canonicalPath, isInsideCanonical, sharesInodeWith, sqliteFamily } from "../store.ts";
import type { NotesStore } from "./types.ts";

const GROUP_CONTAINER = "group.com.apple.notes";
const DB_NAME = "NoteStore.sqlite";

/**
 * Notes keeps one Core Data store for every account, directly in its group
 * container. The whole container is treated as live, not only the database:
 * notesd owns all of it — attachment media under `Accounts/<uuid>/Media`
 * included — and a snapshot is only worth anything if SQLite can never be
 * pointed at a file next to one.
 */
export function notesContainerForHome(home: string = homedir()): string {
  return join(home, "Library", "Group Containers", GROUP_CONTAINER);
}

export function isInsideLiveNotesStore(path: string, home: string = homedir()): boolean {
  if (isInsideCanonical(path, notesContainerForHome(home))) {
    return true;
  }
  return sharesInodeWith(canonicalPath(path), () => sqliteFamily(findNotesStore(home).dbPath));
}

export function findNotesStore(home: string = homedir()): NotesStore {
  const root = notesContainerForHome(home);
  if (!existsSync(root)) {
    throw new Error(`Notes store not found at ${root}. Notes has to have been opened on this Mac at least once.`);
  }
  const dbPath = join(root, DB_NAME);
  if (!existsSync(dbPath)) {
    throw new Error(`${DB_NAME} missing at ${dbPath}.`);
  }
  return { root, dbPath };
}
