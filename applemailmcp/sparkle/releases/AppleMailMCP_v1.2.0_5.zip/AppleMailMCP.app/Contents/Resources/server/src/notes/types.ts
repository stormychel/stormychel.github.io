//
//  types.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 15/10/2026.
//

export type NotesStore = {
  /** The `group.com.apple.notes` group container. */
  root: string;
  /** `NoteStore.sqlite`: one file for every account, unlike Reminders. */
  dbPath: string;
};

export type FolderType = "default" | "recently-deleted" | `type ${number}`;

export type NoteFolderRow = {
  /** ZIDENTIFIER, a UUID string. */
  id: string;
  name: string | null;
  account: string | null;
  parentId: string | null;
  parentName: string | null;
  type: FolderType;
  /** A smart folder holds a saved query, not notes; its noteCount is 0. */
  smart: boolean;
  noteCount: number;
};

export type NoteAttachment = {
  id: string;
  /** Uniform type identifier, e.g. `public.jpeg`, `com.apple.notes.table`. */
  type: string | null;
  /** User title, generated title or media file name, whichever exists. */
  name: string | null;
};

/**
 * `decoded`: the body was read out of its protobuf. `locked`: the note is
 * password-protected and its body is encrypted. `unfetched`: Notes holds a
 * stub for this note with no body yet (see the README). `undecodable`: a body
 * exists but is not in the layout this code was verified against.
 */
export type BodyStatus = "decoded" | "locked" | "unfetched" | "undecodable";

export type NoteRow = {
  id: string;
  title: string | null;
  folder: string | null;
  folderId: string | null;
  account: string | null;
  created: string | null;
  modified: string | null;
  pinned: boolean;
  locked: boolean;
  /** Search rows only: matching context from the body, or Notes' own snippet. */
  snippet?: string;
};

export type NoteDetail = NoteRow & {
  bodyStatus: BodyStatus;
  body: string | null;
  bodyLength: number;
  bodyOffset: number;
  bodyTruncated: boolean;
  nextOffset: number | null;
  attachments: NoteAttachment[];
};

export type NoteQuery = {
  /** Substring of the title or decoded body, case-insensitive. */
  text?: string;
  /** Folder name substring, or a folder id. */
  folder?: string;
  /** Apple reference-date seconds, inclusive, on the modification date. */
  modifiedFrom?: number;
  modifiedTo?: number;
  /** Include notes sitting in Recently Deleted. */
  includeDeleted?: boolean;
  limit?: number;
};
