//
//  osascript.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 19/09/2026.
//

import { spawnSync } from "node:child_process";

export const DEFAULT_OSASCRIPT = "/usr/bin/osascript";

/**
 * Ten minutes: the first-run Automation prompt blocks osascript until the user
 * answers it, which can mean a trip into System Settings. Two minutes cut that
 * off and reported a failure for an action that then went through. Still
 * bounded, so a hung app cannot hold a tool call open forever.
 */
export const DEFAULT_TIMEOUT_MS = 600_000;

export type RunOptions = {
  osascriptPath?: string;
  timeoutMs?: number;
  /** The application the script drives, named in error messages. */
  app: string;
  /** App-specific wording for a failure, tried before the generic explanations. */
  explain?: (message: string) => string | null;
};

/**
 * The one bridge from this repo to an Apple app. Mail's write path, Calendar's
 * create_event and Reminders' create_reminder all go through it.
 *
 * The script is fed on stdin and every value travels as an `on run argv`
 * argument, never interpolated into the source, so a quote or a line break in
 * a subject or title is data and can never become script. Returns stdout,
 * trimmed, or null when the script printed nothing.
 */
export function runOsascript(script: string, args: string[], options: RunOptions): string | null {
  const result = spawnSync(options.osascriptPath ?? DEFAULT_OSASCRIPT, ["-", ...args], {
    input: script,
    encoding: "utf8",
    timeout: options.timeoutMs ?? DEFAULT_TIMEOUT_MS,
  });
  if (result.error) {
    const code = (result.error as NodeJS.ErrnoException).code;
    if (code === "ETIMEDOUT") {
      const ms = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
      // Giving up on the script does not undo what it may already have done,
      // so the caller is told to look before trying again.
      throw new Error(
        `${options.app} did not answer within ${formatDuration(ms)}. It may be waiting on a dialog or be busy. ` +
          `The action may still have completed: check ${options.app} before retrying.`,
      );
    }
    throw new Error(`Could not run osascript: ${result.error.message}`);
  }
  if (result.status !== 0) {
    throw new Error(explainOsascriptFailure(result.stderr ?? "", options));
  }
  const out = (result.stdout ?? "").trim();
  return out.length > 0 ? out : null;
}

function formatDuration(ms: number): string {
  if (ms >= 60_000 && ms % 60_000 === 0) return `${ms / 60_000} min`;
  if (ms >= 1000) return `${Math.round(ms / 1000)}s`;
  return `${ms}ms`;
}

/**
 * Whether the app is already running, asked of the process list rather than
 * of the app: `tell application "Mail"` launches it, and even
 * `application "Mail" is running` goes through osascript, which the tests
 * replace with a stub that cannot tell one script from another. pgrep needs
 * no Automation grant, cannot launch anything, and answers in ~40ms.
 */
export function appIsRunning(processName: string): boolean {
  // -U: this user's processes only. The same app running in another logged-in
  // user's session is not ours to talk to, and counting it would let Launch
  // Services start a second copy here — the launch the check exists to avoid.
  const uid = process.getuid?.();
  const args = uid === undefined ? ["-x", processName] : ["-U", String(uid), "-x", processName];
  return spawnSync("/usr/bin/pgrep", args, { encoding: "utf8" }).status === 0;
}

export function explainOsascriptFailure(
  stderr: string,
  options: Pick<RunOptions, "app" | "explain">,
): string {
  const message = stderr.trim() || "osascript failed with no output";
  const specific = options.explain?.(message);
  if (specific) {
    return specific;
  }
  if (/-1743|not (allowed|authori[sz]ed)/i.test(message)) {
    return (
      `${options.app} automation is not permitted: ${message}. ` +
      `Grant the host app (Terminal, or Claude Code) control of ${options.app} under ` +
      "System Settings → Privacy & Security → Automation."
    );
  }
  if (/-600|isn['’]t running|not running/i.test(message)) {
    return `${options.app} could not be reached: ${message}. Open ${options.app} and retry.`;
  }
  return message;
}
