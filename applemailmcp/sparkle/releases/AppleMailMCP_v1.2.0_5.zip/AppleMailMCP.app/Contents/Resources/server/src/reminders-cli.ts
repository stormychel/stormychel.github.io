#!/usr/bin/env node
//
//  reminders-cli.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 19/09/2026.
//

import { parseRangeBound } from "./calendar/format.ts";
import { getReminder, listReminderLists, searchReminders } from "./reminders/reminders.ts";
import { openRemindersSession } from "./reminders/session.ts";
import type { Priority, ReminderStatus } from "./reminders/types.ts";
import { createReminder, writeEnabled, WRITE_ENV } from "./reminders/write.ts";

const USAGE = `Usage:
  applerem lists [options]
  applerem search [options]
  applerem get --id <uuid> [options]
  applerem create --list <name> --title <text> [options]
  applerem mcp

Reads never touch a live store: remindd keeps one Core Data store per account,
and each is APFS-cloned to a temp snapshot before SQLite opens it. create never
touches SQLite at all; it goes through Reminders.app, and only when
${WRITE_ENV}=1.

Options:
  --db <path>            A Data-*.sqlite store (repeatable; skips discovery)
  --text <text>          Title or notes substring (search)
  --list <name|id>       List name substring or list id (search) / exact list name (create)
  --list-id <uuid>       List id (create), for when two lists share a name
  --title <text>         Reminder title (create)
  --notes <text>         Reminder notes (create)
  --due <when>           YYYY-MM-DD for all-day, or local 2026-09-21T09:00 (create)
  --priority <p>         high, medium, low or none (create)
  --dry-run              Resolve and print what would be created, write nothing
  --status <s>           open (default), completed or all (search)
  --due-from <date>      Due on or after; a bare date is the start of that local day
  --due-to <date>        Due on or before; a bare date is the end of that local day
  --flagged              Only flagged reminders (search) / flag it (create)
  --unflagged            Only unflagged reminders (search)
  --id <uuid>            Reminder id (get)
  --limit <n>            Max rows (default 50, hard cap 1000)
  --help                 Show this help
`;

const PRIORITIES = new Set<Priority | "none">(["high", "medium", "low", "none"]);

const STATUSES = new Set<ReminderStatus>(["open", "completed", "all"]);

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  if (args.length === 0 || args.includes("--help") || args.includes("-h")) {
    process.stdout.write(USAGE);
    process.exit(args.length === 0 ? 1 : 0);
  }

  const command = args[0];
  if (command.startsWith("-")) {
    fail(`missing command. ${USAGE}`);
  }

  if (command === "mcp") {
    const { startStdioServer } = await import("./reminders-server.ts");
    await startStdioServer();
    return;
  }

  const flags = parseFlags(args.slice(1));
  const session = openRemindersSession({ dbPaths: flags.db });
  try {
    if (command === "lists") {
      printJson(listReminderLists(session));
      return;
    }
    if (command === "search") {
      printJson(
        searchReminders(session, {
          text: flags.text,
          list: flags.list,
          status: flags.status,
          dueFrom: flags.dueFrom ? parseRangeBound(flags.dueFrom, "from") : undefined,
          dueTo: flags.dueTo ? parseRangeBound(flags.dueTo, "to") : undefined,
          flagged: flags.flagged,
          limit: flags.limit,
        }),
      );
      return;
    }
    if (command === "get") {
      if (!flags.id) {
        fail("--id is required for get (search shows them)");
      }
      printJson(getReminder(session, flags.id));
      return;
    }
    if (command === "create") {
      if (!flags.dryRun && !writeEnabled()) {
        fail(
          `writing is disabled. Set ${WRITE_ENV}=1 to allow it, or pass --dry-run to see what would be created.`,
        );
      }
      if (!flags.title) {
        fail("--title is required for create");
      }
      printJson(
        await createReminder(
          session,
          {
            list: flags.list,
            listId: flags.listId,
            title: flags.title,
            notes: flags.notes,
            due: flags.due,
            priority: flags.priority,
            flagged: flags.flagged,
          },
          { dryRun: flags.dryRun === true, readBack: () => openRemindersSession({ dbPaths: flags.db }) },
        ),
      );
      return;
    }
    fail(`unknown command: ${command}\n${USAGE}`);
  } finally {
    session.close();
  }
}

type Flags = {
  db?: string[];
  text?: string;
  list?: string;
  status?: ReminderStatus;
  dueFrom?: string;
  dueTo?: string;
  flagged?: boolean;
  id?: string;
  listId?: string;
  title?: string;
  notes?: string;
  due?: string;
  priority?: Priority | "none";
  dryRun?: boolean;
  limit?: number;
};

function parseFlags(argv: string[]): Flags {
  const flags: Flags = {};
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    const next = (): string => {
      const value = argv[i + 1];
      if (value === undefined) {
        fail(`missing value for ${arg}`);
      }
      i += 1;
      return value;
    };
    switch (arg) {
      case "--db":
        (flags.db ??= []).push(next());
        break;
      case "--text":
        flags.text = next();
        break;
      case "--list":
        flags.list = next();
        break;
      case "--status": {
        const value = next() as ReminderStatus;
        if (!STATUSES.has(value)) {
          fail("--status must be open, completed or all");
        }
        flags.status = value;
        break;
      }
      case "--due-from":
        flags.dueFrom = next();
        break;
      case "--due-to":
        flags.dueTo = next();
        break;
      case "--flagged":
        flags.flagged = true;
        break;
      case "--unflagged":
        flags.flagged = false;
        break;
      case "--id":
        flags.id = next();
        break;
      case "--list-id":
        flags.listId = next();
        break;
      case "--title":
        flags.title = next();
        break;
      case "--notes":
        flags.notes = next();
        break;
      case "--due":
        flags.due = next();
        break;
      case "--priority": {
        const value = next() as Priority | "none";
        if (!PRIORITIES.has(value)) {
          fail("--priority must be high, medium, low or none");
        }
        flags.priority = value;
        break;
      }
      case "--dry-run":
        flags.dryRun = true;
        break;
      case "--limit": {
        const value = Number(next());
        if (!Number.isFinite(value)) {
          fail("--limit must be a number");
        }
        flags.limit = value;
        break;
      }
      default:
        fail(`unknown option: ${arg}`);
    }
  }
  return flags;
}

function printJson(value: unknown): void {
  process.stdout.write(`${JSON.stringify(value, null, 2)}\n`);
}

function fail(message: string): never {
  process.stderr.write(`${message}\n`);
  process.exit(1);
}

main().catch((error) => {
  process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
  process.exit(1);
});
