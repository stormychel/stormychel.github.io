#!/usr/bin/env node
//
//  reminders-server.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 19/09/2026.
//

import { basename } from "node:path";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { reportHealth } from "./health.ts";
import { findRemindersStore, remindersContainerForHome } from "./reminders/store.ts";
import { parseRangeBound } from "./calendar/format.ts";
import { getReminder, listReminderLists, searchReminders } from "./reminders/reminders.ts";
import { openRemindersSession, type RemindersSession } from "./reminders/session.ts";
import { createReminder, WRITE_ENV, writeEnabled } from "./reminders/write.ts";

export const MCP_DEFAULT_LIMIT = 20;
export const MCP_MAX_LIMIT = 50;

const READ_ONLY = {
  readOnlyHint: true,
  destructiveHint: false,
  idempotentHint: true,
  openWorldHint: false,
} as const;

const WRITES = {
  readOnlyHint: false,
  // Nothing existing is modified or removed — create_reminder only ever adds.
  destructiveHint: false,
  idempotentHint: false,
  openWorldHint: false,
} as const;

const limitSchema = z.number().int().min(1).max(MCP_MAX_LIMIT).optional();

export function createRemindersServer(
  sessionFactory: () => RemindersSession = () => openRemindersSession(),
  options: { enableWrite?: boolean; osascriptPath?: string } = {},
): McpServer {
  const enableWrite = options.enableWrite ?? writeEnabled();
  const server = new McpServer({
    name: "applereminders",
    version: "0.6.0",
    title: enableWrite ? "Apple Reminders" : "Apple Reminders (read-only)",
  });

  const withSession = async (fn: (session: RemindersSession) => Promise<unknown> | unknown) => {
    // Opening is inside the try for the same reason as the other servers: a
    // locked store or a missing Full Disk Access grant has to come back in the
    // same {error: ...} envelope as every other failure.
    let session: RemindersSession | null = null;
    try {
      session = sessionFactory();
      const result = await fn(session);
      return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      return {
        isError: true,
        content: [{ type: "text" as const, text: JSON.stringify({ error: message }, null, 2) }],
      };
    } finally {
      session?.close();
    }
  };

  server.registerTool(
    "list_reminder_lists",
    {
      title: "List Reminder Lists",
      description:
        "Read-only list of the Reminders lists on this Mac, across every account, with open and " +
        "completed counts. Use a returned id or name as the list filter of search_reminders.",
      inputSchema: {},
      annotations: READ_ONLY,
    },
    async () => withSession((session) => listReminderLists(session)),
  );

  server.registerTool(
    "search_reminders",
    {
      title: "Search Reminders",
      description:
        "Read-only search of Apple Reminders on this Mac, across every account. Returns open reminders " +
        "unless status says otherwise, soonest due first (undated last); completed ones come back most " +
        "recently completed first. An all-day dueDate is a plain YYYY-MM-DD date, a timed one an ISO " +
        "instant with its timeZone. A zero-result search means not found locally. Notes come back as a " +
        "snippet; use get_reminder for the full text and subtasks. Results are capped.",
      inputSchema: {
        text: z.string().optional().describe("Substring of the title or notes, case-insensitive"),
        list: z.string().optional().describe("List name substring, or a list id from list_reminder_lists"),
        status: z
          .enum(["open", "completed", "all"])
          .optional()
          .describe("Default open"),
        dueFrom: z
          .string()
          .optional()
          .describe("Due on or after: a bare date means the start of that local day; ISO-8601 or YYYYMMDD"),
        dueTo: z
          .string()
          .optional()
          .describe("Due on or before: a bare date means the end of that local day; ISO-8601 or YYYYMMDD"),
        flagged: z.boolean().optional().describe("true for flagged reminders only, false for unflagged"),
        limit: limitSchema.describe(`Max rows (default ${MCP_DEFAULT_LIMIT}, cap ${MCP_MAX_LIMIT})`),
      },
      annotations: READ_ONLY,
    },
    async (args) =>
      withSession((session) =>
        searchReminders(session, {
          text: args.text,
          list: args.list,
          status: args.status,
          dueFrom: args.dueFrom ? parseRangeBound(args.dueFrom, "from") : undefined,
          dueTo: args.dueTo ? parseRangeBound(args.dueTo, "to") : undefined,
          flagged: args.flagged,
          limit: args.limit ?? MCP_DEFAULT_LIMIT,
        }),
      ),
  );

  server.registerTool(
    "get_reminder",
    {
      title: "Get Reminder",
      description:
        "Read-only fetch of one reminder in full: notes, list, account, dates, priority, flag and its " +
        "subtasks. Takes the id returned by search_reminders.",
      inputSchema: {
        id: z.string().describe("Reminder id (a UUID) from search_reminders"),
      },
      annotations: READ_ONLY,
    },
    async (args) => withSession((session) => getReminder(session, args.id)),
  );

  // Registered, not merely refused: with the gate off the tool is absent from
  // tools/list, so a model cannot decide to try it.
  if (enableWrite) {
    server.registerTool(
      "create_reminder",
      {
        title: "Create Reminder",
        description:
          "Creates one reminder through Reminders.app, then reads it back from the local store and returns " +
          "what was stored. Only adds; nothing existing is changed. Pass dryRun to validate and see exactly " +
          "what would be created without writing.",
        inputSchema: {
          list: z
            .string()
            .optional()
            .describe("Exact list name from list_reminder_lists. Refused if two lists share it. Use this or listId, not both."),
          listId: z.string().optional().describe("List id (UUID) from list_reminder_lists"),
          title: z.string().describe("Reminder title"),
          notes: z.string().optional(),
          due: z
            .string()
            .optional()
            .describe("YYYY-MM-DD for an all-day reminder, or a local date-time such as 2026-09-21T09:00"),
          priority: z.enum(["high", "medium", "low", "none"]).optional(),
          flagged: z.boolean().optional(),
          dryRun: z.boolean().optional().describe("Resolve and validate without creating anything"),
        },
        annotations: WRITES,
      },
      async (args) =>
        withSession((session) =>
          createReminder(
            session,
            {
              list: args.list,
              listId: args.listId,
              title: args.title,
              notes: args.notes,
              due: args.due,
              priority: args.priority,
              flagged: args.flagged,
            },
            {
              dryRun: args.dryRun === true,
              osascriptPath: options.osascriptPath,
              readBack: sessionFactory,
            },
          ),
        ),
    );
  }

  return server;
}

export { WRITE_ENV };

export async function startStdioServer(): Promise<void> {
  // Which app started this server, and whether its store opened under it (#99).
  reportHealth("reminders", () => findRemindersStore().dbPaths[0], remindersContainerForHome());
  const server = createRemindersServer();
  const transport = new StdioServerTransport();
  await server.connect(transport);
}

// basename, not endsWith: a suffix test would start this server whenever
// another *-server.ts is the entry point and anything pulls this module in.
const entry = basename(process.argv[1] ?? "");
if (entry === "reminders-server.ts" || entry === "reminders-server.js") {
  startStdioServer().catch((error) => {
    process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
    process.exit(1);
  });
}
