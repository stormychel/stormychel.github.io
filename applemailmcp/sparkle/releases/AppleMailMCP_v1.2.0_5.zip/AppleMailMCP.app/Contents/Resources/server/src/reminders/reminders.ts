//
//  reminders.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 19/09/2026.
//

import { DEFAULT_LIMIT, MAX_LIMIT } from "../db.ts";
import { clampLimit, epochToIso, likeContains } from "../format.ts";
import { APPLE_EPOCH_OFFSET, appleToUnix } from "../calendar/format.ts";
import type { RemindersSession, RemindersSource } from "./session.ts";
import type {
  Priority,
  ReminderDetail,
  ReminderListRow,
  ReminderQuery,
  ReminderRow,
  SkippedStore,
} from "./types.ts";

const LOCAL_ONLY_NOTE =
  "Results are from the Reminders stores on this Mac only. A zero-result search means not found locally.";

const NOT_FOUND_LOCALLY = "not found locally";

const SNIPPET_CHARS = 200;

const UUID = /^[0-9a-f]{8}-?[0-9a-f]{4}-?[0-9a-f]{4}-?[0-9a-f]{4}-?[0-9a-f]{12}$/i;

type RawReminder = {
  pk: number;
  hex_id: string;
  title: string | null;
  notes: string | null;
  completed: number | null;
  completion_date: number | null;
  due: number | null;
  all_day: number | null;
  tz: string | null;
  priority: number | null;
  flagged: number | null;
  created: number | null;
  modified: number | null;
  list: string | null;
  list_hex: string | null;
  account: string | null;
  parent_hex: string | null;
};

/**
 * Soft deletes stay in the file until remindd purges them: 9 reminders and 3
 * lists on the store checked carry ZMARKEDFORDELETION = 1, including a second
 * "Travel" list. A reminder in a deleted list is treated as deleted too. One
 * with no list at all is kept, since hiding it would be a guess.
 */
const REMINDER_SELECT = `
  SELECT
    r.Z_PK AS pk,
    hex(r.ZIDENTIFIER) AS hex_id,
    r.ZTITLE AS title,
    r.ZNOTES AS notes,
    r.ZCOMPLETED AS completed,
    r.ZCOMPLETIONDATE AS completion_date,
    r.ZDUEDATE AS due,
    r.ZALLDAY AS all_day,
    r.ZTIMEZONE AS tz,
    r.ZPRIORITY AS priority,
    r.ZFLAGGED AS flagged,
    r.ZCREATIONDATE AS created,
    r.ZLASTMODIFIEDDATE AS modified,
    l.ZNAME AS list,
    hex(l.ZIDENTIFIER) AS list_hex,
    a.ZNAME AS account,
    hex(p.ZIDENTIFIER) AS parent_hex
  FROM ZREMCDREMINDER r
  LEFT JOIN ZREMCDBASELIST l ON l.Z_PK = r.ZLIST
  LEFT JOIN ZREMCDOBJECT a ON a.Z_PK = r.ZACCOUNT AND a.Z_ENT = ?
  LEFT JOIN ZREMCDREMINDER p ON p.Z_PK = r.ZPARENTREMINDER
  WHERE COALESCE(r.ZMARKEDFORDELETION, 0) = 0
    AND (l.Z_PK IS NULL OR COALESCE(l.ZMARKEDFORDELETION, 0) = 0)`;

export function listReminderLists(session: RemindersSession) {
  const lists: ReminderListRow[] = [];
  for (const source of session.sources) {
    const rows = source.index.all<{
      hex_id: string;
      name: string | null;
      account: string | null;
      open_count: number;
      completed_count: number;
    }>(
      `
      SELECT
        hex(l.ZIDENTIFIER) AS hex_id,
        l.ZNAME AS name,
        a.ZNAME AS account,
        (SELECT count(*) FROM ZREMCDREMINDER r
          WHERE r.ZLIST = l.Z_PK AND COALESCE(r.ZMARKEDFORDELETION, 0) = 0
            AND COALESCE(r.ZCOMPLETED, 0) = 0) AS open_count,
        (SELECT count(*) FROM ZREMCDREMINDER r
          WHERE r.ZLIST = l.Z_PK AND COALESCE(r.ZMARKEDFORDELETION, 0) = 0
            AND r.ZCOMPLETED = 1) AS completed_count
      FROM ZREMCDBASELIST l
      LEFT JOIN ZREMCDOBJECT a ON a.Z_PK = l.ZACCOUNT AND a.Z_ENT = ?
      WHERE l.Z_ENT = ?
        AND COALESCE(l.ZMARKEDFORDELETION, 0) = 0
        AND COALESCE(l.ZISGROUP, 0) = 0
      `,
      [source.entities.account, source.entities.list],
    );
    for (const row of rows) {
      lists.push({
        id: formatUuid(row.hex_id) ?? "",
        name: row.name,
        account: row.account,
        openCount: row.open_count,
        completedCount: row.completed_count,
      });
    }
  }
  lists.sort(
    (a, b) =>
      compareText(a.account, b.account) || compareText(a.name, b.name) || compareText(a.id, b.id),
  );
  return {
    count: lists.length,
    ...envelope(session),
    lists,
  };
}

export function searchReminders(session: RemindersSession, query: ReminderQuery = {}) {
  const limit = clampLimit(query.limit, DEFAULT_LIMIT, MAX_LIMIT);
  const status = query.status ?? "open";
  const byCompletion = status === "completed";

  const where: string[] = [];
  const params: unknown[] = [];
  if (status === "open") {
    where.push("COALESCE(r.ZCOMPLETED, 0) = 0");
  } else if (status === "completed") {
    where.push("r.ZCOMPLETED = 1");
  }
  if (query.text) {
    where.push("(r.ZTITLE LIKE ? ESCAPE '#' OR r.ZNOTES LIKE ? ESCAPE '#')");
    params.push(likeContains(query.text), likeContains(query.text));
  }
  if (query.list) {
    const listHex = uuidToHex(query.list);
    if (listHex) {
      where.push("hex(l.ZIDENTIFIER) = ?");
      params.push(listHex);
    } else {
      where.push("l.ZNAME LIKE ? ESCAPE '#'");
      params.push(likeContains(query.list));
    }
  }
  if (query.flagged !== undefined) {
    where.push(query.flagged ? "r.ZFLAGGED = 1" : "COALESCE(r.ZFLAGGED, 0) = 0");
  }
  if (query.dueFrom !== undefined || query.dueTo !== undefined) {
    const range = dueRangeSql(query.dueFrom, query.dueTo);
    where.push(range.sql);
    params.push(...range.params);
  }

  // The SQL order and `compareRows` below must agree exactly: each store is cut
  // to `limit` rows in SQL, and the merged top-N is only right if every store
  // was cut by the same ordering the merge then applies.
  const orderBy = byCompletion
    ? "r.ZCOMPLETIONDATE DESC NULLS LAST, hex_id ASC"
    : "r.ZDUEDATE ASC NULLS LAST, r.ZCREATIONDATE DESC NULLS LAST, hex_id ASC";

  const raw: RawReminder[] = [];
  for (const source of session.sources) {
    raw.push(
      ...source.index.all<RawReminder>(
        `${REMINDER_SELECT}${where.map((clause) => `\n    AND ${clause}`).join("")}
        ORDER BY ${orderBy}
        LIMIT ?`,
        [source.entities.account, ...params, limit],
      ),
    );
  }

  const reminders = raw
    .sort((a, b) => compareRows(a, b, byCompletion))
    .slice(0, limit)
    .map((row) => ({ ...toRow(row), ...snippet(row.notes) }));

  return {
    count: reminders.length,
    limit,
    status,
    note: reminders.length === 0 ? NOT_FOUND_LOCALLY : LOCAL_ONLY_NOTE,
    ...envelope(session),
    reminders,
  };
}

export function getReminder(session: RemindersSession, id: string): ReminderDetail & {
  source: "local";
  snapshot: boolean;
  skippedStores?: SkippedStore[];
} {
  const hex = uuidToHex(id);
  if (!hex) {
    throw new Error(`Invalid reminder id: ${id} (expected a UUID from search_reminders)`);
  }
  const blob = Buffer.from(hex, "hex");
  for (const source of session.sources) {
    const row = source.index.get<RawReminder>(`${REMINDER_SELECT}\n    AND r.ZIDENTIFIER = ?`, [
      source.entities.account,
      blob,
    ]);
    if (row) {
      return {
        ...toRow(row),
        notes: row.notes,
        subtasks: subtasksOf(source, row.pk),
        ...envelope(session),
      };
    }
  }
  throw new Error(`Reminder ${id} ${NOT_FOUND_LOCALLY}.`);
}

function subtasksOf(source: RemindersSource, parentPk: number): ReminderRow[] {
  return source.index
    .all<RawReminder>(
      `${REMINDER_SELECT}
    AND r.ZPARENTREMINDER = ?
    ORDER BY r.ZCREATIONDATE ASC, hex_id ASC`,
      [source.entities.account, parentPk],
    )
    .map(toRow);
}

/**
 * All-day due dates are floating: stored at UTC midnight of the calendar date
 * with ZTIMEZONE NULL (all 10 all-day rows on the store checked). Timed ones
 * are real instants. So a range is applied to each on its own terms — timed
 * rows against the instants, all-day rows by calendar date, where a bound's
 * date is the local date its instant falls on. Comparing an all-day value as
 * an instant happens to work east of Greenwich, where the local day starts
 * before UTC midnight, but west of it the local day starts after: in Los
 * Angeles an all-day reminder for the 21st sits at 17:00 on the 20th and drops
 * out of a search for the 21st.
 */
function dueRangeSql(from: number | undefined, to: number | undefined) {
  const timed: string[] = [];
  const allDay: string[] = [];
  const params: number[] = [];
  const timedParams: number[] = [];
  const allDayParams: number[] = [];
  if (from !== undefined) {
    timed.push("r.ZDUEDATE >= ?");
    timedParams.push(from);
    allDay.push("r.ZDUEDATE >= ?");
    allDayParams.push(localDateAsFloating(from));
  }
  if (to !== undefined) {
    timed.push("r.ZDUEDATE <= ?");
    timedParams.push(to);
    allDay.push("r.ZDUEDATE <= ?");
    allDayParams.push(localDateAsFloating(to));
  }
  params.push(...timedParams, ...allDayParams);
  return {
    sql:
      `r.ZDUEDATE IS NOT NULL AND (` +
      `(COALESCE(r.ZALLDAY, 0) = 0 AND ${timed.join(" AND ")}) OR ` +
      `(r.ZALLDAY = 1 AND ${allDay.join(" AND ")}))`,
    params,
  };
}

/** The local calendar date of an Apple-seconds instant, as that date's UTC midnight. */
function localDateAsFloating(apple: number): number {
  const local = new Date((apple + APPLE_EPOCH_OFFSET) * 1000);
  const utcMidnight = Date.UTC(local.getFullYear(), local.getMonth(), local.getDate());
  return utcMidnight / 1000 - APPLE_EPOCH_OFFSET;
}

function compareRows(a: RawReminder, b: RawReminder, byCompletion: boolean): number {
  if (byCompletion) {
    return compareNullsLast(a.completion_date, b.completion_date, "desc") || compareText(a.hex_id, b.hex_id);
  }
  return (
    compareNullsLast(a.due, b.due, "asc") ||
    compareNullsLast(a.created, b.created, "desc") ||
    compareText(a.hex_id, b.hex_id)
  );
}

/**
 * SQL's `NULLS LAST` in either direction. The direction is a parameter rather
 * than a swap of the arguments: swapping flips which side the null check
 * applies to, which put null completion dates first under `DESC`.
 */
function compareNullsLast(x: number | null, y: number | null, direction: "asc" | "desc"): number {
  if (x === null && y === null) return 0;
  if (x === null) return 1;
  if (y === null) return -1;
  return direction === "asc" ? x - y : y - x;
}

/** Binary order, matching SQLite's default collation rather than the locale's. */
function compareText(x: string | null, y: string | null): number {
  const a = x ?? "";
  const b = y ?? "";
  return a < b ? -1 : a > b ? 1 : 0;
}

function toRow(row: RawReminder): ReminderRow {
  const allDay = row.all_day === 1;
  return {
    id: formatUuid(row.hex_id) ?? "",
    title: row.title,
    list: row.list,
    listId: formatUuid(row.list_hex),
    account: row.account,
    completed: row.completed === 1,
    completionDate: epochToIso(appleToUnix(row.completion_date)),
    dueDate: formatDue(row.due, allDay),
    allDay,
    timeZone: allDay ? null : row.tz,
    priority: mapPriority(row.priority),
    flagged: row.flagged === 1,
    created: epochToIso(appleToUnix(row.created)),
    modified: epochToIso(appleToUnix(row.modified)),
    parentId: formatUuid(row.parent_hex),
  };
}

function formatDue(due: number | null, allDay: boolean): string | null {
  const unix = appleToUnix(due);
  if (unix === null) {
    return null;
  }
  const iso = epochToIso(unix);
  return allDay ? (iso?.slice(0, 10) ?? null) : iso;
}

/**
 * The iCalendar scale Reminders uses: 1–4 high, 5 medium, 6–9 low, 0 none.
 * The app only ever writes 1, 5 and 9, but anything in range is mapped.
 */
function mapPriority(value: number | null): Priority | null {
  if (value === null || value <= 0 || value > 9) return null;
  if (value < 5) return "high";
  if (value === 5) return "medium";
  return "low";
}

function snippet(notes: string | null): { notesSnippet?: string } {
  if (!notes) {
    return {};
  }
  const flat = notes.replace(/\s+/g, " ").trim();
  if (!flat) {
    return {};
  }
  return { notesSnippet: flat.length > SNIPPET_CHARS ? `${flat.slice(0, SNIPPET_CHARS)}…` : flat };
}

function envelope(session: RemindersSession) {
  return {
    source: "local" as const,
    snapshot: session.sources.every((s) => s.index.openedViaSnapshot),
    ...(session.skipped.length > 0 ? { skippedStores: session.skipped } : {}),
  };
}

/** ZIDENTIFIER is a raw 16-byte UUID; SQLite's hex() gives it undashed. */
export function formatUuid(hex: string | null): string | null {
  if (!hex || hex.length !== 32) {
    return null;
  }
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

function uuidToHex(value: string): string | null {
  const trimmed = value.trim();
  return UUID.test(trimmed) ? trimmed.replace(/-/g, "").toUpperCase() : null;
}
