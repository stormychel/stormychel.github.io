//
//  schema.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 19/09/2026.
//

import type { ReadOnlyIndex } from "../db.ts";

const REQUIRED_TABLES = ["ZREMCDREMINDER", "ZREMCDBASELIST", "ZREMCDOBJECT", "Z_PRIMARYKEY"] as const;

/** Every column this code reads, per table. */
const REQUIRED_COLUMNS: Record<string, readonly string[]> = {
  ZREMCDREMINDER: [
    "Z_PK",
    "ZIDENTIFIER",
    "ZTITLE",
    "ZNOTES",
    "ZCOMPLETED",
    "ZCOMPLETIONDATE",
    "ZDUEDATE",
    "ZALLDAY",
    "ZTIMEZONE",
    "ZPRIORITY",
    "ZFLAGGED",
    "ZCREATIONDATE",
    "ZLASTMODIFIEDDATE",
    "ZLIST",
    "ZPARENTREMINDER",
    "ZACCOUNT",
    "ZMARKEDFORDELETION",
  ],
  ZREMCDBASELIST: [
    "Z_PK",
    "Z_ENT",
    "ZIDENTIFIER",
    "ZNAME",
    "ZACCOUNT",
    "ZISGROUP",
    "ZMARKEDFORDELETION",
  ],
  ZREMCDOBJECT: ["Z_PK", "Z_ENT", "ZNAME"],
  Z_PRIMARYKEY: ["Z_ENT", "Z_NAME"],
};

/**
 * Core Data numbers its entities per model, so `Z_ENT` for a list or an
 * account is looked up by name every time rather than hard-coded: the store
 * checked has REMCDList at 3 and REMCDAccount at 14, and nothing promises the
 * next model version keeps either.
 */
export type RemindersEntities = { list: number; account: number };

export class NotARemindersStore extends Error {}

/**
 * Two kinds of mismatch, handled differently. A file missing whole tables is a
 * different kind of store — `Data-local.sqlite` has no ZREMCDBASELIST at all —
 * and is skipped by the caller. A file that has the tables but lacks a column
 * this code reads is drift in a store that does hold reminders, and that is an
 * error rather than a quiet gap in the results.
 */
export function assertKnownRemindersSchema(index: ReadOnlyIndex): RemindersEntities {
  const tables = new Set(
    index
      .all<{ name: string }>(`SELECT name FROM sqlite_master WHERE type = 'table'`)
      .map((row) => row.name),
  );
  const missingTables = REQUIRED_TABLES.filter((name) => !tables.has(name));
  if (missingTables.length > 0) {
    throw new NotARemindersStore(`missing tables ${missingTables.join(", ")}`);
  }

  // As in the Calendar and Messages guards: the authorizer denies PRAGMA, so a
  // LIMIT 0 prepare is how a missing column is detected without reading a row.
  const missing: string[] = [];
  for (const [table, columns] of Object.entries(REQUIRED_COLUMNS)) {
    for (const column of columns) {
      try {
        index.all(`SELECT "${column}" FROM "${table}" LIMIT 0`);
      } catch {
        missing.push(`${table}.${column}`);
      }
    }
  }
  if (missing.length > 0) {
    throw new Error(
      `Unknown Reminders schema: missing ${missing.join(", ")}. Refusing to guess column meanings.`,
    );
  }

  const entities = new Map(
    index
      .all<{ Z_ENT: number; Z_NAME: string }>(
        `SELECT Z_ENT, Z_NAME FROM Z_PRIMARYKEY WHERE Z_NAME IN ('REMCDList', 'REMCDAccount')`,
      )
      .map((row) => [row.Z_NAME, row.Z_ENT]),
  );
  const list = entities.get("REMCDList");
  const account = entities.get("REMCDAccount");
  if (list === undefined || account === undefined) {
    throw new Error(
      "Unknown Reminders schema: Z_PRIMARYKEY has no REMCDList or REMCDAccount entity.",
    );
  }
  return { list, account };
}

export function wrapRemindersError(error: unknown, fallback: string): Error {
  const err = error as { message?: string; code?: string };
  const message = err.message ?? String(error);
  const code = err.code ?? "";
  if (code === "SQLITE_BUSY" || /locked|SQLITE_BUSY/i.test(message)) {
    return new Error(`Reminders database is locked or busy. ${message}`);
  }
  if (code === "EACCES" || code === "EPERM" || /permission denied|unable to open/i.test(message)) {
    return new Error(
      `Cannot read the Reminders store (${message}). Grant Full Disk Access to the terminal / Node / MCP host — ` +
        `the group container is protected by TCC even for the user who owns it.`,
    );
  }
  if (code === "ENOENT") {
    return new Error(message);
  }
  return new Error(`${fallback}: ${message}`);
}
