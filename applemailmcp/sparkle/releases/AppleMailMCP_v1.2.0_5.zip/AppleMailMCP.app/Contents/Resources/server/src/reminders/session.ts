//
//  session.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 19/09/2026.
//

import { existsSync } from "node:fs";
import { basename, resolve } from "node:path";
import { openIndex, type ReadOnlyIndex } from "../db.ts";
import {
  assertKnownRemindersSchema,
  NotARemindersStore,
  wrapRemindersError,
  type RemindersEntities,
} from "./schema.ts";
import { findRemindersStore, isInsideLiveRemindersStore } from "./store.ts";
import type { SkippedStore } from "./types.ts";

export type RemindersSource = {
  /** Store file name, e.g. `Data-<UUID>.sqlite`. */
  file: string;
  index: ReadOnlyIndex;
  entities: RemindersEntities;
};

export type RemindersSession = {
  sources: RemindersSource[];
  skipped: SkippedStore[];
  close: () => void;
};

/**
 * Unlike the other three servers this one reads several databases per call:
 * remindd keeps one store per account. Each is snapshotted and opened on its
 * own through the shared read-only path, and a reminder id is a UUID that is
 * unique across all of them, so callers never need to know which file a row
 * came from.
 */
export function openRemindersSession(
  options: { dbPaths?: string[]; home?: string } = {},
): RemindersSession {
  const sources: RemindersSource[] = [];
  const skipped: SkippedStore[] = [];
  const closeAll = () => {
    for (const source of sources) {
      source.index.close();
    }
  };
  try {
    for (const dbPath of resolveDbPaths(options)) {
      const index = openIndex(dbPath, options.home, {
        isLive: isInsideLiveRemindersStore,
        label: "Reminders",
      });
      try {
        sources.push({ file: basename(dbPath), index, entities: assertKnownRemindersSchema(index) });
      } catch (error) {
        index.close();
        if (!(error instanceof NotARemindersStore)) {
          throw error;
        }
        skipped.push({ file: basename(dbPath), reason: error.message });
      }
    }
    if (sources.length === 0) {
      const reasons = skipped.map((s) => `${s.file}: ${s.reason}`).join("; ");
      throw new Error(`No readable Reminders store (${reasons}).`);
    }
    return { sources, skipped, close: closeAll };
  } catch (error) {
    closeAll();
    throw wrapRemindersError(error, "failed to open Reminders session");
  }
}

function resolveDbPaths(options: { dbPaths?: string[]; home?: string }): string[] {
  if (!options.dbPaths || options.dbPaths.length === 0) {
    return findRemindersStore(options.home).dbPaths;
  }
  return options.dbPaths.map((path) => {
    const abs = resolve(path);
    if (!existsSync(abs)) {
      throw new Error(`Reminders database not found: ${abs}`);
    }
    return abs;
  });
}
