//
//  store.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 19/09/2026.
//

import { existsSync, readdirSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
import { canonicalPath, isInsideCanonical, sharesInodeWith, sqliteFamily } from "../store.ts";
import type { RemindersStore } from "./types.ts";

const GROUP_CONTAINER = "group.com.apple.reminders";
const STORE_FILE = /^Data-.+\.sqlite$/;

/**
 * Reminders does not live in Calendar.sqlitedb. That database carries a
 * `Reminders` store row (`integration:reminders`) and nothing else; the data is
 * in remindd's Core Data stores here, one `Data-<UUID>.sqlite` per account plus
 * `Data-local.sqlite`.
 *
 * The whole group container is treated as live, not just `Stores`: remindd
 * owns all of it, and a snapshot is only worth anything if SQLite can never be
 * pointed at a file next to one.
 */
export function remindersContainerForHome(home: string = homedir()): string {
  return join(home, "Library", "Group Containers", GROUP_CONTAINER);
}

export function remindersStoresDirForHome(home: string = homedir()): string {
  return join(remindersContainerForHome(home), "Container_v1", "Stores");
}

export function isInsideLiveRemindersStore(path: string, home: string = homedir()): boolean {
  if (isInsideCanonical(path, remindersContainerForHome(home))) {
    return true;
  }
  return sharesInodeWith(canonicalPath(path), () =>
    findRemindersStore(home).dbPaths.flatMap((dbPath) => sqliteFamily(dbPath)),
  );
}

export function findRemindersStore(home: string = homedir()): RemindersStore {
  const root = remindersStoresDirForHome(home);
  if (!existsSync(root)) {
    throw new Error(
      `Reminders store not found at ${root}. Reminders has to have been opened on this Mac at least once.`,
    );
  }
  // Sorted so every call reads the stores in the same order, which keeps
  // merged results stable when two rows tie.
  const dbPaths = readdirSync(root)
    .filter((name) => STORE_FILE.test(name))
    .sort()
    .map((name) => join(root, name));
  if (dbPaths.length === 0) {
    throw new Error(`No Data-*.sqlite stores in ${root}.`);
  }
  return { root, dbPaths };
}
