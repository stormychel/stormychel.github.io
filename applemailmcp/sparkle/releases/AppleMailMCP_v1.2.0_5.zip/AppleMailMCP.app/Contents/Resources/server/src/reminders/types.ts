//
//  types.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 19/09/2026.
//

export type RemindersStore = {
  /** The `Stores` directory holding one `Data-*.sqlite` per account. */
  root: string;
  dbPaths: string[];
};

export type ReminderListRow = {
  /** ZIDENTIFIER as a UUID; unique across every store file. */
  id: string;
  name: string | null;
  account: string | null;
  openCount: number;
  completedCount: number;
};

export type Priority = "high" | "medium" | "low";

export type ReminderRow = {
  id: string;
  title: string | null;
  list: string | null;
  listId: string | null;
  account: string | null;
  completed: boolean;
  completionDate: string | null;
  /**
   * `YYYY-MM-DD` for an all-day reminder, which is a date rather than an
   * instant; ISO-8601 in UTC for a timed one.
   */
  dueDate: string | null;
  allDay: boolean;
  /** The zone a timed due date was set in; null for all-day and undated rows. */
  timeZone: string | null;
  priority: Priority | null;
  flagged: boolean;
  created: string | null;
  modified: string | null;
  parentId: string | null;
  /** Present on search rows only: the notes cut down to a snippet. */
  notesSnippet?: string;
};

export type ReminderDetail = ReminderRow & {
  notes: string | null;
  subtasks: ReminderRow[];
};

export type ReminderStatus = "open" | "completed" | "all";

export type ReminderQuery = {
  /** Substring of title or notes, case-insensitive (ASCII). */
  text?: string;
  /** List name substring, or a list id. */
  list?: string;
  status?: ReminderStatus;
  /** Apple reference-date seconds, inclusive. */
  dueFrom?: number;
  dueTo?: number;
  flagged?: boolean;
  limit?: number;
};

export type SkippedStore = { file: string; reason: string };
