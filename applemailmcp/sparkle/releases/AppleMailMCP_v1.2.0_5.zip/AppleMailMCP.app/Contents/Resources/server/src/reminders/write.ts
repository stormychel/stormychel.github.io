//
//  write.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 19/09/2026.
//

import { switchEnabled, type SwitchName } from "../config.ts";
import { formatLocalParts, parseLocalDateTime } from "../calendar/format.ts";
import { runOsascript } from "../osascript.ts";
import { getReminder, listReminderLists } from "./reminders.ts";
import type { RemindersSession } from "./session.ts";
import type { Priority, ReminderDetail } from "./types.ts";

export const WRITE_ENV = "APPLEREM_ENABLE_WRITE" satisfies SwitchName;

/**
 * Off unless explicitly set, and read at registration time so the write tool
 * does not merely refuse — it does not exist. Same shape as Calendar's gate.
 */
export function writeEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
  return switchEnabled(WRITE_ENV, env);
}

export type NewReminder = {
  /** Exact list name. Refused when two lists share it. */
  list?: string;
  /** List id (UUID) from list_reminder_lists. */
  listId?: string;
  title: string;
  notes?: string;
  /** `YYYY-MM-DD` for an all-day reminder, or a local date-time for a timed one. */
  due?: string;
  priority?: Priority | "none";
  flagged?: boolean;
};

export type CreateReminderResult = {
  created: boolean;
  dryRun: boolean;
  id: string | null;
  list: string | null;
  listId: string;
  title: string;
  due: string | null;
  allDay: boolean;
  note: string;
  /** The stored reminder as the read path sees it, when it could be read back. */
  reminder?: ReminderDetail;
  /** Exactly what would be handed to osascript, so a dry run is inspectable. */
  arguments?: string[];
};

export type CreateReminderOptions = {
  dryRun?: boolean;
  osascriptPath?: string;
  /** Opens a fresh session for the read-back; the one used to resolve the list predates the write. */
  readBack?: () => RemindersSession;
  /** How long to keep looking for the new row before reporting it unconfirmed. */
  readBackTimeoutMs?: number;
};

const PRIORITY_VALUE: Record<Priority | "none", number> = { high: 1, medium: 5, low: 9, none: 0 };

const BARE_DATE = /^\d{4}-\d{2}-\d{2}$/;

const UUID = /^[0-9a-f]{8}-?[0-9a-f]{4}-?[0-9a-f]{4}-?[0-9a-f]{4}-?[0-9a-f]{12}$/i;

/**
 * Writing goes through Reminders.app, never through SQLite. remindd owns the
 * Core Data stores and syncs them through CloudKit, so a direct INSERT would be
 * invisible at best and corrupting at worst.
 *
 * The list is resolved against the read path first, so the ambiguity check is
 * exact and the script is always handed an id, never a name. Values reach
 * AppleScript as `on run argv` arguments, not interpolated into the source, so
 * a quote or a line break in a title is data and can never become script.
 */
export async function createReminder(
  session: RemindersSession,
  input: NewReminder,
  options: CreateReminderOptions = {},
): Promise<CreateReminderResult> {
  const title = input.title?.trim();
  if (!title) {
    throw new Error("title is required");
  }
  const target = resolveList(session, input.list, input.listId);

  if (input.priority !== undefined && !(input.priority in PRIORITY_VALUE)) {
    throw new Error(`priority must be high, medium, low or none (got ${input.priority})`);
  }

  let dueSpec = "";
  let allDay = false;
  if (input.due?.trim()) {
    const due = input.due.trim();
    allDay = BARE_DATE.test(due);
    // parseLocalDateTime validates the calendar date and, for a timed value,
    // refuses a time the clocks skip or repeat — the same rules create_event
    // applies, so a reminder cannot land an hour away from what was asked.
    dueSpec = formatLocalParts(parseLocalDateTime(due));
  }

  const args = [
    target.id,
    title,
    input.notes ?? "",
    dueSpec,
    allDay ? "1" : "0",
    String(PRIORITY_VALUE[input.priority ?? "none"]),
    input.flagged ? "1" : "0",
  ];

  const shared = {
    list: target.name,
    listId: target.id,
    title,
    due: dueSpec ? (allDay ? dueSpec.slice(0, 10) : dueSpec) : null,
    allDay,
  };

  if (options.dryRun) {
    return {
      ...shared,
      created: false,
      dryRun: true,
      id: null,
      note: "Dry run — nothing was written. A timed due date is local wall-clock on this Mac.",
      arguments: args,
    };
  }

  const id = parseReminderUrl(
    runOsascript(CREATE_REMINDER_SCRIPT, args, {
      app: "Reminders",
      osascriptPath: options.osascriptPath,
      explain: explainRemindersFailure,
    }),
  );
  const { reminder, error } =
    id && options.readBack ? await readBack(id, options) : { reminder: null, error: null };
  return {
    ...shared,
    created: true,
    dryRun: false,
    id,
    note: reminder
      ? "Created in Reminders.app and read back from the store."
      : error
        ? `Created in Reminders.app, but it could not be read back (${error}). Do not retry the create; search for it instead.`
        : "Created in Reminders.app, but not yet visible in the local store. It may still be syncing; search again shortly.",
    ...(reminder ? { reminder } : {}),
  };
}

function resolveList(
  session: RemindersSession,
  name: string | undefined,
  id: string | undefined,
): { id: string; name: string | null } {
  const listName = name?.trim() ?? "";
  const listId = id?.trim() ?? "";
  if (!listName && !listId) {
    throw new Error("list is required — run list_reminder_lists for names, or pass listId");
  }
  // Two selectors that disagree have no safe resolution, and picking one
  // silently is how a reminder lands in a list nobody named.
  if (listName && listId) {
    throw new Error("pass either list or listId, not both");
  }

  const lists = listReminderLists(session).lists;
  if (listId) {
    if (!UUID.test(listId)) {
      throw new Error(`Invalid listId: ${listId} (expected a UUID from list_reminder_lists)`);
    }
    const normalized = listId.replace(/-/g, "").toUpperCase();
    const match = lists.find((l) => l.id.replace(/-/g, "") === normalized);
    if (!match) {
      throw new Error(`No list with id ${listId}. Run list_reminder_lists for the ids.`);
    }
    return { id: match.id, name: match.name };
  }

  const matches = lists.filter((l) => l.name === listName);
  if (matches.length === 0) {
    throw new Error(`No list named ${listName}. Run list_reminder_lists for the exact names.`);
  }
  if (matches.length > 1) {
    const where = matches.map((l) => `${l.id} (${l.account ?? "unknown account"})`).join(", ");
    throw new Error(`More than one list is named ${listName}: ${where}. Pass listId instead.`);
  }
  return { id: matches[0].id, name: matches[0].name };
}

/** Reminders.app answers `x-apple-reminder://<UUID>`; the UUID is the read path's id. */
function parseReminderUrl(value: string | null): string | null {
  const match = /^x-apple-reminder:\/\/([0-9a-f-]{36})$/i.exec(value ?? "");
  return match ? match[1].toUpperCase() : null;
}

/**
 * remindd persists asynchronously, so the row may not be in the store the
 * instant osascript returns. A fresh snapshot is taken per attempt — the
 * original session is a copy from before the write and can never see it.
 *
 * Nothing in here may throw. By the time it runs the reminder already exists,
 * and an error would read as a failed write and invite a retry that creates a
 * duplicate. That covers failing to open the store, too: the snapshot is taken
 * while remindd is busiest writing, which is exactly when a consistent clone is
 * hardest to get. Any failure is retried until the deadline and then reported
 * alongside the created id.
 */
async function readBack(
  id: string,
  options: CreateReminderOptions,
): Promise<{ reminder: ReminderDetail | null; error: string | null }> {
  const deadline = Date.now() + (options.readBackTimeoutMs ?? 3000);
  for (;;) {
    let error: string | null = null;
    let session: RemindersSession | null = null;
    try {
      session = options.readBack!();
      const { source: _source, snapshot: _snapshot, skippedStores: _skipped, ...reminder } = getReminder(
        session,
        id,
      );
      return { reminder, error: null };
    } catch (caught) {
      const message = caught instanceof Error ? caught.message : String(caught);
      // Not there yet is the expected miss, not an error worth reporting.
      error = /not found locally/.test(message) ? null : message;
    } finally {
      try {
        session?.close();
      } catch {
        // A failed cleanup must not turn a created reminder into an error.
      }
    }
    if (Date.now() >= deadline) {
      return { reminder: null, error };
    }
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
}

/** Reminders-specific wording; the shared runner covers Automation denials and a missing app. */
function explainRemindersFailure(message: string): string | null {
  if (/-1728|Can['’]t get list/i.test(message)) {
    return (
      `${message}. Reminders.app cannot see that list — lists in the local-only ` +
      "accounts are not exposed to AppleScript. Pick an iCloud list."
    );
  }
  return null;
}

/**
 * Seven arguments, positional. The date is built component by component, with
 * month taken from the constant list and day set to 1 first, for the same
 * reasons as Calendar's script: coercing an integer into `month of` is the
 * classic AppleScript foot-gun, and assigning a month to the 31st overflows.
 */
const CREATE_REMINDER_SCRIPT = `
on run argv
  set listId to item 1 of argv
  set theName to item 2 of argv
  set theBody to item 3 of argv
  set dueSpec to item 4 of argv
  set isAllDay to (item 5 of argv is "1")
  set thePriority to (item 6 of argv) as integer
  set isFlagged to (item 7 of argv is "1")

  tell application "Reminders"
    set targetList to list id listId
    set newReminder to make new reminder at end of reminders of targetList with properties {name:theName, priority:thePriority, flagged:isFlagged}
    if theBody is not "" then set body of newReminder to theBody
    if dueSpec is not "" then
      set dueDate to my parseSpec(dueSpec)
      if isAllDay then
        set allday due date of newReminder to dueDate
      else
        set due date of newReminder to dueDate
      end if
    end if
    return id of newReminder
  end tell
end run

on parseSpec(spec)
  set monthList to {January, February, March, April, May, June, July, August, September, October, November, December}
  set theDate to current date
  set day of theDate to 1
  set year of theDate to (text 1 thru 4 of spec) as integer
  set month of theDate to item ((text 6 thru 7 of spec) as integer) of monthList
  set day of theDate to (text 9 thru 10 of spec) as integer
  set hours of theDate to (text 12 thru 13 of spec) as integer
  set minutes of theDate to (text 15 thru 16 of spec) as integer
  set seconds of theDate to 0
  return theDate
end parseSpec
`;

export { CREATE_REMINDER_SCRIPT };
