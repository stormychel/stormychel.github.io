//
//  schema.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 13/08/2026.
//

import type { ReadOnlyIndex } from "./db.ts";

export const KNOWN_INDEX_MAJOR_VERSION = "4";

const REQUIRED_TABLES = [
  "messages",
  "subjects",
  "addresses",
  "recipients",
  "mailboxes",
  "attachments",
] as const;

export function assertKnownSchema(index: ReadOnlyIndex): void {
  let tables: { name: string }[];
  try {
    tables = index.all<{ name: string }>(
      `SELECT name FROM sqlite_master WHERE type = 'table'`,
    );
  } catch (error) {
    throw wrapIndexError(error, "could not read envelope index schema");
  }

  const names = new Set(tables.map((row) => row.name));
  const missing = REQUIRED_TABLES.filter((name) => !names.has(name));
  if (missing.length > 0) {
    throw new Error(
      `Unknown envelope index schema: missing tables ${missing.join(", ")}. Refusing to guess column meanings.`,
    );
  }

  // A missing table or row is as unknown as a wrong number. Skipping the check
  // when the row was absent meant a store that stopped recording its version
  // was read as if it were version 4.
  if (!names.has("properties")) {
    throw new Error(
      "Unknown envelope index schema: no properties table to read the version from. Refusing to guess column meanings.",
    );
  }
  const version = index.get<{ value: string }>(
    `SELECT value FROM properties WHERE key = 'version'`,
  );
  if (!version) {
    throw new Error(
      "Unknown envelope index schema: properties has no version row. Refusing to guess column meanings.",
    );
  }
  if (String(version.value) !== KNOWN_INDEX_MAJOR_VERSION) {
    throw new Error(
      `Unknown envelope index schema version ${version.value} (expected ${KNOWN_INDEX_MAJOR_VERSION}). Refusing to guess column meanings.`,
    );
  }
}

export function wrapIndexError(error: unknown, fallback: string): Error {
  const err = error as { message?: string; code?: string };
  const message = err.message ?? String(error);
  const code = err.code ?? "";
  if (code === "SQLITE_BUSY" || /locked|SQLITE_BUSY/i.test(message)) {
    return new Error(`Envelope index is locked or busy. ${message}`);
  }
  if (code === "EACCES" || code === "EPERM" || /permission denied/i.test(message)) {
    return new Error(
      `Cannot read the Mail store (${message}). Grant Full Disk Access to the terminal / Node / MCP host.`,
    );
  }
  if (code === "ENOENT") {
    return new Error(message);
  }
  return new Error(`${fallback}: ${message}`);
}
