//
//  search.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 13/08/2026.
//

import { DEFAULT_LIMIT, MAX_LIMIT, type ReadOnlyIndex } from "./db.ts";
import { peekBodyFile } from "./emlx.ts";
import { clampLimit, epochToIso, escapeLike, formatFrom, likeContains, LOCAL_ONLY_NOTE, NOT_FOUND_LOCALLY } from "./format.ts";
import type { BodyAvailability, MailStore, SearchQuery, SearchRow } from "./types.ts";

export type RawRow = {
  id: number;
  date_received: number | null;
  sender_address: string | null;
  sender_name: string | null;
  to_addresses: string | null;
  subject: string | null;
  mailbox: string;
  conversation_id: number;
  has_attachments: number;
};

export type SearchResult = {
  count: number;
  limit: number;
  note: string;
  source: "local";
  snapshot: boolean;
  /**
   * Only with afterId: the cursor to pass as afterId on the next poll. The
   * highest id returned, or afterId itself when nothing new matched.
   */
  nextAfterId?: number;
  /** Only with afterId: set when the cursor looks stale. */
  cursorWarning?: string;
  messages: SearchRow[];
};

export function search(
  index: ReadOnlyIndex,
  query: SearchQuery = {},
  options: { store?: MailStore | null } = {},
): SearchResult {
  const limit = clampLimit(query.limit, DEFAULT_LIMIT, MAX_LIMIT);
  const { sql, params } = buildSearchSql(query, limit);
  const rows = index.all<RawRow>(sql, params);
  const messages = rows.map((row) => toSearchRow(row, options.store ?? null));
  return {
    count: messages.length,
    limit,
    note: messages.length === 0 ? NOT_FOUND_LOCALLY : LOCAL_ONLY_NOTE,
    source: "local",
    snapshot: index.openedViaSnapshot,
    ...(query.afterId === undefined ? {} : cursorFields(index, query.afterId, messages)),
    messages,
  };
}

/**
 * Polling instead of MailKit (#31): ROWIDs are AUTOINCREMENT, so "new since
 * the last poll" is every id above the highest one already seen. The rows
 * come back oldest first for this, so a poll that hits its limit stops at a
 * point the next one continues from, with nothing skipped.
 *
 * Two things the cursor cannot tell apart from new mail: a message Mail moved,
 * which it files under a new id, and a mailbox rebuild, which renumbers the
 * index from 1. The rebuild is caught when the cursor is past the highest id
 * the index holds; that is reported rather than answered with silence.
 */
function cursorFields(
  index: ReadOnlyIndex,
  afterId: number,
  messages: SearchRow[],
): Pick<SearchResult, "nextAfterId" | "cursorWarning"> {
  const nextAfterId = messages.reduce((highest, message) => Math.max(highest, message.id), afterId);
  const newest = highestIdIssued(index);
  if (afterId > newest) {
    return {
      nextAfterId,
      cursorWarning:
        `afterId ${afterId} is past the newest message in the index (${newest}), so the index was probably ` +
        "rebuilt and renumbered. Start again from a fresh search rather than trusting this empty answer.",
    };
  }
  return { nextAfterId };
}

/**
 * The highest id the messages table has ever handed out. Not max(ROWID): when
 * Mail purges the newest rows that falls below a cursor that is still valid,
 * and the caller would be told to start over and replay mail it has seen.
 * AUTOINCREMENT keeps its high-water mark in sqlite_sequence, which only a
 * rebuild resets; max(ROWID) is the fallback for an index without it.
 */
function highestIdIssued(index: ReadOnlyIndex): number {
  const hasSequence = index.get<{ n: number }>(
    `SELECT count(*) AS n FROM sqlite_master WHERE type = 'table' AND name = 'sqlite_sequence'`,
  );
  const issued = hasSequence?.n
    ? index.get<{ seq: number | null }>(`SELECT seq FROM sqlite_sequence WHERE name = 'messages'`)?.seq ?? null
    : null;
  const present = index.get<{ id: number | null }>(`SELECT max(ROWID) AS id FROM messages`)?.id ?? 0;
  return Math.max(issued ?? 0, present);
}

/**
 * The rows the index filters select, newest first, before any body is read.
 * A body search (#30) narrows with these and then scans at most `cap` of them;
 * the caller asks for one more than it will scan, so it can tell a candidate
 * set that ran out from one the cap cut short.
 */
export function searchCandidates(index: ReadOnlyIndex, query: SearchQuery, cap: number): RawRow[] {
  const { sql, params } = buildSearchSql(query, cap);
  return index.all<RawRow>(sql, params);
}

/**
 * `mailboxes.url` stores percent-encoded path segments, so a caller asking for
 * "Deleted Messages" never matched "…/Deleted%20Messages" and got a confident
 * zero-result answer. Match either form; the slash is left alone so nested
 * mailbox paths still work.
 */
function mailboxUrlVariants(name: string): string[] {
  const variants: string[] = [];
  // Mail encodes an already-normalised name, and the normalisation it used is
  // not necessarily the one the caller typed: "Envoyés" composed (NFC) and
  // decomposed (NFD) percent-encode to different strings, so matching only the
  // typed form gives another confident zero-result answer on accented names.
  for (const form of ["NFC", "NFD"] as const) {
    let normalised: string;
    try {
      normalised = name.normalize(form);
    } catch {
      normalised = name;
    }
    variants.push(normalised);
    // The slash is left alone so nested mailbox paths keep resolving.
    variants.push(normalised.split("/").map(encodeURIComponent).join("/"));
  }
  return [...new Set(variants)];
}

/**
 * The names Mail and the common servers give an account's Trash, as the last
 * segment of a mailbox url: iCloud and On My Mac use "Deleted Messages",
 * Gmail "[Gmail]/Trash" (or "Bin" in some regions), Exchange "Deleted Items".
 *
 * The index records no mailbox roles, so this is a name match. A Trash under
 * another name — a localised one, say — is not recognised and stays in
 * results. Mail.app itself knows the real one; move_to_trash asks it.
 */
export const TRASH_MAILBOX_NAMES = ["Trash", "Deleted Messages", "Deleted Items", "Bin"] as const;

export function isTrashMailboxUrl(url: string): boolean {
  const leaf = url.split("/").pop() ?? "";
  return TRASH_MAILBOX_NAMES.some((name) => leaf.toLowerCase() === encodeURIComponent(name).toLowerCase());
}

function buildSearchSql(query: SearchQuery, limit: number): { sql: string; params: unknown[] } {
  const where: string[] = [];
  const params: unknown[] = [];

  if (query.id !== undefined) {
    where.push("m.ROWID = ?");
    params.push(query.id);
  }
  if (query.afterId !== undefined) {
    where.push("m.ROWID > ?");
    params.push(query.afterId);
  }
  if (query.conversationId !== undefined) {
    where.push("m.conversation_id = ?");
    params.push(query.conversationId);
  }
  if (!query.includeDeleted) {
    where.push("m.deleted = 0");
  }
  // `deleted` is the IMAP \Deleted flag, and a message in the Trash does not
  // carry it, so includeDeleted alone let Trash through (#73). Trash is left
  // out of a plain search too, but not when the caller names a mailbox — they
  // chose where to look — and not for a lookup by id or conversation, which
  // get_message and get_thread rely on to find a message wherever it is.
  if (
    !query.includeDeleted &&
    !query.mailbox &&
    query.id === undefined &&
    query.conversationId === undefined
  ) {
    for (const name of TRASH_MAILBOX_NAMES) {
      where.push("mb.url NOT LIKE ? ESCAPE '#'");
      params.push(`%/${escapeLike(encodeURIComponent(name))}`);
    }
  }
  if (query.sender) {
    where.push("(sender_addr.address LIKE ? ESCAPE '#' OR sender_addr.comment LIKE ? ESCAPE '#')");
    const like = likeContains(query.sender);
    params.push(like, like);
  }
  if (query.recipient) {
    where.push(`EXISTS (
      SELECT 1 FROM recipients r2
      JOIN addresses ra2 ON ra2.ROWID = r2.address
      WHERE r2.message = m.ROWID
        AND (ra2.address LIKE ? ESCAPE '#' OR ra2.comment LIKE ? ESCAPE '#')
    )`);
    const like = likeContains(query.recipient);
    params.push(like, like);
  }
  if (query.subject) {
    where.push("sub.subject LIKE ? ESCAPE '#'");
    params.push(likeContains(query.subject));
  }
  if (query.after !== undefined) {
    where.push("m.date_received >= ?");
    params.push(query.after);
  }
  if (query.before !== undefined) {
    where.push("m.date_received <= ?");
    params.push(query.before);
  }
  if (query.mailbox) {
    const clauses: string[] = [];
    for (const variant of mailboxUrlVariants(query.mailbox)) {
      clauses.push("mb.url LIKE ? ESCAPE '#'", "mb.url LIKE ? ESCAPE '#'");
      params.push(likeContains(variant), `%/${escapeLike(variant)}`);
    }
    where.push(`(${clauses.join(" OR ")})`);
  }
  if (query.read !== undefined) {
    where.push("m.read = ?");
    params.push(query.read ? 1 : 0);
  }
  if (query.flagged !== undefined) {
    where.push("m.flagged = ?");
    params.push(query.flagged ? 1 : 0);
  }

  const whereSql = where.length > 0 ? `WHERE ${where.join(" AND ")}` : "";
  params.push(limit);

  const sql = `
    SELECT
      m.ROWID AS id,
      m.date_received AS date_received,
      sender_addr.address AS sender_address,
      sender_addr.comment AS sender_name,
      (
        SELECT group_concat(ra.address, char(31))
        FROM recipients r
        JOIN addresses ra ON ra.ROWID = r.address
        WHERE r.message = m.ROWID AND IFNULL(r.type, 0) = 0
      ) AS to_addresses,
      sub.subject AS subject,
      mb.url AS mailbox,
      m.conversation_id AS conversation_id,
      CASE WHEN EXISTS (
        SELECT 1 FROM attachments a WHERE a.message = m.ROWID
      ) THEN 1 ELSE 0 END AS has_attachments
    FROM messages m
    LEFT JOIN subjects sub ON sub.ROWID = m.subject
    LEFT JOIN addresses sender_addr ON sender_addr.ROWID = m.sender
    JOIN mailboxes mb ON mb.ROWID = m.mailbox
    ${whereSql}
    ORDER BY ${query.afterId === undefined ? "m.date_received DESC, m.ROWID DESC" : "m.ROWID ASC"}
    LIMIT ?
  `;

  return { sql, params };
}

export function toSearchRow(row: RawRow, store: MailStore | null, known?: BodyAvailability): SearchRow {
  // A body search has already resolved the file; resolving it again per match
  // would repeat the containment walk for nothing.
  const availability = known ?? (store
    ? peekBodyFile(store, row.id, row.mailbox).status
    : "unknown");
  return {
    id: row.id,
    date: epochToIso(row.date_received),
    from: formatFrom(row.sender_address, row.sender_name),
    to: row.to_addresses ? row.to_addresses.split("\u001f").filter(Boolean) : [],
    subject: row.subject,
    mailbox: row.mailbox,
    conversationId: row.conversation_id,
    "has-attachments": row.has_attachments === 1,
    "body-availability": availability,
  };
}
