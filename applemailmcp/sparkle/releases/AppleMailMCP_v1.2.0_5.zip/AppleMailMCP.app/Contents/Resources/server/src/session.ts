//
//  session.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 13/08/2026.
//

import { existsSync } from "node:fs";
import { basename, dirname, join, resolve } from "node:path";
import { openIndex, type ReadOnlyIndex } from "./db.ts";
import { assertKnownSchema, wrapIndexError } from "./schema.ts";
import { findMailStore } from "./store.ts";
import type { MailStore } from "./types.ts";

export type MailSession = {
  index: ReadOnlyIndex;
  store: MailStore | null;
  close: () => void;
};

export function openSession(options: { indexPath?: string; home?: string } = {}): MailSession {
  try {
    const resolved = resolveStoreAndIndex(options);
    const index = openIndex(resolved.indexPath, options.home);
    try {
      assertKnownSchema(index);
    } catch (error) {
      index.close();
      throw error;
    }
    return {
      index,
      store: resolved.store,
      close: () => index.close(),
    };
  } catch (error) {
    throw wrapIndexError(error, "failed to open Mail session");
  }
}

function resolveStoreAndIndex(options: { indexPath?: string; home?: string }): {
  indexPath: string;
  store: MailStore | null;
} {
  if (!options.indexPath) {
    const store = findMailStore(options.home);
    return { indexPath: store.indexPath, store };
  }
  const indexPath = resolve(options.indexPath);
  if (!existsSync(indexPath)) {
    throw new Error(`Envelope index not found: ${indexPath}`);
  }
  return { indexPath, store: inferStoreFromIndexPath(indexPath) };
}

export function inferStoreFromIndexPath(indexPath: string): MailStore | null {
  const abs = resolve(indexPath);
  if (basename(abs) !== "Envelope Index") {
    return null;
  }
  const mailData = dirname(abs);
  if (basename(mailData) !== "MailData") {
    return null;
  }
  const versionDir = dirname(mailData);
  const version = basename(versionDir);
  if (!/^V\d+$/.test(version)) {
    return null;
  }
  return {
    mailRoot: dirname(versionDir),
    version,
    versionDir,
    indexPath: abs,
  };
}

export function storeFromHome(home: string): MailStore {
  return findMailStore(home);
}

export function fixtureIndexBeside(store: MailStore): string {
  return join(store.versionDir, "MailData", "Envelope Index");
}
