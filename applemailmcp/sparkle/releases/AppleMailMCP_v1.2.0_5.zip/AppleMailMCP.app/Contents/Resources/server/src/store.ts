//
//  store.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 13/08/2026.
//

import { existsSync, readdirSync, realpathSync, statSync } from "node:fs";
import { homedir } from "node:os";
import { join, resolve } from "node:path";
import type { MailStore } from "./types.ts";

const VERSION_DIR = /^V\d+$/;

/**
 * Store layouts this code has been verified against. A new `V*` directory is
 * Apple changing the layout, and the columns read here may not mean what they
 * did — so it is an error until someone checks it, not a guess.
 */
export const KNOWN_STORE_VERSIONS: readonly string[] = ["V10"];

export function mailRootForHome(home: string = homedir()): string {
  return join(home, "Library", "Mail");
}

export function isInsideLiveMailStore(path: string, home: string = homedir()): boolean {
  if (isInsideCanonical(path, mailRootForHome(home))) {
    return true;
  }
  const abs = canonicalPath(path);
  // realpath resolves symlinks but not hardlinks, and a hardlink to the live
  // Envelope Index — or to its -wal — is the same inode under a different name.
  // Only reachable via an explicit --index, but the invariant should not depend
  // on that.
  return sharesInodeWithLiveIndex(abs, home);
}

function sharesInodeWithLiveIndex(absolutePath: string, home: string): boolean {
  // The version directory is discovered, never assumed — V10 today, V11 next.
  // locateMailStore, not findMailStore: an unrecognised version must still be
  // guarded. findMailStore throws on one, and a throw here reads as "no live
  // store", which would let SQLite open a hardlink to it in place.
  return sharesInodeWith(absolutePath, () => sqliteFamily(locateMailStore(home).indexPath));
}

/**
 * Shared by all three store guards: realpath resolves symlinks but not
 * hardlinks, and a hardlink to a live database file is the same inode under a
 * different name.
 *
 * Takes the whole family rather than the main database alone. A `-wal` holds
 * pages that have not been checkpointed yet, so it is as much a part of the
 * live store as the file it belongs to, and the invariant is "SQLite never
 * opens a live store", not "never opens the main file of one".
 */
export function sharesInodeWith(absolutePath: string, liveFiles: () => string[]): boolean {
  let candidate: ReturnType<typeof statSync>;
  try {
    candidate = statSync(absolutePath);
  } catch {
    return false;
  }
  // A hardlink raises the count on every name for the inode, this one included,
  // so a single-link file cannot be a hardlink to anything.
  if (candidate.nlink < 2) {
    return false;
  }

  let live: string[];
  try {
    live = liveFiles();
  } catch {
    // Store not found: nothing to be a hardlink to.
    return false;
  }

  for (const path of live) {
    try {
      const stat = statSync(path);
      if (candidate.dev === stat.dev && candidate.ino === stat.ino) {
        return true;
      }
    } catch {
      // Sidecars are transient — a store between checkpoints has no -wal at
      // all. One absent file must not stop the rest of the family being
      // checked, which is why this is caught per path rather than around the
      // loop.
      continue;
    }
  }
  return false;
}

/**
 * A database and the sidecars SQLite keeps beside it. `-journal` is included
 * even though all three stores run in WAL mode: the guard is about the store,
 * not about the journal mode it happens to use today, and one unused array
 * entry is cheaper than rediscovering this the next time one changes.
 */
export function sqliteFamily(dbPath: string): string[] {
  return [dbPath, `${dbPath}-wal`, `${dbPath}-shm`, `${dbPath}-journal`];
}

/** True when `path` is `root` itself or lives under it, symlinks resolved. */
export function isInsideCanonical(path: string, root: string): boolean {
  const live = canonicalPath(root).toLowerCase();
  const abs = canonicalPath(path).toLowerCase();
  return abs === live || abs.startsWith(live + "/");
}

/**
 * realpath, not resolve: a symlink pointing at the live Envelope Index would
 * otherwise slip past the guard and let SQLite open the store Mail is writing.
 * Compared case-folded because APFS is case-insensitive by default — a false
 * positive only costs us a snapshot, a false negative costs the invariant.
 */
export function canonicalPath(path: string): string {
  const abs = resolve(path);
  try {
    return realpathSync(abs);
  } catch {
    // The path need not exist yet; lexical resolution is the best we can do.
    return abs;
  }
}

/** The live store, refusing a `V*` layout nobody has verified. */
export function findMailStore(home: string = homedir()): MailStore {
  const store = locateMailStore(home);
  if (!KNOWN_STORE_VERSIONS.includes(store.version)) {
    throw new Error(
      `Unknown Mail store version ${store.version} at ${store.versionDir} ` +
        `(this code knows ${KNOWN_STORE_VERSIONS.join(", ")}). Apple has changed the store layout; ` +
        `refusing to guess what its columns mean.`,
    );
  }
  return store;
}

/**
 * The newest `V*` store, whatever its version. Used on its own only where the
 * answer must not depend on recognising the version: the live-store guard.
 */
export function locateMailStore(home: string = homedir()): MailStore {
  const mailRoot = mailRootForHome(home);
  if (!existsSync(mailRoot)) {
    throw new Error(`Mail store not found at ${mailRoot}`);
  }

  const versions = readdirSync(mailRoot)
    .filter((name) => VERSION_DIR.test(name))
    .sort((a, b) => Number(b.slice(1)) - Number(a.slice(1)));

  if (versions.length === 0) {
    const listing = readdirSync(mailRoot).join(", ") || "(empty)";
    throw new Error(
      `No V* Mail version directory under ${mailRoot}. Detected: ${listing}. Refusing to guess.`,
    );
  }

  const version = versions[0];
  const versionDir = join(mailRoot, version);
  const indexPath = join(versionDir, "MailData", "Envelope Index");
  if (!existsSync(indexPath)) {
    throw new Error(
      `Envelope index missing at ${indexPath} (detected store version ${version}).`,
    );
  }

  return { mailRoot, version, versionDir, indexPath };
}

export function parseMailboxUrl(url: string): { scheme: string; accountId: string; path: string } {
  const match = url.match(/^([a-z][a-z0-9+.-]*):\/\/([^/]+)\/?(.*)$/i);
  if (!match) {
    return { scheme: "unknown", accountId: url, path: "" };
  }
  return {
    scheme: match[1].toLowerCase(),
    accountId: safeDecode(match[2]),
    path: safeDecode(match[3]),
  };
}

/**
 * One malformed percent sequence in one mailbox url must not take down the
 * whole listing. The raw value is still more useful than an exception.
 */
function safeDecode(value: string): string {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}
