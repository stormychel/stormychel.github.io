//
//  types.ts
//  AppleMailMCP
//
//  Created by Michel Storms on 13/08/2026.
//

export type BodyAvailability = "unknown" | "full" | "partial" | "unavailable";

export type SearchRow = {
  id: number;
  date: string | null;
  from: string | null;
  to: string[];
  subject: string | null;
  mailbox: string;
  conversationId: number;
  "has-attachments": boolean;
  "body-availability": BodyAvailability;
};

export type SearchQuery = {
  id?: number;
  conversationId?: number;
  sender?: string;
  recipient?: string;
  subject?: string;
  after?: number;
  before?: number;
  mailbox?: string;
  read?: boolean;
  flagged?: boolean;
  includeDeleted?: boolean;
  /** Only messages with a ROWID above this: the polling cursor (#31). */
  afterId?: number;
  limit?: number;
};

export type AttachmentInfo = {
  name: string | null;
  size: number | null;
  contentType: string | null;
};

export type MailStore = {
  mailRoot: string;
  version: string;
  versionDir: string;
  indexPath: string;
};

export type MailboxRow = {
  id: number;
  url: string;
  scheme: string;
  accountId: string;
  path: string;
  totalCount: number;
  unreadCount: number;
};

export type AccountRow = {
  scheme: string;
  id: string;
  mailboxCount: number;
};
