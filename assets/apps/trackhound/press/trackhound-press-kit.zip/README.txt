TrackHound press kit
Built 2026-09-25 from app version 1.16.0

screenshots/   iPhone captures, device-framed, plus CarPlay shots from a car head unit
icon-*.png     app icon, light and dark
keyart.jpg     key art
appstore-qr.png  QR to the App Store listing

TrackHound is offline navigation for ADV motorcycles, supermoto, 4x4 /
overlanding and gravel. Routing runs on the phone, so it keeps working with no
signal. Free to plan; TrackHound Pro adds turn-by-turn and CarPlay.

App Store:  https://apps.apple.com/app/id6762570002
Website:    https://trackhoundapp.com
Press:      michelstorms@icloud.com
